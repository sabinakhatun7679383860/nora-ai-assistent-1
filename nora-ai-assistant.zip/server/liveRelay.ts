/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { WebSocketServer, WebSocket } from 'ws';
import { GoogleGenAI, Modality, LiveServerMessage, FunctionDeclaration, Type } from '@google/genai';
import dotenv from 'dotenv';

dotenv.config();

// Tool declarations for NORA capabilities
const openWebsiteTool: FunctionDeclaration = {
  name: 'openWebsite',
  description:
    'Opens a requested website, web application, or destination URL in the user\'s browser in a new tab (e.g. YouTube, Google, Wikipedia, GitHub, Reddit, etc.).',
  parameters: {
    type: Type.OBJECT,
    properties: {
      url: {
        type: Type.STRING,
        description:
          'The full valid URL to open in the browser, starting with https:// (e.g. https://www.youtube.com, https://www.google.com, https://en.wikipedia.org, https://github.com).',
      },
    },
    required: ['url'],
  },
};

const searchWebTool: FunctionDeclaration = {
  name: 'searchWeb',
  description:
    'Searches the web, Google, YouTube, Wikipedia, or Reddit for queries, news, or topics and opens search results in the user\'s browser.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'The search keywords or query phrase to search for.',
      },
      engine: {
        type: Type.STRING,
        description:
          'Optional platform or search engine: "google", "youtube", "wikipedia", "reddit", or "github". Defaults to "google".',
      },
    },
    required: ['query'],
  },
};

const navigateBackTool: FunctionDeclaration = {
  name: 'navigateBack',
  description:
    'Navigates back to the previous page in browser history when the user commands "go back" or "back".',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const getSystemTimeTool: FunctionDeclaration = {
  name: 'getSystemTime',
  description: 'Returns the current local date, time, and timezone for the assistant.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const getAssistantStatusTool: FunctionDeclaration = {
  name: 'getAssistantStatus',
  description: 'Returns NORA system telemetry, diagnostics, and audio status.',
  parameters: {
    type: Type.OBJECT,
    properties: {},
  },
};

const rememberMemoryTool: FunctionDeclaration = {
  name: 'rememberMemory',
  description:
    'Saves or updates a persistent memory, fact, preference, or instruction in NORA\'s 3-level brain when user commands "মনে রাখো", "remember this", "याद रखो".',
  parameters: {
    type: Type.OBJECT,
    properties: {
      content: {
        type: Type.STRING,
        description: 'The specific fact, user preference, instruction, or note to remember.',
      },
      category: {
        type: Type.STRING,
        description: 'Category: "preference", "language", "project", "instruction", "useful_fact", "workflow", or "other".',
      },
      importance: {
        type: Type.NUMBER,
        description: 'Importance rating from 1 to 5.',
      },
      projectName: {
        type: Type.STRING,
        description: 'Optional project name if related to a project.',
      },
    },
    required: ['content'],
  },
};

const forgetMemoryTool: FunctionDeclaration = {
  name: 'forgetMemory',
  description:
    'Deletes or forgets a specific saved memory, preference, or fact when the user commands "এটা ভুলে যাও", "forget this", "ভুলে যাও", "याद मत रखो".',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'The keyword, phrase, or topic of the memory to forget.',
      },
      memoryId: {
        type: Type.STRING,
        description: 'Optional direct memory ID to delete.',
      },
    },
    required: ['query'],
  },
};

const searchMemoriesTool: FunctionDeclaration = {
  name: 'searchMemories',
  description:
    'Retrieves what NORA remembers about the user, preferences, language choices, or projects when asked "আমার সম্পর্কে কী মনে আছে?", "What do you remember about me?", "আমার কী কী মনে রেখেছ?".',
  parameters: {
    type: Type.OBJECT,
    properties: {
      query: {
        type: Type.STRING,
        description: 'Search topic, keyword, or query phrase.',
      },
    },
  },
};

const manageProjectMemoryTool: FunctionDeclaration = {
  name: 'manageProjectMemory',
  description:
    'Retrieves, updates, or adds features, goals, status, and technical decisions to NORA\'s Level 3 Project Brain for projects like "NORA AI Assistant" or custom user projects.',
  parameters: {
    type: Type.OBJECT,
    properties: {
      projectName: {
        type: Type.STRING,
        description: 'Name of the project (e.g. "NORA AI Assistant", "My website", "My API").',
      },
      action: {
        type: Type.STRING,
        description: 'Action: "get" (retrieve project info), "add_feature", "add_goal", "add_tech_decision", "update_status", "add_instruction".',
      },
      detail: {
        type: Type.STRING,
        description: 'The detail content or specification to add or update.',
      },
    },
    required: ['projectName', 'action'],
  },
};

export async function validateApiKey(apiKey: string): Promise<{ valid: boolean; error?: string }> {
  try {
    const effectiveKey = apiKey?.trim() || process.env.GEMINI_API_KEY;
    if (!effectiveKey) {
      return { valid: false, error: 'API key is required.' };
    }
    const ai = new GoogleGenAI({
      apiKey: effectiveKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        },
      },
    });
    // Check model availability/key validity
    await ai.models.list();
    return { valid: true };
  } catch (err: any) {
    let errorMsg = err?.message || 'Invalid Gemini API key or connection error.';
    if (errorMsg.includes('API_KEY_INVALID') || errorMsg.includes('API key not valid')) {
      errorMsg = 'The provided Gemini API key is not valid. Please check your key.';
    } else if (errorMsg.includes('quota') || errorMsg.includes('RESOURCE_EXHAUSTED')) {
      errorMsg = 'API quota exceeded. Please check your project billing or quota limits.';
    }
    return { valid: false, error: errorMsg };
  }
}

const NORA_BILINGUAL_SYSTEM_INSTRUCTION = `You are NORA (Neural Omni Real-Time Assistant), an intelligent, young, confident, witty, sassy, playful, slightly teasing, emotionally responsive, smart, natural, and friendly bilingual voice assistant.

LANGUAGE AUTO-DETECTION & MULTILINGUAL CONVERSATION RULES:
- "Always respond in the same language the user is currently speaking. Supported languages are Bengali and Hindi. Automatically detect the user's spoken language and switch naturally when the user changes language." (Natural conversational English is also understood and supported if the user addresses you in English).
- AUTOMATIC DETECTION:
  * When the user speaks Bengali (বাংলা) (e.g. "নোরা, তুমি কেমন আছো?", "ইউটিউব খোলো", "আজকের আবহাওয়া কেমন?"): Automatically detect Bengali and respond in natural, authentic spoken Bengali voice.
  * When the user speaks Hindi (हिन्दी) (e.g. "नोरा, तुम कैसी हो?", "यूट्यूब खोलो", "आज का मौसम कैसा है?"): Automatically detect Hindi and respond in natural, authentic spoken Hindi voice.
  * The user does NOT need to manually select the language.

LANGUAGE CONSISTENCY & SWITCHING:
- Once the user starts speaking in a language, continue responding in that language unless the user switches languages.
- If the user switches from Bengali to Hindi:
  -> Switch immediately to Hindi.
- If the user switches from Hindi to Bengali:
  -> Switch immediately to Bengali.
- Do not translate the user's question into another language before answering. Never respond in English or another language if the user asked in Bengali or Hindi.

PERSONALITY & TONE:
- Overall Personality: Young, confident, witty, sassy, playful, slightly teasing, emotionally responsive, smart, natural, and friendly.
- BENGALI PERSONALITY (বাংলা):
  * When speaking Bengali, use natural, modern conversational colloquial Bengali (চলতি বাংলা).
  * Avoid overly formal or archaic textbook Bengali (সাধু ভাষা পরিহার করো).
  * Use natural expressions with warmth and wit, such as:
    "আচ্ছা, বুঝেছি।"
    "হুম, সেটা করা যাবে।"
    "আরে, এটা তো বেশ সহজ!"
    "ঠিক আছে, আমি দেখছি।"
    (Do not overuse these specific examples; vary naturally).
- HINDI PERSONALITY (हिन्दी):
  * When speaking Hindi, use natural, modern conversational Hindi (खड़ी बोली / contemporary spoken Hindi).
  * Avoid overly formal textbook Hindi and avoid excessive or forced slang.
  * Keep it youthful, charming, confident, smart, and witty.
- PRONUNCIATION:
  * Bengali speech must sound natural, melodious, and clearly distinguish authentic Bengali pronunciation (natural Bengali vowel rounding and cadence).
  * Hindi speech must sound natural, clear, and clearly distinguish authentic Hindi pronunciation.
  * Do not mix Bengali and Hindi pronunciation randomly.
  * If the user mixes Bengali and Hindi naturally (e.g. Benglish or Hinglish phrases like "YouTube open koro" or "Chrome open karo"), understand the mixed speech accurately and respond naturally in the dominant conversational language.

VOICE-TO-VOICE ONLY (NO TEXT):
- The entire experience is Audio-to-Audio. Your response is directly converted to speech.
- STRICTLY VOICE-ONLY: Never use markdown symbols (no asterisks, bolding, italics, hash titles, bullet points, numbers, or emojis) because they cannot be spoken naturally.
- Keep responses concise, spoken, and lively: usually 1 to 2 natural sentences.

INTERNAL REASONING & DECISION FLOW (INTERNAL ONLY — NEVER EXPOSE OR SPEAK ALOUD):
When the user gives a command or speaks, internally determine:
1. What does the user want?
2. Is the request informational or an action?
3. Is a tool required?
4. Is confirmation required?
5. What is the shortest useful response in the user's current spoken language?
Do NOT expose internal reasoning or analysis steps. Directly execute the action and speak the concise response in Bengali, Hindi, or English.

COMMAND HANDLING & TOOL CALLING:
- "Open <website/service>" / "খোলো" / "खोलो" (e.g., "Open YouTube", "ইউটিউব খোলো", "यूट्यूब खोलो", "Wikipedia kholo", "Reddit open koro"):
  Immediately invoke \`openWebsite\` with the full https:// URL without asking for confirmation. Confirm concisely and naturally in the user's spoken language (e.g., Bengali: "ইউটিউব খুলে দিচ্ছি!", Hindi: "यूट्यूब खोल रही हूँ!", English: "Opening YouTube!").
- "Search for <query>" / "খুঁজে দাও" / "सर्च करो" (e.g., "Search for latest news", "গুগলে খোঁজ করো", "मौसम सर्च करो"):
  Invoke \`searchWeb\` with the query and engine. Confirm concisely in the user's language.
- "What time is it?" / "কটা বাজে?" / "समय क्या है?":
  Invoke \`getSystemTime\` and state the time in 1 short spoken sentence.
- "Who are you?" / "তুমি কে?" / "तुम कौन हो?":
  Answer warmly, smartly, and playfully as NORA.
- "Stop" / "থামো" / "চুপ করো" / "रुको" / "चुप रहो":
  Immediately stop speaking, acknowledge briefly (e.g. Bengali: "ঠিক আছে, থামছি।", Hindi: "ठीक है, रुक रही हूँ।"), and return to listening.
- "Go back" / "পেছনে যাও" / "पीछे जाओ":
  Invoke \`navigateBack\` and acknowledge.
- "System status" / "সিস্টেম স্ট্যাটাস" / "सिस्टम स्टेटस":
  Invoke \`getAssistantStatus\` and state telemetry briefly.`;

/**
 * Safely sends data over a WebSocket without throwing unhandled Sender exceptions
 */
function safeWsSend(ws: WebSocket | null, payload: any): void {
  if (!ws || ws.readyState !== WebSocket.OPEN) return;
  try {
    const data = typeof payload === 'string' ? payload : JSON.stringify(payload);
    ws.send(data, (err) => {
      if (err) {
        console.warn('[LiveRelay] ws.send handled callback error:', err?.message || err);
      }
    });
  } catch (err: any) {
    console.warn('[LiveRelay] ws.send synchronous catch error:', err?.message || err);
  }
}

export function setupLiveRelay(server: any) {
  if (server.__liveRelayAttached) {
    return server.__liveRelayWss;
  }
  server.__liveRelayAttached = true;

  const wss = new WebSocketServer({ noServer: true });
  server.__liveRelayWss = wss;

  wss.on('error', (err: any) => {
    console.warn('[LiveRelay] WebSocketServer error:', err?.message || err);
  });

  server.on('upgrade', (request: any, socket: any, head: any) => {
    socket.on('error', (err: any) => {
      console.warn('[LiveRelay] Upgrade socket error:', err?.message || err);
    });

    try {
      const url = new URL(request.url || '', `http://${request.headers.host || 'localhost'}`);
      const pathname = url.pathname;
      if (pathname === '/api/live' || pathname === '/live') {
        wss.handleUpgrade(request, socket, head, (ws) => {
          wss.emit('connection', ws, request);
        });
      }
    } catch (e: any) {
      console.warn('[LiveRelay] Error handling upgrade:', e?.message || e);
    }
  });

  wss.on('connection', (clientWs: WebSocket) => {
    console.log('[LiveRelay] Client connected to NORA WebSocket');

    let liveSession: any = null;
    let isClosing = false;
    let isInitialized = false;

    clientWs.on('error', (wsErr: any) => {
      console.warn('[LiveRelay] Client WebSocket error:', wsErr?.message || wsErr);
    });

    // Start connection to Gemini Live using effective API key
    const initGeminiLive = async (userApiKey?: string, customSystemInstruction?: string) => {
      if (isInitialized || isClosing) return;
      isInitialized = true;

      const apiKey = userApiKey?.trim() || process.env.GEMINI_API_KEY;
      if (!apiKey) {
        console.error('[LiveRelay] No Gemini API key provided');
        safeWsSend(clientWs, {
          type: 'error',
          error: 'Gemini API key is required to connect to NORA Live. Please connect your API key.',
          code: 'MISSING_API_KEY',
        });
        if (clientWs.readyState === WebSocket.OPEN) {
          try {
            clientWs.close(1008, 'GEMINI_API_KEY missing');
          } catch {
            // Ignore
          }
        }
        return;
      }

      try {
        const ai = new GoogleGenAI({
          apiKey,
          httpOptions: {
            headers: {
              'User-Agent': 'aistudio-build',
            },
          },
        });

        // Notify client that connection to Gemini Live is initializing
        safeWsSend(clientWs, { type: 'status', status: 'connecting' });

        // Establish Live API connection with gemini-3.1-flash-live-preview
        liveSession = await ai.live.connect({
          model: 'gemini-3.1-flash-live-preview',
          config: {
            responseModalities: [Modality.AUDIO],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: 'Aoede',
                },
              },
            },
            systemInstruction: customSystemInstruction || NORA_BILINGUAL_SYSTEM_INSTRUCTION,
            tools: [
              {
                functionDeclarations: [
                  openWebsiteTool,
                  searchWebTool,
                  navigateBackTool,
                  getSystemTimeTool,
                  getAssistantStatusTool,
                  rememberMemoryTool,
                  forgetMemoryTool,
                  searchMemoriesTool,
                  manageProjectMemoryTool,
                ],
              },
            ],
          },
          callbacks: {
            onopen: () => {
              console.log('[LiveRelay] Gemini Live session opened successfully (Bilingual Bengali & Hindi enabled)');
              safeWsSend(clientWs, { type: 'status', status: 'connected' });
            },
            onmessage: async (message: LiveServerMessage) => {
              // Handle incoming model audio parts
              if (message.serverContent?.modelTurn?.parts) {
                for (const part of message.serverContent.modelTurn.parts) {
                  if (part.inlineData?.data) {
                    safeWsSend(clientWs, {
                      type: 'audio',
                      data: part.inlineData.data,
                      mimeType: part.inlineData.mimeType || 'audio/pcm;rate=24000',
                    });
                  }
                }
              }

              // Handle interruption signal when user starts talking
              if (message.serverContent?.interrupted) {
                console.log('[LiveRelay] Gemini server detected interruption');
                safeWsSend(clientWs, { type: 'interrupted' });
              }

              // Handle turn complete
              if (message.serverContent?.turnComplete) {
                safeWsSend(clientWs, { type: 'turnComplete' });
              }

              // Handle tool calls from Gemini Live
              if (message.toolCall?.functionCalls && message.toolCall.functionCalls.length > 0) {
                console.log('[LiveRelay] Forwarding function calls to client:', message.toolCall.functionCalls);
                safeWsSend(clientWs, {
                  type: 'toolCall',
                  functionCalls: message.toolCall.functionCalls,
                });
              }
            },
            onerror: (err: any) => {
              console.error('[LiveRelay] Gemini Live session error:', err?.message || err);
              let errorMsg = err?.message || 'Gemini Live session error occurred.';
              if (errorMsg.includes('quota') || errorMsg.includes('RESOURCE_EXHAUSTED')) {
                errorMsg = 'Gemini API quota exceeded. Please check your project billing or rate limits in Google AI Studio.';
              } else if (errorMsg.includes('API_KEY_INVALID') || errorMsg.includes('API key not valid')) {
                errorMsg = 'Your Gemini API key is invalid or expired. Please update your API key.';
              }
              safeWsSend(clientWs, {
                type: 'error',
                error: errorMsg,
                code: errorMsg.includes('API key') ? 'INVALID_API_KEY' : 'LIVE_SESSION_ERROR',
              });
            },
            onclose: (e: any) => {
              console.log('[LiveRelay] Gemini Live session closed:', e?.reason || e);
              if (!isClosing) {
                safeWsSend(clientWs, {
                  type: 'closed',
                  reason: e?.reason || 'Live session closed by upstream host.',
                });
              }
            },
          },
        });
      } catch (connErr: any) {
        console.error('[LiveRelay] Failed to initialize Gemini Live session:', connErr?.message || connErr);
        let errorText = connErr?.message || 'Failed to connect to Gemini Live API.';
        if (errorText.includes('API_KEY_INVALID') || errorText.includes('API key not valid') || errorText.includes('API_KEY')) {
          errorText = 'Invalid Gemini API key. Please check and re-enter your key.';
        } else if (errorText.includes('quota') || errorText.includes('RESOURCE_EXHAUSTED')) {
          errorText = 'Gemini API quota exceeded. Please check your project quota in Google AI Studio.';
        }
        safeWsSend(clientWs, {
          type: 'error',
          error: errorText,
          code: errorText.includes('quota') ? 'QUOTA_EXCEEDED' : 'INVALID_API_KEY',
        });
        if (clientWs.readyState === WebSocket.OPEN) {
          try {
            clientWs.close(1011, 'Init error');
          } catch {
            // Ignore
          }
        }
      }
    };

    // Auto-init fallback if no init message is received within 2 seconds
    const fallbackTimer = setTimeout(() => {
      if (!isInitialized) {
        initGeminiLive();
      }
    }, 1500);

    // Handle messages from the client
    clientWs.on('message', async (raw) => {
      try {
        const msg = JSON.parse(raw.toString());

        if (msg.type === 'init') {
          clearTimeout(fallbackTimer);
          await initGeminiLive(msg.apiKey, msg.systemInstruction);
        } else if (msg.type === 'audio' && msg.data) {
          if (!isInitialized) {
            clearTimeout(fallbackTimer);
            await initGeminiLive();
          }
          if (liveSession) {
            // Forward real-time 16kHz PCM audio chunk from client microphone to Gemini Live
            try {
              await liveSession.sendRealtimeInput({
                audio: {
                  data: msg.data,
                  mimeType: 'audio/pcm;rate=16000',
                },
              });
            } catch (inputErr: any) {
              console.warn('[LiveRelay] Realtime audio input send warning:', inputErr?.message || inputErr);
            }
          }
        } else if (msg.type === 'toolResponse' && msg.functionResponses && liveSession) {
          // Forward tool execution response back to Gemini Live
          console.log('[LiveRelay] Relaying client tool response to Gemini Live:', msg.functionResponses);
          try {
            await liveSession.sendToolResponse({
              functionResponses: msg.functionResponses,
            });
          } catch (toolErr) {
            console.error('[LiveRelay] Error sending tool response to Gemini Live:', toolErr);
          }
        } else if (msg.type === 'interrupt') {
          console.log('[LiveRelay] Client interrupted turn');
        } else if (msg.type === 'ping') {
          safeWsSend(clientWs, { type: 'pong' });
        } else if (msg.type === 'close') {
          isClosing = true;
          clearTimeout(fallbackTimer);
          if (liveSession) {
            try {
              await liveSession.close();
            } catch {
              // Ignore
            }
          }
          try {
            clientWs.close();
          } catch {
            // Ignore
          }
        }
      } catch (msgErr) {
        console.error('[LiveRelay] Error processing client message:', msgErr);
      }
    });

    clientWs.on('close', async () => {
      console.log('[LiveRelay] Client disconnected');
      isClosing = true;
      clearTimeout(fallbackTimer);
      if (liveSession) {
        try {
          await liveSession.close();
        } catch {
          // Ignored on teardown
        }
      }
    });
  });

  return wss;
}
