/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { executeOpenWebsite, executeSearchWeb, executeNavigateBack } from './BrowserTools';
import { defaultMemoryService } from './MemoryService';

export interface ToolParameterSchema {
  type: string;
  description?: string;
  properties?: Record<string, unknown>;
  required?: string[];
  items?: Record<string, unknown>;
  enum?: string[];
}

export interface ToolDefinition {
  name: string;
  description: string;
  parameters: ToolParameterSchema;
  execute: (args: Record<string, any>) => Promise<Record<string, any>> | Record<string, any>;
}

export interface FunctionCallRequest {
  id?: string;
  name: string;
  args?: Record<string, any>;
}

export interface FunctionResponsePayload {
  name: string;
  id?: string;
  response: Record<string, unknown>;
}

export class ToolManager {
  private tools: Map<string, ToolDefinition> = new Map();

  constructor() {
    this.registerDefaultTools();
  }

  /**
   * Registers default browser, memory, and assistant tools
   */
  private registerDefaultTools(): void {
    // 1. openWebsite Browser Tool
    this.registerTool({
      name: 'openWebsite',
      description: 'Opens a requested website or web application URL in the user\'s browser in a new tab.',
      parameters: {
        type: 'OBJECT',
        properties: {
          url: {
            type: 'STRING',
            description: 'The URL to open, starting with https:// or http:// (e.g. https://www.youtube.com, https://www.google.com, https://en.wikipedia.org).',
          },
        },
        required: ['url'],
      },
      execute: (args) => {
        const url = typeof args.url === 'string' ? args.url : String(args.url || '');
        return executeOpenWebsite(url);
      },
    });

    // 2. getSystemTime Tool
    this.registerTool({
      name: 'getSystemTime',
      description: 'Returns the current local date, time, and timezone of the user\'s system.',
      parameters: {
        type: 'OBJECT',
        properties: {},
      },
      execute: () => {
        const now = new Date();
        return {
          time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
          date: now.toLocaleDateString([], { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
          timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          iso: now.toISOString(),
        };
      },
    });

    // 3. getAssistantStatus Tool
    this.registerTool({
      name: 'getAssistantStatus',
      description: 'Returns real-time system status, 3-level brain metrics, and engine telemetry for NORA.',
      parameters: {
        type: 'OBJECT',
        properties: {},
      },
      execute: async () => {
        const settings = defaultMemoryService.getBrainSettings();
        const memories = await defaultMemoryService.getAllMemories();
        const projects = await defaultMemoryService.getAllProjects();
        return {
          status: 'online',
          core: 'NORA Neural Real-time Assistant',
          model: 'gemini-3.1-flash-live-preview',
          brainSystem: {
            memoryActive: settings.memoryEnabled,
            shortTermMemory: settings.shortTermMemory,
            longTermMemory: settings.longTermMemory,
            projectBrain: settings.projectBrain,
            totalSavedMemories: memories.length,
            totalProjects: projects.length,
          },
          audioConfig: '16kHz PCM In / 24kHz PCM Out',
          latency: 'real-time ultra low latency',
        };
      },
    });

    // 4. searchWeb Tool
    this.registerTool({
      name: 'searchWeb',
      description: 'Searches the web, Google, YouTube, or Wikipedia for queries, news, or topics and opens search results in the browser.',
      parameters: {
        type: 'OBJECT',
        properties: {
          query: {
            type: 'STRING',
            description: 'The search keywords, query, or phrase to search for.',
          },
          engine: {
            type: 'STRING',
            description: 'Optional search engine or platform: "google", "youtube", "wikipedia", "reddit", or "github". Defaults to "google".',
          },
        },
        required: ['query'],
      },
      execute: (args) => {
        const query = typeof args.query === 'string' ? args.query : String(args.query || '');
        const engine = typeof args.engine === 'string' ? args.engine : undefined;
        return executeSearchWeb(query, engine);
      },
    });

    // 5. navigateBack Tool
    this.registerTool({
      name: 'navigateBack',
      description: 'Navigates back to the previous page in browser history when the user says "go back" or "back".',
      parameters: {
        type: 'OBJECT',
        properties: {},
      },
      execute: () => {
        return executeNavigateBack();
      },
    });

    // 6. rememberMemory Tool (Level 2 & Level 3 Brain)
    this.registerTool({
      name: 'rememberMemory',
      description:
        'Explicitly saves or updates a persistent memory, user preference, instruction, fact, or project note in NORA\'s 3-level brain when user commands "মনে রাখো", "remember this", "याद रखो".',
      parameters: {
        type: 'OBJECT',
        properties: {
          content: {
            type: 'STRING',
            description: 'The exact useful fact, user preference, instruction, or note to store persistently.',
          },
          category: {
            type: 'STRING',
            description: 'Category: "preference", "language", "project", "instruction", "useful_fact", "workflow", or "other".',
          },
          importance: {
            type: 'NUMBER',
            description: 'Importance rating from 1 (low) to 5 (critical user directive).',
          },
          projectName: {
            type: 'STRING',
            description: 'Optional project name if this memory is tied to a specific project (e.g. "NORA AI Assistant").',
          },
        },
        required: ['content'],
      },
      execute: async (args) => {
        try {
          const content = String(args.content || '').trim();
          if (!content) {
            return { success: false, error: 'Memory content cannot be empty.' };
          }

          let projectId: string | undefined;
          if (args.projectName) {
            const proj = await defaultMemoryService.findProjectByName(String(args.projectName));
            if (proj) projectId = proj.id;
          }

          const saved = await defaultMemoryService.saveMemory({
            content,
            category: args.category || 'useful_fact',
            importance: args.importance ? Number(args.importance) : 4,
            projectId,
            projectName: args.projectName,
            source: 'user',
          });

          return {
            success: true,
            message: '✓ মনে রাখলাম / I will remember that',
            memory: {
              id: saved.id,
              content: saved.content,
              category: saved.category,
            },
          };
        } catch (err: any) {
          return {
            success: false,
            error: err?.message || 'Failed to save memory',
          };
        }
      },
    });

    // 7. forgetMemory Tool
    this.registerTool({
      name: 'forgetMemory',
      description:
        'Deletes or forgets a specific saved memory, preference, or fact when the user commands "এটা ভুলে যাও", "forget this", "ভুলে যাও", "याद मत रखो".',
      parameters: {
        type: 'OBJECT',
        properties: {
          query: {
            type: 'STRING',
            description: 'The keyword, phrase, or topic of the memory to forget.',
          },
          memoryId: {
            type: 'STRING',
            description: 'Optional direct memory ID to delete.',
          },
        },
        required: ['query'],
      },
      execute: async (args) => {
        try {
          if (args.memoryId) {
            const deleted = await defaultMemoryService.deleteMemory(String(args.memoryId));
            return {
              success: deleted,
              message: deleted ? '✓ মুছে ফেলা হয়েছে / Memory forgotten' : 'Memory ID not found.',
            };
          }

          const query = String(args.query || '').trim();
          const result = await defaultMemoryService.forgetMatchingMemory(query);
          return {
            success: result.deleted,
            message: result.deleted
              ? `✓ মুছে ফেলা হয়েছে / Forgotten "${result.memory?.content}"`
              : `কোনো মেলেনি / No matching memory found for "${query}"`,
          };
        } catch (err: any) {
          return { success: false, error: err?.message || 'Failed to forget memory' };
        }
      },
    });

    // 8. searchMemories Tool
    this.registerTool({
      name: 'searchMemories',
      description:
        'Retrieves what NORA remembers about the user, preferences, language choices, or projects when asked "আমার সম্পর্কে কী মনে আছে?", "What do you remember about me?", "আমার কী কী মনে রেখেছ?".',
      parameters: {
        type: 'OBJECT',
        properties: {
          query: {
            type: 'STRING',
            description: 'Search topic, keyword, or query phrase.',
          },
        },
      },
      execute: async (args) => {
        const query = String(args.query || '');
        const memories = query
          ? await defaultMemoryService.getRelevantMemories(query, 5)
          : await defaultMemoryService.getAllMemories();

        return {
          success: true,
          count: memories.length,
          memories: memories.map((m) => ({
            content: m.content,
            category: m.category,
            importance: m.importance,
            project: m.projectName,
          })),
        };
      },
    });

    // 9. manageProjectMemory Tool (Level 3 Project Brain)
    this.registerTool({
      name: 'manageProjectMemory',
      description:
        'Retrieves, updates, or adds features, goals, status, and technical decisions to NORA\'s Level 3 Project Brain for projects like "NORA AI Assistant" or custom user projects.',
      parameters: {
        type: 'OBJECT',
        properties: {
          projectName: {
            type: 'STRING',
            description: 'Name of the project (e.g. "NORA AI Assistant", "My website", "My API").',
          },
          action: {
            type: 'STRING',
            description: 'Action: "get" (retrieve project info), "add_feature", "add_goal", "add_tech_decision", "update_status", "add_instruction".',
          },
          detail: {
            type: 'STRING',
            description: 'The detail content or specification to add or update.',
          },
        },
        required: ['projectName', 'action'],
      },
      execute: async (args) => {
        try {
          const name = String(args.projectName || 'NORA AI Assistant').trim();
          const action = String(args.action || 'get').toLowerCase();
          const detail = String(args.detail || '').trim();

          let proj = await defaultMemoryService.findProjectByName(name);
          if (!proj) {
            proj = await defaultMemoryService.saveProject({
              name,
              description: `User project: ${name}`,
            });
          }

          if (action === 'get') {
            return {
              success: true,
              project: {
                name: proj.name,
                status: proj.currentStatus,
                goals: proj.goals,
                features: proj.features,
                technicalDecisions: proj.technicalDecisions,
                importantInstructions: proj.importantInstructions,
              },
            };
          }

          if (action === 'add_feature' && detail) {
            if (!proj.features.includes(detail)) {
              proj.features.push(detail);
              await defaultMemoryService.saveProject(proj);
            }
            return { success: true, message: `✓ Added feature "${detail}" to project "${proj.name}".` };
          }

          if (action === 'add_goal' && detail) {
            if (!proj.goals.includes(detail)) {
              proj.goals.push(detail);
              await defaultMemoryService.saveProject(proj);
            }
            return { success: true, message: `✓ Added goal "${detail}" to project "${proj.name}".` };
          }

          if (action === 'add_tech_decision' && detail) {
            if (!proj.technicalDecisions.includes(detail)) {
              proj.technicalDecisions.push(detail);
              await defaultMemoryService.saveProject(proj);
            }
            return { success: true, message: `✓ Added technical decision to project "${proj.name}".` };
          }

          if (action === 'update_status' && detail) {
            proj.currentStatus = detail;
            await defaultMemoryService.saveProject(proj);
            return { success: true, message: `✓ Updated status of "${proj.name}" to: ${detail}` };
          }

          return { success: true, project: proj };
        } catch (err: any) {
          return { success: false, error: err?.message || 'Failed to manage project memory' };
        }
      },
    });
  }

  /**
   * Registers a new custom tool into the manager
   */
  public registerTool(tool: ToolDefinition): void {
    this.tools.set(tool.name, tool);
    console.log(`[ToolManager] Registered tool: ${tool.name}`);
  }

  /**
   * Checks if a tool with the given name is registered
   */
  public hasTool(name: string): boolean {
    return this.tools.has(name);
  }

  /**
   * Retrieves a registered tool definition
   */
  public getTool(name: string): ToolDefinition | undefined {
    return this.tools.get(name);
  }

  /**
   * Returns list of all registered tool declarations
   */
  public getRegisteredToolNames(): string[] {
    return Array.from(this.tools.keys());
  }

  /**
   * Safely executes a tool call and returns the result object
   */
  public async executeTool(name: string, args: Record<string, any> = {}): Promise<Record<string, unknown>> {
    const tool = this.tools.get(name);
    if (!tool) {
      console.warn(`[ToolManager] Tool "${name}" is not registered.`);
      return {
        error: `Tool "${name}" is not supported or recognized.`,
        success: false,
      };
    }

    try {
      console.log(`[ToolManager] Executing tool "${name}" with arguments:`, args);
      const result = await tool.execute(args);
      return result;
    } catch (err: unknown) {
      const errorMsg = err instanceof Error ? err.message : String(err);
      console.error(`[ToolManager] Error executing tool "${name}":`, errorMsg);
      return {
        error: `Execution error in "${name}": ${errorMsg}`,
        success: false,
      };
    }
  }

  /**
   * Processes a batch of function calls and formats function response payloads
   */
  public async handleFunctionCalls(functionCalls: FunctionCallRequest[]): Promise<FunctionResponsePayload[]> {
    const responses: FunctionResponsePayload[] = [];

    for (const fc of functionCalls) {
      const response = await this.executeTool(fc.name, fc.args || {});
      responses.push({
        name: fc.name,
        id: fc.id,
        response,
      });
    }

    return responses;
  }
}

// Export a singleton instance for standard use
export const defaultToolManager = new ToolManager();
