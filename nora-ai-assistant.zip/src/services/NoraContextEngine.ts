/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NORA_BILINGUAL_SYSTEM_INSTRUCTION } from './noraLiveConfig';
import { defaultMemoryService } from './MemoryService';
import { defaultConversationBrain } from './ConversationBrain';

export interface NoraContextOptions {
  activeProjectId?: string;
  maxMemoryItems?: number;
  maxRecentTurns?: number;
}

/**
 * Centralized AI Context Engine: combines System Directives, Relevant Memories,
 * Project Brain Context, and Short-Term Conversation into an optimized prompt.
 */
export async function buildNoraContext(
  userMessage: string = '',
  options: NoraContextOptions = {}
): Promise<string> {
  const memoryService = defaultMemoryService;
  const convBrain = defaultConversationBrain;
  const brainSettings = memoryService.getBrainSettings();

  const sections: string[] = [NORA_BILINGUAL_SYSTEM_INSTRUCTION];

  if (!brainSettings.memoryEnabled) {
    return sections.join('\n\n');
  }

  // 1. Level 2 Long-Term Memories & Level 3 Project Context
  try {
    const memoryContext = await memoryService.buildMemoryContext(userMessage, options.activeProjectId);
    if (memoryContext) {
      sections.push(memoryContext);
    }
  } catch (err) {
    console.warn('[NoraContextEngine] Error retrieving memories:', err);
  }

  // 2. Level 1 Short-Term Conversation Context
  if (brainSettings.shortTermMemory) {
    const recentHistory = convBrain.formatRecentContext(options.maxRecentTurns || 5);
    if (recentHistory) {
      sections.push(recentHistory);
    }

    const pronounResolution = convBrain.resolveContextReference(userMessage);
    if (pronounResolution) {
      sections.push(pronounResolution);
    }
  }

  return sections.join('\n\n');
}
