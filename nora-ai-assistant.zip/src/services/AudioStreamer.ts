/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AudioStreamerCallbacks {
  onAudioChunk?: (base64Pcm16: string) => void;
  onVolumeChange?: (volume: number, decibels: number) => void;
  onUserSpeechDetected?: () => void; // Triggered when user speaks during assistant playback
  onError?: (error: Error) => void;
}

export class AudioStreamer {
  private audioContext: AudioContext | null = null;
  private mediaStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private processorNode: ScriptProcessorNode | null = null;
  private analyserNode: AnalyserNode | null = null;
  private isStreaming: boolean = false;
  private isMuted: boolean = false;
  private isAssistantSpeaking: boolean = false;
  private speechStreakCount: number = 0;
  private callbacks: AudioStreamerCallbacks = {};

  private readonly TARGET_SAMPLE_RATE = 16000;
  private readonly BUFFER_SIZE = 2048; // 128ms buffer at 16kHz for responsive latency

  // Voice Activity Detection Threshold for client-side instant interruption
  private readonly BARGE_IN_RMS_THRESHOLD = 0.035;
  private readonly REQUIRED_CONSECUTIVE_CHUNKS = 2;

  constructor(callbacks?: AudioStreamerCallbacks) {
    if (callbacks) {
      this.callbacks = callbacks;
    }
  }

  public setCallbacks(callbacks: AudioStreamerCallbacks) {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public getAnalyserNode(): AnalyserNode | null {
    return this.analyserNode;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getIsStreaming(): boolean {
    return this.isStreaming;
  }

  public setAssistantSpeaking(speaking: boolean): void {
    this.isAssistantSpeaking = speaking;
    if (!speaking) {
      this.speechStreakCount = 0;
    }
  }

  /**
   * Request microphone access, configure 16kHz capture, and start streaming
   */
  public async start(): Promise<void> {
    if (this.isStreaming) return;

    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Microphone access is not supported on this browser.');
      }

      // 1. Request microphone stream with voice-optimized constraints
      try {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            channelCount: 1,
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
      } catch (mediaErr: unknown) {
        const error = mediaErr as { name?: string; message?: string };
        if (error.name === 'NotAllowedError' || error.name === 'PermissionDeniedError') {
          throw new Error('Microphone access was denied. Please allow microphone access in your browser to talk with NORA.');
        } else if (error.name === 'NotFoundError' || error.name === 'DevicesNotFoundError') {
          throw new Error('No microphone was found on your device. Please plug in a microphone.');
        } else if (error.name === 'NotReadableError' || error.name === 'TrackStartError') {
          throw new Error('Microphone is already in use by another application.');
        } else {
          throw new Error(`Microphone error: ${error.message || 'Unable to access audio input.'}`);
        }
      }

      // Handle track ending unexpectedly (e.g. unplugged)
      const audioTracks = this.mediaStream.getAudioTracks();
      if (audioTracks.length > 0) {
        audioTracks[0].onended = () => {
          console.warn('[AudioStreamer] Microphone track ended unexpectedly.');
          this.stop();
          this.callbacks.onError?.(new Error('Microphone disconnected.'));
        };
      }

      // 2. Initialize Web Audio Context
      if (typeof window === 'undefined') {
        throw new Error('Web Audio is only available in browser environments.');
      }

      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;

      if (!AudioCtx) {
        throw new Error('Web Audio API is not supported on this browser/device.');
      }

      this.audioContext = new AudioCtx({ sampleRate: this.TARGET_SAMPLE_RATE });

      if (this.audioContext.state === 'suspended') {
        await this.audioContext.resume();
      }

      this.sourceNode = this.audioContext.createMediaStreamSource(this.mediaStream);

      // 3. Create Analyser for reactive visuals
      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.75;
      this.sourceNode.connect(this.analyserNode);

      // 4. Capture PCM float buffers with ScriptProcessor
      this.processorNode = this.audioContext.createScriptProcessor(this.BUFFER_SIZE, 1, 1);

      this.processorNode.onaudioprocess = (event: AudioProcessingEvent) => {
        if (!this.isStreaming || this.isMuted) return;

        const inputBuffer = event.inputBuffer;
        const channelData = inputBuffer.getChannelData(0);
        const currentSampleRate = inputBuffer.sampleRate;

        // Downsample to 16kHz if running on native 44.1k/48k device
        let resampledData: Float32Array;
        if (currentSampleRate !== this.TARGET_SAMPLE_RATE) {
          resampledData = this.downsample(channelData, currentSampleRate, this.TARGET_SAMPLE_RATE);
        } else {
          resampledData = channelData;
        }

        // Compute RMS & Decibels
        let sum = 0;
        for (let i = 0; i < resampledData.length; i++) {
          sum += resampledData[i] * resampledData[i];
        }
        const rms = Math.sqrt(sum / resampledData.length);
        const normalizedVol = Math.min(1, rms * 5.5);
        const decibels = rms > 0.0001 ? 20 * Math.log10(rms) : -90;

        this.callbacks.onVolumeChange?.(normalizedVol, decibels);

        // Client-side Instant Interruption (Barge-in detection)
        if (this.isAssistantSpeaking && rms > this.BARGE_IN_RMS_THRESHOLD) {
          this.speechStreakCount++;
          if (this.speechStreakCount >= this.REQUIRED_CONSECUTIVE_CHUNKS) {
            console.log('[AudioStreamer] User speech detected during playback -> triggering immediate interruption');
            this.callbacks.onUserSpeechDetected?.();
            this.speechStreakCount = 0;
          }
        } else {
          this.speechStreakCount = 0;
        }

        // Convert to 16-bit PCM integer array
        const pcm16 = this.floatTo16BitPCM(resampledData);

        // Convert PCM16 array buffer into base64 string
        const base64Audio = this.arrayBufferToBase64(pcm16.buffer);

        // Send to Gemini Live session
        this.callbacks.onAudioChunk?.(base64Audio);
      };

      this.sourceNode.connect(this.processorNode);
      this.processorNode.connect(this.audioContext.destination);

      this.isStreaming = true;
    } catch (err: unknown) {
      this.stop();
      const error = err instanceof Error ? err : new Error(String(err));
      this.callbacks.onError?.(error);
      throw error;
    }
  }

  /**
   * Stop microphone capture and clean up audio resources
   */
  public stop(): void {
    this.isStreaming = false;
    this.speechStreakCount = 0;

    if (this.processorNode) {
      try {
        this.processorNode.disconnect();
        this.processorNode.onaudioprocess = null;
      } catch {
        // Ignore
      }
      this.processorNode = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch {
        // Ignore
      }
      this.sourceNode = null;
    }

    if (this.analyserNode) {
      try {
        this.analyserNode.disconnect();
      } catch {
        // Ignore
      }
      this.analyserNode = null;
    }

    if (this.mediaStream) {
      try {
        this.mediaStream.getTracks().forEach((track) => track.stop());
      } catch {
        // Ignore
      }
      this.mediaStream = null;
    }

    if (this.audioContext && this.audioContext.state !== 'closed') {
      try {
        this.audioContext.close().catch(() => {});
      } catch {
        // Ignore
      }
      this.audioContext = null;
    }
  }

  /**
   * Anti-aliased linear interpolation downsampling from inputRate to outputRate
   */
  private downsample(buffer: Float32Array, inputRate: number, outputRate: number): Float32Array {
    if (inputRate === outputRate) return buffer;
    const sampleRateRatio = inputRate / outputRate;
    const newLength = Math.round(buffer.length / sampleRateRatio);
    const result = new Float32Array(newLength);
    let offsetResult = 0;
    let offsetBuffer = 0;

    while (offsetResult < result.length) {
      const nextOffsetBuffer = Math.round((offsetResult + 1) * sampleRateRatio);
      let accum = 0;
      let count = 0;
      for (let i = offsetBuffer; i < nextOffsetBuffer && i < buffer.length; i++) {
        accum += buffer[i];
        count++;
      }
      result[offsetResult] = count > 0 ? accum / count : 0;
      offsetResult++;
      offsetBuffer = nextOffsetBuffer;
    }
    return result;
  }

  /**
   * Converts Float32Array (-1.0 to 1.0) into Int16Array (-32768 to 32767)
   */
  private floatTo16BitPCM(input: Float32Array): Int16Array {
    const output = new Int16Array(input.length);
    for (let i = 0; i < input.length; i++) {
      const s = Math.max(-1, Math.min(1, input[i]));
      output[i] = s < 0 ? s * 0x8000 : s * 0x7fff;
    }
    return output;
  }

  /**
   * Fast ArrayBuffer to Base64 conversion
   */
  private arrayBufferToBase64(buffer: ArrayBufferLike): string {
    let binary = '';
    const bytes = new Uint8Array(buffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }
}
