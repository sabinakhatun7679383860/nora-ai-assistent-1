/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VoiceState, AssistantConfig } from '../types/assistant';

/**
 * Gemini Live API Architecture Blueprint
 * 
 * This module establishes the architectural boundaries and contracts for 
 * real-time bidirectional voice-to-voice streaming with the Gemini Live API.
 * 
 * Pipeline:
 * 1. Client Microphone (AudioWorklet / MediaStream)
 * 2. Downsampler (converts browser audio context rate to 16kHz / 24kHz PCM16)
 * 3. Base64 / ArrayBuffer streaming via WebSocket to server proxy (/api/live)
 * 4. Gemini Live WebSocket Session (@google/genai LiveClient)
 * 5. Incoming real-time PCM audio chunks decoded and buffered to Web Audio queue
 */

export interface LiveSessionCallbacks {
  onStateChange?: (state: VoiceState) => void;
  onAudioDataReceived?: (pcm16Data: ArrayBuffer) => void;
  onError?: (error: Error) => void;
  onTelemetryUpdate?: (latencyMs: number) => void;
}

export interface LiveAudioPipelineContract {
  state: VoiceState;
  connect: (config?: Partial<AssistantConfig>) => Promise<void>;
  disconnect: () => Promise<void>;
  sendAudioChunk: (pcm16Data: ArrayBuffer) => void;
  setMuted: (muted: boolean) => void;
  registerCallbacks: (callbacks: LiveSessionCallbacks) => void;
}

export class LiveSessionManager implements LiveAudioPipelineContract {
  private _state: VoiceState = 'DISCONNECTED';
  private callbacks: LiveSessionCallbacks = {};
  private muted: boolean = false;

  get state(): VoiceState {
    return this._state;
  }

  public registerCallbacks(callbacks: LiveSessionCallbacks): void {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public async connect(_config?: Partial<AssistantConfig>): Promise<void> {
    this._state = 'CONNECTING';
    this.callbacks.onStateChange?.(this._state);
    
    // Architecture ready for stage 2 Live API websocket initialization
  }

  public async disconnect(): Promise<void> {
    this._state = 'DISCONNECTED';
    this.callbacks.onStateChange?.(this._state);
  }

  public sendAudioChunk(_pcm16Data: ArrayBuffer): void {
    if (this._state !== 'LISTENING' && this._state !== 'SPEAKING') return;
    // Dispatches PCM16 chunk to Live stream buffer
  }

  public setMuted(muted: boolean): void {
    this.muted = muted;
  }

  public isMuted(): boolean {
    return this.muted;
  }
}

export const liveSessionManager = new LiveSessionManager();
