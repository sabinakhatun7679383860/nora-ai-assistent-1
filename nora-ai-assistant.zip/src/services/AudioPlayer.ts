/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface AudioPlayerCallbacks {
  onPlaybackStateChange?: (isPlaying: boolean) => void;
  onError?: (error: Error) => void;
}

export class AudioPlayer {
  private audioContext: AudioContext | null = null;
  private analyserNode: AnalyserNode | null = null;
  private masterGain: GainNode | null = null;
  private activeSources: { source: AudioBufferSourceNode; gain: GainNode }[] = [];
  private scheduledTime: number = 0;
  private isPlaying: boolean = false;
  private checkTimer: number | null = null;
  private callbacks: AudioPlayerCallbacks = {};
  private currentTurnId: number = 0;

  private readonly SAMPLE_RATE = 24000; // Gemini Live standard audio output rate

  constructor(callbacks?: AudioPlayerCallbacks) {
    if (callbacks) {
      this.callbacks = callbacks;
    }
  }

  public setCallbacks(callbacks: AudioPlayerCallbacks) {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public getAnalyserNode(): AnalyserNode | null {
    return this.analyserNode;
  }

  public getIsPlaying(): boolean {
    return this.isPlaying;
  }

  /**
   * Pre-warm / ensure AudioContext is initialized and active (crucial for mobile/Android gestures)
   */
  public async ensureContext(): Promise<AudioContext> {
    if (!this.audioContext || this.audioContext.state === 'closed') {
      if (typeof window === 'undefined') {
        throw new Error('AudioContext is only available in browser environments.');
      }
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;

      if (!AudioCtx) {
        throw new Error('Web Audio API is not supported on this device/browser.');
      }

      this.audioContext = new AudioCtx({ sampleRate: this.SAMPLE_RATE });

      this.masterGain = this.audioContext.createGain();
      this.masterGain.gain.value = 1.0;

      this.analyserNode = this.audioContext.createAnalyser();
      this.analyserNode.fftSize = 128;
      this.analyserNode.smoothingTimeConstant = 0.7;

      this.masterGain.connect(this.analyserNode);
      this.analyserNode.connect(this.audioContext.destination);
    }

    if (this.audioContext.state === 'suspended') {
      await this.audioContext.resume();
    }

    return this.audioContext;
  }

  /**
   * Reset turn counter on interruption or start of new turn to reject stale delayed chunks
   */
  public nextTurn(): number {
    this.currentTurnId++;
    return this.currentTurnId;
  }

  public getTurnId(): number {
    return this.currentTurnId;
  }

  /**
   * Schedules a 24kHz PCM16 audio chunk into the seamless playback queue
   */
  public async playChunk(base64Pcm16: string, turnId?: number): Promise<void> {
    // If chunk belongs to an older, interrupted turn, drop it immediately
    if (turnId !== undefined && turnId !== this.currentTurnId) {
      return;
    }

    if (!base64Pcm16 || base64Pcm16.length === 0) return;

    try {
      const ctx = await this.ensureContext();

      // Fast Base64 decode to binary
      const binaryString = window.atob(base64Pcm16);
      const len = binaryString.length;
      if (len < 2) return;

      const bytes = new Uint8Array(len);
      for (let i = 0; i < len; i++) {
        bytes[i] = binaryString.charCodeAt(i);
      }

      // Convert PCM16 (Int16Array) to normalized Float32Array (-1.0 to +1.0)
      const int16 = new Int16Array(bytes.buffer, bytes.byteOffset, Math.floor(bytes.byteLength / 2));
      const float32 = new Float32Array(int16.length);
      for (let i = 0; i < int16.length; i++) {
        float32[i] = int16[i] / 32768.0;
      }

      if (float32.length === 0) return;

      // Create Web Audio buffer at 24kHz
      const audioBuffer = ctx.createBuffer(1, float32.length, this.SAMPLE_RATE);
      audioBuffer.getChannelData(0).set(float32);

      // Create source node & individual gain node for anti-pop fading
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;

      const sourceGain = ctx.createGain();
      sourceGain.gain.setValueAtTime(1.0, ctx.currentTime);

      source.connect(sourceGain);
      sourceGain.connect(this.masterGain!);

      // Calculate scheduled timeline
      const currentTime = ctx.currentTime;
      // If queue fell behind (underrun or first chunk), schedule with a tiny cushion (20ms)
      if (this.scheduledTime < currentTime) {
        this.scheduledTime = currentTime + 0.02;
      }

      const startTime = this.scheduledTime;
      source.start(startTime);
      this.scheduledTime += audioBuffer.duration;

      const sourceEntry = { source, gain: sourceGain };
      this.activeSources.push(sourceEntry);

      if (!this.isPlaying) {
        this.isPlaying = true;
        this.callbacks.onPlaybackStateChange?.(true);
        this.startStateMonitor();
      }

      source.onended = () => {
        const idx = this.activeSources.indexOf(sourceEntry);
        if (idx > -1) {
          this.activeSources.splice(idx, 1);
        }
        try {
          source.disconnect();
          sourceGain.disconnect();
        } catch {
          // Ignore
        }
      };
    } catch (err: unknown) {
      console.error('[AudioPlayer] Error processing audio chunk:', err);
      const error = err instanceof Error ? err : new Error(String(err));
      this.callbacks.onError?.(error);
    }
  }

  /**
   * Monitor when audio timeline finishes to notify SPEAKING -> LISTENING
   */
  private startStateMonitor(): void {
    if (this.checkTimer !== null) return;

    const check = () => {
      if (!this.audioContext) {
        this.isPlaying = false;
        this.callbacks.onPlaybackStateChange?.(false);
        this.checkTimer = null;
        return;
      }

      const now = this.audioContext.currentTime;
      if (this.isPlaying && now >= this.scheduledTime && this.activeSources.length === 0) {
        this.isPlaying = false;
        this.callbacks.onPlaybackStateChange?.(false);
        this.checkTimer = null;
        return;
      }

      if (this.isPlaying) {
        this.checkTimer = window.setTimeout(check, 35);
      } else {
        this.checkTimer = null;
      }
    };

    this.checkTimer = window.setTimeout(check, 35);
  }

  /**
   * Immediately stops all playing and scheduled sources with a smooth micro-fade to eliminate clicks
   */
  public flush(): void {
    this.nextTurn(); // Advance turn ID to drop any lagging in-flight chunks

    const ctx = this.audioContext;
    const now = ctx ? ctx.currentTime : 0;

    for (const { source, gain } of this.activeSources) {
      try {
        if (ctx) {
          // Smooth 5ms fade-out before stopping to prevent clicking sound
          gain.gain.setValueAtTime(gain.gain.value, now);
          gain.gain.linearRampToValueAtTime(0, now + 0.005);
          source.stop(now + 0.006);
        } else {
          source.stop();
        }
      } catch {
        // Source might have already finished
      }
    }
    this.activeSources = [];

    if (ctx) {
      this.scheduledTime = ctx.currentTime;
    } else {
      this.scheduledTime = 0;
    }

    if (this.isPlaying) {
      this.isPlaying = false;
      this.callbacks.onPlaybackStateChange?.(false);
    }

    if (this.checkTimer !== null) {
      clearTimeout(this.checkTimer);
      this.checkTimer = null;
    }
  }

  /**
   * Closes or cleans up the audio player
   */
  public close(): void {
    this.flush();
    if (this.audioContext && this.audioContext.state !== 'closed') {
      this.audioContext.close().catch(() => {});
      this.audioContext = null;
    }
    this.analyserNode = null;
    this.masterGain = null;
  }
}
