/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { NoraMemory, NoraProject, NoraBrainSettings } from '../types/memory';

const DB_NAME = 'nora_brain_db';
const DB_VERSION = 1;
const STORE_MEMORIES = 'memories';
const STORE_PROJECTS = 'projects';
const STORE_SETTINGS = 'settings';

export const DEFAULT_BRAIN_SETTINGS: NoraBrainSettings = {
  memoryEnabled: true,
  shortTermMemory: true,
  longTermMemory: true,
  projectBrain: true,
  autoRemember: true,
};

const DEFAULT_NORA_PROJECT: NoraProject = {
  id: 'proj_nora_core',
  name: 'NORA AI Assistant',
  description: 'Neural Omni Real-Time Assistant with bilingual voice, 3-level persistent memory, and browser tool automation.',
  goals: [
    'Natural real-time voice-to-voice conversation in Bengali and Hindi',
    '3-Level persistent brain architecture (Short-Term, Long-Term, Project Brain)',
    'Instant device-private offline memory via IndexedDB',
    'Seamless browser tools and command center HUD',
    'PWA & GitHub Pages compatibility',
  ],
  features: [
    'Gemini 3.1 Flash Live Audio API',
    '3-Level AI Brain & Memory System',
    'Bengali & Hindi Spoken Language Auto-Detection',
    'Voice-to-Voice Full Duplex with Interruption Cutoff',
    'Private Local IndexedDB Storage',
    'Browser Automation Tools (openWebsite, searchWeb, navigateBack, time, status)',
    'Custom Glowing Neural Orb and HUD Waveform',
    'Offline PWA Service Worker Support',
  ],
  technicalDecisions: [
    '16kHz PCM audio microphone streaming',
    '24kHz Web Audio playback scheduler',
    'Pure client-side private memory storage with zero server dependency',
    'Fast memory retrieval scoring based on relevance, importance, and recency',
    'Privacy guard: refusal to store sensitive credentials or keys',
  ],
  importantInstructions: [
    'Always preserve bilingual Bengali and Hindi natural conversational tone',
    'Never store sensitive passwords, API keys, or private secrets in memory',
    'Keep spoken voice responses concise (1-2 sentences)',
    'When user requests to remember something, save it and confirm with "✓ মনে রাখলাম" or "✓ I\'ll remember that"',
  ],
  currentStatus: 'Active — 3-Level AI Brain & Persistent Memory System Online',
  knownIssues: [],
  futurePlans: [
    'Offline local neural voice synthesis',
    'Enhanced multi-project deep linking',
    'Custom skill extensions',
  ],
  createdAt: new Date().toISOString(),
  updatedAt: new Date().toISOString(),
  lastAccessedAt: new Date().toISOString(),
};

/**
 * Checks if text contains sensitive private data (passwords, API keys, tokens, credit cards)
 */
export function isSensitiveContent(text: string): { sensitive: boolean; reason?: string } {
  if (!text || typeof text !== 'string') return { sensitive: false };

  const lower = text.toLowerCase();

  // API Key patterns
  if (/AIza[0-9A-Za-z-_]{35}/.test(text) || /sk-[a-zA-Z0-9]{20,}/.test(text) || /ghp_[a-zA-Z0-9]{20,}/.test(text)) {
    return {
      sensitive: true,
      reason: 'Contains an API key or authentication secret.',
    };
  }

  // Password patterns
  if (/(password\s*[:=]\s*\S+)|(আমার পাসওয়ার্ড|আমার পাসওয়ার্ড|पासवर्ड है)/i.test(text)) {
    return {
      sensitive: true,
      reason: 'Contains password or login credential information.',
    };
  }

  // Credit card / CVV patterns
  if (/\b(?:\d[ -]*?){13,16}\b/.test(text) && /(card|credit|debit|cvv|cvc|কার্ড|कार्ड)/i.test(lower)) {
    return {
      sensitive: true,
      reason: 'Contains financial credit card or payment credential information.',
    };
  }

  // Secret token indicators
  if (/private_key|secret_token|access_token\s*[:=]/i.test(text)) {
    return {
      sensitive: true,
      reason: 'Contains sensitive access tokens or private keys.',
    };
  }

  return { sensitive: false };
}

// In-Memory fallback cache
let memoryCache: NoraMemory[] = [];
let projectCache: NoraProject[] = [DEFAULT_NORA_PROJECT];
let brainSettingsCache: NoraBrainSettings = { ...DEFAULT_BRAIN_SETTINGS };
let isDbInitialized = false;

function openDatabase(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    if (typeof window === 'undefined' || !window.indexedDB) {
      reject(new Error('IndexedDB not supported in this environment'));
      return;
    }

    try {
      const request = window.indexedDB.open(DB_NAME, DB_VERSION);

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Store 1: Memories
        if (!db.objectStoreNames.contains(STORE_MEMORIES)) {
          const memStore = db.createObjectStore(STORE_MEMORIES, { keyPath: 'id' });
          memStore.createIndex('category', 'category', { unique: false });
          memStore.createIndex('importance', 'importance', { unique: false });
          memStore.createIndex('updatedAt', 'updatedAt', { unique: false });
          memStore.createIndex('projectId', 'projectId', { unique: false });
        }

        // Store 2: Projects
        if (!db.objectStoreNames.contains(STORE_PROJECTS)) {
          const projStore = db.createObjectStore(STORE_PROJECTS, { keyPath: 'id' });
          projStore.createIndex('name', 'name', { unique: false });
          projStore.createIndex('updatedAt', 'updatedAt', { unique: false });
        }

        // Store 3: Settings
        if (!db.objectStoreNames.contains(STORE_SETTINGS)) {
          db.createObjectStore(STORE_SETTINGS, { keyPath: 'key' });
        }
      };

      request.onsuccess = () => {
        resolve(request.result);
      };

      request.onerror = () => {
        console.warn('[MemoryStorage] Error opening IndexedDB:', request.error);
        reject(request.error || new Error('Failed to open IndexedDB'));
      };
    } catch (err) {
      reject(err);
    }
  });
}

/**
 * Initializes the IndexedDB memory engine and seeds defaults
 */
export async function initializeMemoryStorage(): Promise<void> {
  if (isDbInitialized) return;

  try {
    const db = await openDatabase();

    // Check & seed settings
    const settings = await getSettingFromDb(db, 'brain_settings');
    if (settings) {
      brainSettingsCache = { ...DEFAULT_BRAIN_SETTINGS, ...settings };
    } else {
      await saveSettingToDb(db, 'brain_settings', DEFAULT_BRAIN_SETTINGS);
    }

    // Check & seed default project
    const projects = await getAllFromStore<NoraProject>(db, STORE_PROJECTS);
    if (projects.length === 0) {
      await putToStore(db, STORE_PROJECTS, DEFAULT_NORA_PROJECT);
      projectCache = [DEFAULT_NORA_PROJECT];
    } else {
      projectCache = projects;
    }

    // Load initial memories into memory cache
    const memories = await getAllFromStore<NoraMemory>(db, STORE_MEMORIES);
    memoryCache = memories;

    isDbInitialized = true;
    console.log(`[MemoryStorage] IndexedDB initialized successfully with ${memories.length} memories and ${projectCache.length} projects.`);
  } catch (err) {
    console.warn('[MemoryStorage] IndexedDB unavailable or blocked, utilizing LocalStorage fallback:', err);
    loadFromLocalStorageFallback();
    isDbInitialized = true;
  }
}

function loadFromLocalStorageFallback(): void {
  try {
    if (typeof localStorage !== 'undefined') {
      const savedSettings = localStorage.getItem('nora_brain_settings');
      if (savedSettings) {
        brainSettingsCache = { ...DEFAULT_BRAIN_SETTINGS, ...JSON.parse(savedSettings) };
      }

      const savedMemories = localStorage.getItem('nora_brain_memories');
      if (savedMemories) {
        memoryCache = JSON.parse(savedMemories);
      }

      const savedProjects = localStorage.getItem('nora_brain_projects');
      if (savedProjects) {
        projectCache = JSON.parse(savedProjects);
      } else {
        projectCache = [DEFAULT_NORA_PROJECT];
      }
    } else {
      projectCache = [DEFAULT_NORA_PROJECT];
    }
  } catch (e) {
    console.warn('[MemoryStorage] Fallback to in-memory store:', e);
    projectCache = [DEFAULT_NORA_PROJECT];
  }
}

function syncToLocalStorageFallback(): void {
  try {
    if (typeof localStorage !== 'undefined') {
      localStorage.setItem('nora_brain_settings', JSON.stringify(brainSettingsCache));
      localStorage.setItem('nora_brain_memories', JSON.stringify(memoryCache));
      localStorage.setItem('nora_brain_projects', JSON.stringify(projectCache));
    }
  } catch {
    // Ignore storage quota exceeded
  }
}

// -------------------------------------------------------------
// IndexedDB Helper Primitives
// -------------------------------------------------------------
function getAllFromStore<T>(db: IDBDatabase, storeName: string): Promise<T[]> {
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(storeName, 'readonly');
      const store = tx.objectStore(storeName);
      const request = store.getAll();

      request.onsuccess = () => resolve((request.result as T[]) || []);
      request.onerror = () => {
        console.warn(`[MemoryStorage] Error reading from ${storeName}:`, request.error);
        resolve([]);
      };
    } catch {
      resolve([]);
    }
  });
}

function putToStore<T>(db: IDBDatabase, storeName: string, item: T): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.put(item);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    } catch (err) {
      reject(err);
    }
  });
}

function deleteFromStore(db: IDBDatabase, storeName: string, key: string): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.delete(key);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    } catch (err) {
      reject(err);
    }
  });
}

function clearStore(db: IDBDatabase, storeName: string): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const tx = db.transaction(storeName, 'readwrite');
      const store = tx.objectStore(storeName);
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    } catch (err) {
      reject(err);
    }
  });
}

function getSettingFromDb(db: IDBDatabase, key: string): Promise<any> {
  return new Promise((resolve) => {
    try {
      const tx = db.transaction(STORE_SETTINGS, 'readonly');
      const store = tx.objectStore(STORE_SETTINGS);
      const request = store.get(key);

      request.onsuccess = () => {
        resolve(request.result?.value ?? null);
      };
      request.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function saveSettingToDb(db: IDBDatabase, key: string, value: any): Promise<void> {
  return putToStore(db, STORE_SETTINGS, { key, value });
}

// -------------------------------------------------------------
// PUBLIC CRUD OPERATIONS FOR MEMORIES
// -------------------------------------------------------------

export async function dbGetAllMemories(): Promise<NoraMemory[]> {
  await initializeMemoryStorage();
  try {
    const db = await openDatabase();
    const memories = await getAllFromStore<NoraMemory>(db, STORE_MEMORIES);
    memoryCache = memories;
    return memories;
  } catch {
    return [...memoryCache];
  }
}

export async function dbGetMemoryById(id: string): Promise<NoraMemory | null> {
  await initializeMemoryStorage();
  return memoryCache.find((m) => m.id === id) || null;
}

export async function dbSaveMemory(memory: NoraMemory): Promise<NoraMemory> {
  await initializeMemoryStorage();

  // Update in-memory cache
  const idx = memoryCache.findIndex((m) => m.id === memory.id);
  if (idx >= 0) {
    memoryCache[idx] = memory;
  } else {
    memoryCache.unshift(memory);
  }

  try {
    const db = await openDatabase();
    await putToStore(db, STORE_MEMORIES, memory);
  } catch {
    syncToLocalStorageFallback();
  }

  return memory;
}

export async function dbDeleteMemory(id: string): Promise<boolean> {
  await initializeMemoryStorage();

  const prevLen = memoryCache.length;
  memoryCache = memoryCache.filter((m) => m.id !== id);

  try {
    const db = await openDatabase();
    await deleteFromStore(db, STORE_MEMORIES, id);
  } catch {
    syncToLocalStorageFallback();
  }

  return memoryCache.length < prevLen;
}

export async function dbClearAllMemories(): Promise<boolean> {
  await initializeMemoryStorage();
  memoryCache = [];

  try {
    const db = await openDatabase();
    await clearStore(db, STORE_MEMORIES);
  } catch {
    syncToLocalStorageFallback();
  }

  return true;
}

// -------------------------------------------------------------
// PUBLIC CRUD OPERATIONS FOR PROJECTS
// -------------------------------------------------------------

export async function dbGetAllProjects(): Promise<NoraProject[]> {
  await initializeMemoryStorage();
  try {
    const db = await openDatabase();
    const projs = await getAllFromStore<NoraProject>(db, STORE_PROJECTS);
    if (projs.length > 0) {
      projectCache = projs;
    }
    return projectCache;
  } catch {
    return [...projectCache];
  }
}

export async function dbGetProjectById(id: string): Promise<NoraProject | null> {
  await initializeMemoryStorage();
  return projectCache.find((p) => p.id === id) || null;
}

export async function dbSaveProject(project: NoraProject): Promise<NoraProject> {
  await initializeMemoryStorage();

  const idx = projectCache.findIndex((p) => p.id === project.id);
  if (idx >= 0) {
    projectCache[idx] = project;
  } else {
    projectCache.push(project);
  }

  try {
    const db = await openDatabase();
    await putToStore(db, STORE_PROJECTS, project);
  } catch {
    syncToLocalStorageFallback();
  }

  return project;
}

export async function dbDeleteProject(id: string): Promise<boolean> {
  await initializeMemoryStorage();

  // Protect default project from permanent deletion
  if (id === 'proj_nora_core') {
    return false;
  }

  const prevLen = projectCache.length;
  projectCache = projectCache.filter((p) => p.id !== id);

  try {
    const db = await openDatabase();
    await deleteFromStore(db, STORE_PROJECTS, id);
  } catch {
    syncToLocalStorageFallback();
  }

  return projectCache.length < prevLen;
}

// -------------------------------------------------------------
// BRAIN SETTINGS
// -------------------------------------------------------------

export function dbGetBrainSettings(): NoraBrainSettings {
  return { ...brainSettingsCache };
}

export async function dbSaveBrainSettings(settings: Partial<NoraBrainSettings>): Promise<NoraBrainSettings> {
  brainSettingsCache = { ...brainSettingsCache, ...settings };

  try {
    const db = await openDatabase();
    await saveSettingToDb(db, 'brain_settings', brainSettingsCache);
  } catch {
    syncToLocalStorageFallback();
  }

  return { ...brainSettingsCache };
}
