/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { ConversationTurn } from '../types/memory';
import { defaultMemoryService } from './MemoryService';

const MAX_RECENT_TURNS = 12;

export class ConversationBrain {
  private static instance: ConversationBrain;
  private turns: ConversationTurn[] = [];
  private currentTopic: string = '';
  private referencedEntity: string = '';

  private constructor() {}

  public static getInstance(): ConversationBrain {
    if (!ConversationBrain.instance) {
      ConversationBrain.instance = new ConversationBrain();
    }
    return ConversationBrain.instance;
  }

  /**
   * Adds a new conversation turn to short-term memory
   */
  public addTurn(speaker: 'user' | 'nora', text: string, detectedLanguage?: 'bn' | 'hi' | 'en'): ConversationTurn {
    const settings = defaultMemoryService.getBrainSettings();
    if (!settings.memoryEnabled || !settings.shortTermMemory) {
      return {
        id: `turn_${Date.now()}`,
        speaker,
        text,
        timestamp: Date.now(),
      };
    }

    const cleanText = text.trim();
    if (!cleanText) {
      return {
        id: `turn_${Date.now()}`,
        speaker,
        text: '',
        timestamp: Date.now(),
      };
    }

    // Extract referenced entities (e.g. project names or subjects)
    if (speaker === 'user') {
      if (/project\s+called\s+([A-Za-z0-9\s_-]+)/i.test(cleanText)) {
        const match = cleanText.match(/project\s+called\s+([A-Za-z0-9\s_-]+)/i);
        if (match?.[1]) this.referencedEntity = match[1].trim();
      } else if (/(nora|নোরা)/i.test(cleanText)) {
        this.referencedEntity = 'NORA project';
      }
    }

    const turn: ConversationTurn = {
      id: `turn_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      speaker,
      text: cleanText,
      timestamp: Date.now(),
      detectedLanguage,
    };

    this.turns.push(turn);

    // Keep turns compact
    if (this.turns.length > MAX_RECENT_TURNS) {
      this.turns.shift();
    }

    return turn;
  }

  /**
   * Gets recent turns up to specified count
   */
  public getRecentTurns(count: number = 6): ConversationTurn[] {
    const settings = defaultMemoryService.getBrainSettings();
    if (!settings.memoryEnabled || !settings.shortTermMemory) {
      return [];
    }
    return this.turns.slice(-count);
  }

  /**
   * Resolves contextual pronouns or follow-up references
   * e.g. "It needs a voice system" -> detects "It" refers to previous entity (e.g. NORA project)
   */
  public resolveContextReference(query: string): string {
    if (!query) return '';
    const clean = query.trim();

    if (this.referencedEntity) {
      // Check for pronouns
      if (/^(it|that|this|সেটা|এটা|এর|उसका|यह)\s+/i.test(clean) || /\b(it|that)\b/i.test(clean)) {
        return `[Context Note: User pronoun 'it/that/সেটা' refers to "${this.referencedEntity}"]`;
      }
    }

    return '';
  }

  /**
   * Formats compact recent context string for system prompt injection
   */
  public formatRecentContext(maxTurns: number = 5): string {
    const settings = defaultMemoryService.getBrainSettings();
    if (!settings.memoryEnabled || !settings.shortTermMemory || this.turns.length === 0) {
      return '';
    }

    const recent = this.turns.slice(-maxTurns);
    const lines = recent.map((t) => `${t.speaker === 'user' ? 'User' : 'NORA'}: ${t.text}`);
    return `RECENT CONVERSATION HISTORY (SHORT-TERM CONTEXT):\n${lines.join('\n')}`;
  }

  /**
   * Clears short-term conversation turns
   */
  public clear(): void {
    this.turns = [];
    this.currentTopic = '';
    this.referencedEntity = '';
  }
}

export const defaultConversationBrain = ConversationBrain.getInstance();
