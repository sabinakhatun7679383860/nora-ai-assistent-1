/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface BrowserToolResult {
  [key: string]: unknown;
  success: boolean;
  action: string;
  url?: string;
  domain?: string;
  message?: string;
  error?: string;
}

/**
 * Validates and sanitizes a URL strictly allowing only http and https protocols.
 * Blocks any dangerous protocols (javascript:, data:, file:, blob:, vbscript:, etc.).
 */
export function validateAndSanitizeUrl(rawUrl: string): { valid: boolean; url: string; domain: string; error?: string } {
  if (!rawUrl || typeof rawUrl !== 'string') {
    return { valid: false, url: '', domain: '', error: 'URL must be a non-empty string.' };
  }

  let trimmed = rawUrl.trim();

  // If user or model passes a domain without protocol (e.g. "youtube.com" or "www.google.com"), prepend https://
  if (!/^https?:\/\//i.test(trimmed)) {
    // Prevent malicious protocol injection disguised before slash
    if (/^[a-z0-9+.-]+:/i.test(trimmed)) {
      // Has a protocol that is NOT http or https (e.g. javascript:, file:, data:, blob:)
      return {
        valid: false,
        url: trimmed,
        domain: '',
        error: `Disallowed protocol. Only http:// and https:// URLs are permitted.`,
      };
    }
    trimmed = `https://${trimmed}`;
  }

  try {
    const parsed = new URL(trimmed);

    // Strict protocol check: ONLY http: and https: are allowed
    const protocol = parsed.protocol.toLowerCase();
    if (protocol !== 'http:' && protocol !== 'https:') {
      return {
        valid: false,
        url: trimmed,
        domain: '',
        error: `Security Violation: Protocol "${protocol}" is blocked. Only http:// and https:// are permitted.`,
      };
    }

    // Check for invalid hostnames
    if (!parsed.hostname || parsed.hostname.length < 1) {
      return { valid: false, url: trimmed, domain: '', error: 'Invalid hostname in URL.' };
    }

    // Check for forbidden characters in URL that could indicate injection
    if (/[\r\n\t<>"'`]/.test(trimmed)) {
      return { valid: false, url: trimmed, domain: '', error: 'URL contains forbidden characters.' };
    }

    return {
      valid: true,
      url: parsed.href,
      domain: parsed.hostname,
    };
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : 'Invalid URL format';
    return { valid: false, url: trimmed, domain: '', error: `Invalid URL: ${msg}` };
  }
}

/**
 * Executes safe browser navigation to a verified URL.
 */
export function executeOpenWebsite(rawUrl: string): BrowserToolResult {
  const validation = validateAndSanitizeUrl(rawUrl);

  if (!validation.valid) {
    console.warn(`[BrowserTools] openWebsite rejected URL: ${rawUrl} - ${validation.error}`);
    return {
      success: false,
      action: 'openWebsite',
      url: rawUrl,
      error: validation.error || 'Invalid or forbidden URL.',
    };
  }

  try {
    // Safe browser open with noopener and noreferrer
    const targetUrl = validation.url;
    console.log(`[BrowserTools] Opening validated website: ${targetUrl}`);

    // Open in a new tab safely
    const newWindow = window.open(targetUrl, '_blank', 'noopener,noreferrer');
    
    // Note: If running inside an iframe sandbox with restricted popups, window.open may return null
    // or be intercepted by the host browser popup manager.
    const isOpened = newWindow !== null;

    return {
      success: true,
      action: 'openWebsite',
      url: targetUrl,
      domain: validation.domain,
      message: isOpened
        ? `Successfully opened ${validation.domain} in a new tab.`
        : `Requested navigation to ${validation.domain}.`,
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    console.error('[BrowserTools] Error opening website:', errorMsg);
    return {
      success: false,
      action: 'openWebsite',
      url: validation.url,
      error: `Failed to open browser tab: ${errorMsg}`,
    };
  }
}

/**
 * Searches the web or a specific platform via search URL navigation.
 */
export function executeSearchWeb(query: string, engine?: string): BrowserToolResult {
  if (!query || typeof query !== 'string' || query.trim().length === 0) {
    return {
      success: false,
      action: 'searchWeb',
      error: 'Search query cannot be empty.',
    };
  }

  const cleanQuery = query.trim();
  const lowerEngine = (engine || '').toLowerCase();
  let searchUrl: string;

  if (lowerEngine.includes('youtube') || lowerEngine === 'yt') {
    searchUrl = `https://www.youtube.com/results?search_query=${encodeURIComponent(cleanQuery)}`;
  } else if (lowerEngine.includes('wikipedia') || lowerEngine === 'wiki') {
    searchUrl = `https://en.wikipedia.org/wiki/Special:Search?search=${encodeURIComponent(cleanQuery)}`;
  } else if (lowerEngine.includes('reddit')) {
    searchUrl = `https://www.reddit.com/search/?q=${encodeURIComponent(cleanQuery)}`;
  } else if (lowerEngine.includes('github')) {
    searchUrl = `https://github.com/search?q=${encodeURIComponent(cleanQuery)}`;
  } else {
    searchUrl = `https://www.google.com/search?q=${encodeURIComponent(cleanQuery)}`;
  }

  return executeOpenWebsite(searchUrl);
}

/**
 * Safely navigates back in browser history if supported.
 */
export function executeNavigateBack(): BrowserToolResult {
  try {
    if (typeof window !== 'undefined' && window.history && window.history.length > 1) {
      window.history.back();
      return {
        success: true,
        action: 'navigateBack',
        message: 'Navigated back to previous page in browser history.',
      };
    }
    return {
      success: true,
      action: 'navigateBack',
      message: 'Navigation back signal acknowledged.',
    };
  } catch (err: unknown) {
    const errorMsg = err instanceof Error ? err.message : String(err);
    return {
      success: false,
      action: 'navigateBack',
      error: `Could not navigate back: ${errorMsg}`,
    };
  }
}
