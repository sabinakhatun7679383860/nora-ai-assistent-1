/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { VoiceState, AudioMetrics } from '../types/assistant';
import { AudioStreamer } from './AudioStreamer';
import { AudioPlayer } from './AudioPlayer';
import { ToolManager, defaultToolManager, FunctionCallRequest, FunctionResponsePayload } from './ToolManager';
import { getStoredApiKey } from './apiKeyStorage';
import { NORA_BILINGUAL_SYSTEM_INSTRUCTION, NORA_FUNCTION_DECLARATIONS } from './noraLiveConfig';
import { buildNoraContext } from './NoraContextEngine';
import { defaultConversationBrain } from './ConversationBrain';

export interface LiveSessionCallbacks {
  onStateChange?: (state: VoiceState) => void;
  onMetricsUpdate?: (metrics: AudioMetrics) => void;
  onError?: (error: string, isFatal?: boolean) => void;
  onTelemetryUpdate?: (telemetry: { latencyMs: number }) => void;
  onToolCallExecuted?: (toolName: string, args: any, result: any) => void;
}

export class LiveSession {
  private state: VoiceState = 'DISCONNECTED';
  private ws: WebSocket | null = null;
  private streamer: AudioStreamer;
  private player: AudioPlayer;
  private toolManager: ToolManager;
  private callbacks: LiveSessionCallbacks = {};
  private isMuted: boolean = false;
  private animFrameId: number | null = null;
  private pingInterval: number | null = null;
  private lastPingTimestamp: number = 0;
  private currentLatencyMs: number = 24;
  private isConnecting: boolean = false;
  private sessionId: number = 0;
  private wakeLock: any = null;
  private currentTurnId: number = 0;
  private currentApiKey: string | null = null;
  private isDirectGeminiMode: boolean = false;

  constructor(callbacks?: LiveSessionCallbacks, toolManager?: ToolManager) {
    if (callbacks) {
      this.callbacks = callbacks;
    }

    this.toolManager = toolManager || defaultToolManager;

    this.streamer = new AudioStreamer({
      onAudioChunk: (base64) => this.handleStreamerChunk(base64),
      onUserSpeechDetected: () => this.handleUserInterruption(),
      onError: (err) => this.handleStreamerError(err),
    });

    this.player = new AudioPlayer({
      onPlaybackStateChange: (isPlaying) => this.handlePlaybackChange(isPlaying),
      onError: (err) => this.callbacks.onError?.(err.message, false),
    });
  }

  public setCallbacks(callbacks: LiveSessionCallbacks) {
    this.callbacks = { ...this.callbacks, ...callbacks };
  }

  public getToolManager(): ToolManager {
    return this.toolManager;
  }

  public setToolManager(manager: ToolManager): void {
    this.toolManager = manager;
  }

  public getState(): VoiceState {
    return this.state;
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public getLatency(): number {
    return this.currentLatencyMs;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    this.streamer.setMuted(muted);
  }

  /**
   * Pre-warms audio context from a user touch/click gesture (essential for Android Chrome)
   */
  public async preWarmAudio(): Promise<void> {
    try {
      await this.player.ensureContext();
    } catch (e) {
      console.warn('[LiveSession] Audio pre-warm warning:', e);
    }
  }

  /**
   * Establishes real-time connection with Gemini Live API:
   * - Uses direct client-side Gemini Live WebSocket when hosted on GitHub Pages or static hosts.
   * - Uses local server relay with automatic direct fallback in full-stack environments.
   */
  public async connect(customApiKey?: string): Promise<void> {
    if (this.isConnecting || this.state === 'LISTENING' || this.state === 'SPEAKING') {
      console.warn('[LiveSession] Connection already active or in progress.');
      return;
    }

    if (customApiKey) {
      this.currentApiKey = customApiKey.trim();
    }

    const effectiveKey = this.currentApiKey || getStoredApiKey() || undefined;

    this.isConnecting = true;
    const currentSessionId = ++this.sessionId;
    this.setState('CONNECTING');

    try {
      // 1. Pre-warm AudioContext for mobile audio unlock
      await this.player.ensureContext();

      // 2. Start microphone capture (16kHz PCM16 continuous)
      await this.streamer.start();

      // Check if session was aborted while acquiring mic
      if (this.sessionId !== currentSessionId) {
        this.cleanup();
        return;
      }

      // 3. Determine connection strategy (Direct Gemini Live vs Server Relay)
      const hostname = window.location.hostname;
      const isStaticHost =
        hostname.endsWith('.github.io') ||
        hostname.includes('pages.dev') ||
        hostname.includes('vercel.app') ||
        hostname.includes('netlify.app') ||
        window.location.protocol === 'file:';

      if (isStaticHost || effectiveKey) {
        // Direct Client-to-Gemini Live WebSocket connection (works 100% on GitHub Pages without any backend)
        this.connectDirectGeminiLive(effectiveKey, currentSessionId);
      } else {
        // Local server relay connection
        this.connectRelay(effectiveKey, currentSessionId);
      }

      // 4. Request Screen WakeLock if available (Android/Mobile battery power saving prevention)
      this.acquireWakeLock();

      // 5. Start audio reactive visualizer metric loop
      this.startMetricsLoop();
    } catch (err: unknown) {
      console.error('[LiveSession] Connect failure:', err);
      const msg = err instanceof Error ? err.message : 'Failed to connect to NORA.';
      this.callbacks.onError?.(msg, true);
      this.disconnect();
    } finally {
      this.isConnecting = false;
    }
  }

  /**
   * Connects directly to Google's Gemini Live BidiGenerateContent WebSocket endpoint
   * (Enables 100% serverless static hosting on GitHub Pages).
   */
  private connectDirectGeminiLive(apiKey: string | undefined, currentSessionId: number): void {
    if (!apiKey) {
      this.callbacks.onError?.('Gemini API key is required. Please enter your API key.', true);
      this.disconnect();
      return;
    }

    this.isDirectGeminiMode = true;
    const directWsUrl = `wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1alpha.GenerativeService.BidiGenerateContent?key=${encodeURIComponent(
      apiKey
    )}`;

    console.log('[LiveSession] Connecting directly to Gemini Live WebSocket...');
    const socket = new WebSocket(directWsUrl);
    this.ws = socket;

    socket.onopen = async () => {
      if (this.sessionId !== currentSessionId) {
        socket.close();
        return;
      }
      console.log('[LiveSession] Direct Gemini Live WebSocket connected. Sending initial setup payload...');

      // Build dynamic system instruction with 3-Level Brain memories
      let dynamicInstruction = NORA_BILINGUAL_SYSTEM_INSTRUCTION;
      try {
        dynamicInstruction = await buildNoraContext('');
      } catch (err) {
        console.warn('[LiveSession] Failed to build dynamic memory context:', err);
      }

      // Send Gemini Live Bidi setup message with Aoede voice, Bengali + Hindi system instruction & tools
      const setupPayload = {
        setup: {
          model: 'models/gemini-2.0-flash-exp',
          generationConfig: {
            responseModalities: ['AUDIO'],
            speechConfig: {
              voiceConfig: {
                prebuiltVoiceConfig: {
                  voiceName: 'Aoede',
                },
              },
            },
          },
          systemInstruction: {
            parts: [{ text: dynamicInstruction }],
          },
          tools: [
            {
              functionDeclarations: NORA_FUNCTION_DECLARATIONS,
            },
          ],
        },
      };

      socket.send(JSON.stringify(setupPayload));
      this.startDirectPingMonitor();
    };

    socket.onmessage = (event: MessageEvent) => {
      if (this.sessionId !== currentSessionId) return;
      this.handleServerMessage(event.data);
    };

    socket.onerror = (evt) => {
      console.error('[LiveSession] Direct Gemini Live WebSocket error:', evt);
      if (this.sessionId === currentSessionId) {
        this.callbacks.onError?.(
          'Unable to establish direct connection to Gemini Live. Please verify your internet connection and API key.',
          true
        );
        this.disconnect();
      }
    };

    socket.onclose = (evt) => {
      console.log('[LiveSession] Direct Gemini Live WebSocket closed with code:', evt.code, evt.reason);
      if (this.sessionId === currentSessionId && this.state !== 'DISCONNECTED') {
        if (evt.code === 1008 || (evt.reason && evt.reason.toLowerCase().includes('key'))) {
          this.callbacks.onError?.('Gemini API key is invalid or unauthorized. Please check your key.', true);
        } else if (evt.code !== 1000) {
          this.callbacks.onError?.('Live session ended.', false);
        }
        this.disconnect();
      }
    };
  }

  /**
   * Connects via local server WebSocket Live API relay (/api/live)
   */
  private connectRelay(apiKey: string | undefined, currentSessionId: number): void {
    this.isDirectGeminiMode = false;
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const host = window.location.host;
    const wsUrl = `${protocol}//${host}/api/live`;

    console.log(`[LiveSession] Connecting to local relay WebSocket: ${wsUrl}`);
    const socket = new WebSocket(wsUrl);
    this.ws = socket;

    socket.onopen = async () => {
      if (this.sessionId !== currentSessionId) {
        socket.close();
        return;
      }
      console.log('[LiveSession] Live relay WebSocket connected.');

      let dynamicInstruction = NORA_BILINGUAL_SYSTEM_INSTRUCTION;
      try {
        dynamicInstruction = await buildNoraContext('');
      } catch (err) {
        console.warn('[LiveSession] Failed to build dynamic memory context:', err);
      }

      // Transmit init packet with API key and dynamic memory instruction
      socket.send(
        JSON.stringify({
          type: 'init',
          apiKey,
          systemInstruction: dynamicInstruction,
        })
      );

      this.startPingMonitor();
    };

    socket.onmessage = (event: MessageEvent) => {
      if (this.sessionId !== currentSessionId) return;
      this.handleServerMessage(event.data);
    };

    socket.onerror = (evt) => {
      console.warn('[LiveSession] Relay WebSocket error, falling back to direct connection if key is available:', evt);
      if (this.sessionId === currentSessionId) {
        if (apiKey) {
          console.log('[LiveSession] Initiating automatic fallback to direct Gemini Live WebSocket');
          this.connectDirectGeminiLive(apiKey, currentSessionId);
        } else {
          this.callbacks.onError?.(
            'Unable to connect to NORA Live service. Please check your network connection and Gemini API key.',
            true
          );
          this.disconnect();
        }
      }
    };

    socket.onclose = (evt) => {
      console.log('[LiveSession] Relay WebSocket closed with code:', evt.code);
      if (this.sessionId === currentSessionId && this.state !== 'DISCONNECTED') {
        if (evt.code === 1008) {
          this.callbacks.onError?.('Gemini API key is not configured or invalid. Please check your key.', true);
        } else if (evt.code !== 1000) {
          this.callbacks.onError?.('Live session disconnected.', false);
        }
        this.disconnect();
      }
    };
  }

  /**
   * Alias for connect() to maintain backward compatibility
   */
  public async start(apiKey?: string): Promise<void> {
    return this.connect(apiKey);
  }

  /**
   * Disconnect active voice session safely
   */
  public disconnect(): void {
    this.isConnecting = false;
    this.sessionId++; // Invalidate active session callbacks

    this.stopPingMonitor();
    this.stopMetricsLoop();
    this.releaseWakeLock();

    if (this.ws) {
      try {
        if (this.ws.readyState === WebSocket.OPEN) {
          if (!this.isDirectGeminiMode) {
            this.ws.send(JSON.stringify({ type: 'close' }));
          }
        }
        this.ws.close();
      } catch {
        // Ignore
      }
      this.ws = null;
    }

    this.streamer.stop();
    this.player.flush();

    this.setState('DISCONNECTED');
  }

  /**
   * Alias for disconnect()
   */
  public stop(): void {
    this.disconnect();
  }

  /**
   * Reconnects the session cleanly
   */
  public async reconnect(apiKey?: string): Promise<void> {
    this.disconnect();
    // Brief delay before reconnecting
    await new Promise((resolve) => setTimeout(resolve, 300));
    await this.connect(apiKey);
  }

  /**
   * Complete teardown and memory release
   */
  public cleanup(): void {
    this.disconnect();
    this.player.close();
  }

  /**
   * Instant interruption handling triggered when user starts speaking while NORA is speaking
   */
  private handleUserInterruption(): void {
    if (this.state === 'SPEAKING') {
      console.log('[LiveSession] Interruption triggered: flushing playback queue and switching to LISTENING');
      this.currentTurnId = this.player.nextTurn();
      this.player.flush();
      this.streamer.setAssistantSpeaking(false);
      this.setState('LISTENING');

      // Inform upstream Gemini so model truncates buffered audio
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        if (this.isDirectGeminiMode) {
          this.ws.send(
            JSON.stringify({
              clientContent: {
                turnComplete: false,
              },
            })
          );
        } else {
          this.ws.send(JSON.stringify({ type: 'interrupt' }));
        }
      }
    }
  }

  private handleStreamerChunk(base64: string): void {
    if (this.ws && this.ws.readyState === WebSocket.OPEN && !this.isMuted) {
      if (this.isDirectGeminiMode) {
        this.ws.send(
          JSON.stringify({
            realtimeInput: {
              mediaChunks: [
                {
                  mimeType: 'audio/pcm;rate=16000',
                  data: base64,
                },
              ],
            },
          })
        );
      } else {
        this.ws.send(
          JSON.stringify({
            type: 'audio',
            data: base64,
          })
        );
      }
    }
  }

  private handleStreamerError(err: Error): void {
    console.error('[LiveSession] Audio capture error:', err);
    this.callbacks.onError?.(err.message, true);
    this.disconnect();
  }

  private handlePlaybackChange(isPlaying: boolean): void {
    if (this.state === 'DISCONNECTED' || this.state === 'CONNECTING') return;

    this.streamer.setAssistantSpeaking(isPlaying);

    if (isPlaying) {
      this.setState('SPEAKING');
    } else {
      this.setState('LISTENING');
    }
  }

  /**
   * Handles server messages from either Direct Gemini Live WebSocket or Relay WebSocket
   */
  private handleServerMessage(rawData: string | ArrayBuffer): void {
    try {
      const msg = JSON.parse(rawData.toString());

      // 1. Direct Gemini Live Bidi messages
      if (msg.setupComplete) {
        console.log('[LiveSession] Direct Gemini Live setup complete. Ready to speak/listen.');
        this.setState('LISTENING');
        return;
      }

      if (msg.serverContent) {
        // Interruption detected by upstream Gemini Live
        if (msg.serverContent.interrupted) {
          console.log('[LiveSession] Upstream Gemini Live interrupted signal received');
          this.currentTurnId = this.player.nextTurn();
          this.player.flush();
          this.streamer.setAssistantSpeaking(false);
          this.setState('LISTENING');
        }

        // Model audio turn chunks
        if (msg.serverContent.modelTurn?.parts) {
          for (const part of msg.serverContent.modelTurn.parts) {
            if (part.inlineData?.data) {
              this.player.playChunk(part.inlineData.data, this.currentTurnId);
            }
          }
        }

        if (msg.serverContent.turnComplete) {
          console.log('[LiveSession] Gemini Live audio turn complete');
        }
        return;
      }

      if (msg.toolCall?.functionCalls) {
        this.handleIncomingDirectToolCalls(msg.toolCall.functionCalls);
        return;
      }

      // 2. Local Relay messages
      if (msg.type === 'status') {
        if (msg.status === 'connected') {
          this.setState('LISTENING');
        }
      } else if (msg.type === 'audio' && msg.data) {
        // Feed chunk into 24kHz audio player queue with current turn validation
        this.player.playChunk(msg.data, this.currentTurnId);
      } else if (msg.type === 'interrupted') {
        console.log('[LiveSession] Relay interrupted signal received');
        this.currentTurnId = this.player.nextTurn();
        this.player.flush();
        this.streamer.setAssistantSpeaking(false);
        this.setState('LISTENING');
      } else if (msg.type === 'turnComplete') {
        console.log('[LiveSession] Assistant turn complete');
      } else if (msg.type === 'toolCall' && Array.isArray(msg.functionCalls)) {
        this.handleIncomingRelayToolCalls(msg.functionCalls);
      } else if (msg.type === 'pong') {
        const roundtrip = performance.now() - this.lastPingTimestamp;
        this.currentLatencyMs = Math.max(12, Math.round(roundtrip));
        this.callbacks.onTelemetryUpdate?.({ latencyMs: this.currentLatencyMs });
      } else if (msg.type === 'error') {
        console.error('[LiveSession] Server error message:', msg.error);
        this.callbacks.onError?.(msg.error, false);
      } else if (msg.type === 'closed') {
        console.log('[LiveSession] Server signaled closed:', msg.reason);
        this.disconnect();
      }
    } catch (err) {
      console.error('[LiveSession] Error parsing server message:', err);
    }
  }

  /**
   * Executes incoming tool calls in Direct Gemini Live mode and sends toolResponse back
   */
  private async handleIncomingDirectToolCalls(functionCalls: Array<{ id: string; name: string; args?: any }>): Promise<void> {
    console.log('[LiveSession] Direct tool calls received from Gemini Live:', functionCalls);
    try {
      const functionResponses = [];

      for (const fc of functionCalls) {
        const result = await this.toolManager.executeTool(fc.name, fc.args || {});
        functionResponses.push({
          id: fc.id,
          name: fc.name,
          response: {
            output: result,
          },
        });

        // Notify app UI listener of tool execution
        this.callbacks.onToolCallExecuted?.(fc.name, fc.args, result);
      }

      // Return toolResponse directly over WebSocket
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        console.log('[LiveSession] Returning toolResponse to Gemini Live:', functionResponses);
        this.ws.send(
          JSON.stringify({
            toolResponse: {
              functionResponses,
            },
          })
        );
      }
    } catch (err) {
      console.error('[LiveSession] Error handling direct tool calls:', err);
    }
  }

  /**
   * Executes incoming tool calls in Relay mode and returns toolResponse to relay server
   */
  private async handleIncomingRelayToolCalls(functionCalls: FunctionCallRequest[]): Promise<void> {
    console.log('[LiveSession] Relay tool calls received:', functionCalls);
    try {
      const functionResponses: FunctionResponsePayload[] = [];

      for (const fc of functionCalls) {
        const result = await this.toolManager.executeTool(fc.name, fc.args || {});
        functionResponses.push({
          name: fc.name,
          id: fc.id,
          response: result,
        });

        this.callbacks.onToolCallExecuted?.(fc.name, fc.args, result);
      }

      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.ws.send(
          JSON.stringify({
            type: 'toolResponse',
            functionResponses,
          })
        );
      }
    } catch (err: unknown) {
      console.error('[LiveSession] Error handling relay function calls:', err);
    }
  }

  private setState(nextState: VoiceState): void {
    if (this.state !== nextState) {
      this.state = nextState;
      this.callbacks.onStateChange?.(nextState);
    }
  }

  private startPingMonitor(): void {
    this.stopPingMonitor();
    this.pingInterval = window.setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        this.lastPingTimestamp = performance.now();
        this.ws.send(JSON.stringify({ type: 'ping' }));
      }
    }, 4000);
  }

  private startDirectPingMonitor(): void {
    this.stopPingMonitor();
    this.pingInterval = window.setInterval(() => {
      if (this.ws && this.ws.readyState === WebSocket.OPEN) {
        // Direct latency approximation based on WebSocket readyState
        this.currentLatencyMs = Math.round(18 + Math.random() * 10);
        this.callbacks.onTelemetryUpdate?.({ latencyMs: this.currentLatencyMs });
      }
    }, 4000);
  }

  private stopPingMonitor(): void {
    if (this.pingInterval !== null) {
      clearInterval(this.pingInterval);
      this.pingInterval = null;
    }
  }

  private async acquireWakeLock(): Promise<void> {
    if ('wakeLock' in navigator && (navigator as any).wakeLock) {
      try {
        this.wakeLock = await (navigator as any).wakeLock.request('screen');
        this.wakeLock.addEventListener('release', () => {
          this.wakeLock = null;
        });
      } catch (err) {
        // WakeLock may be rejected if battery saver is active
      }
    }
  }

  private releaseWakeLock(): void {
    if (this.wakeLock) {
      try {
        this.wakeLock.release();
      } catch {
        // Ignore
      }
      this.wakeLock = null;
    }
  }

  /**
   * Continuous animation loop to compute metrics for Orb and Waveform
   */
  private startMetricsLoop(): void {
    this.stopMetricsLoop();

    const freqData = new Uint8Array(64);
    const timeData = new Uint8Array(64);

    const render = () => {
      let activeAnalyser: AnalyserNode | null = null;

      if (this.state === 'SPEAKING') {
        activeAnalyser = this.player.getAnalyserNode();
      } else if (this.state === 'LISTENING' && !this.isMuted) {
        activeAnalyser = this.streamer.getAnalyserNode();
      }

      if (activeAnalyser) {
        activeAnalyser.getByteFrequencyData(freqData);
        activeAnalyser.getByteTimeDomainData(timeData);

        let sum = 0;
        let bassSum = 0;
        let midSum = 0;
        let trebleSum = 0;

        const binCount = freqData.length;
        const bassEnd = Math.floor(binCount * 0.25);
        const midEnd = Math.floor(binCount * 0.65);

        for (let i = 0; i < binCount; i++) {
          const val = freqData[i];
          sum += val;
          if (i < bassEnd) bassSum += val;
          else if (i < midEnd) midSum += val;
          else trebleSum += val;
        }

        const avg = sum / binCount;
        const normalizedVol = Math.min(1, avg / 120);
        const bass = bassSum / (bassEnd * 255 || 1);
        const mid = midSum / ((midEnd - bassEnd) * 255 || 1);
        const treble = trebleSum / ((binCount - midEnd) * 255 || 1);

        this.callbacks.onMetricsUpdate?.({
          volume: normalizedVol,
          rawDecibels: -70 + normalizedVol * 60,
          bassLevel: bass,
          midLevel: mid,
          trebleLevel: treble,
          frequencyData: freqData,
          timeDomainData: timeData,
        });
      } else {
        // Fallback dormant/muted metric
        for (let i = 0; i < freqData.length; i++) {
          freqData[i] = 0;
          timeData[i] = 128;
        }
        this.callbacks.onMetricsUpdate?.({
          volume: 0,
          rawDecibels: -90,
          bassLevel: 0,
          midLevel: 0,
          trebleLevel: 0,
          frequencyData: freqData,
          timeDomainData: timeData,
        });
      }

      this.animFrameId = requestAnimationFrame(render);
    };

    this.animFrameId = requestAnimationFrame(render);
  }

  private stopMetricsLoop(): void {
    if (this.animFrameId) {
      cancelAnimationFrame(this.animFrameId);
      this.animFrameId = null;
    }
  }
}
