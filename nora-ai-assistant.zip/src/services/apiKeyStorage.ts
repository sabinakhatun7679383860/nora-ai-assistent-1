/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const STORAGE_KEY = 'nora_gemini_api_key';

/**
 * Retrieves the stored Gemini API key from local browser storage.
 * The key is kept strictly client-side on this device and never logged or leaked.
 */
export function getStoredApiKey(): string | null {
  try {
    if (typeof localStorage !== 'undefined') {
      const key = localStorage.getItem(STORAGE_KEY);
      if (key) {
        const trimmed = key.trim();
        if (trimmed.length > 0) return trimmed;
      }
    }
  } catch (err) {
    // Storage access might be restricted in some sandbox modes
  }

  try {
    const envKey = (import.meta as any)?.env?.VITE_GEMINI_API_KEY;
    if (typeof envKey === 'string' && envKey.trim().length > 0) {
      return envKey.trim();
    }
  } catch {
    // Ignore env read failure
  }

  return null;
}

/**
 * Saves the Gemini API key into local browser storage.
 */
export function setStoredApiKey(apiKey: string): void {
  try {
    const cleanKey = apiKey.trim();
    if (cleanKey) {
      localStorage.setItem(STORAGE_KEY, cleanKey);
    } else {
      localStorage.removeItem(STORAGE_KEY);
    }
  } catch (err) {
    console.warn('[Storage] Unable to save API key to localStorage');
  }
}

/**
 * Clears the stored Gemini API key from local browser storage.
 */
export function removeStoredApiKey(): void {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch (err) {
    console.warn('[Storage] Unable to remove API key from localStorage');
  }
}

/**
 * Checks if a valid non-empty API key is present in local storage.
 */
export function hasStoredApiKey(): boolean {
  return getStoredApiKey() !== null;
}

/**
 * Validates a Gemini API key securely:
 * 1. Checks local Express / Vite proxy endpoint (/api/validate-key) if running in server mode.
 * 2. If running statically on GitHub Pages or if local proxy is unavailable, validates directly against Google Gemini REST API.
 */
export async function validateGeminiApiKey(apiKey: string): Promise<{ valid: boolean; error?: string }> {
  const cleanKey = apiKey?.trim();
  if (!cleanKey || cleanKey.length < 10) {
    return { valid: false, error: 'The provided API key is too short or empty.' };
  }

  // 1. Try local server validation endpoint first
  try {
    const res = await fetch('/api/validate-key', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ apiKey: cleanKey }),
    });

    // If server responded with JSON
    if (res.headers.get('content-type')?.includes('application/json')) {
      const data = await res.json();
      if (res.ok && data.valid) {
        return { valid: true };
      }
      if (res.status === 400 && data.error) {
        return { valid: false, error: data.error };
      }
    }
  } catch {
    // Server not running or static host (GitHub Pages 404) - proceed to direct validation
  }

  // 2. Direct browser validation via Google Gemini API (CORS enabled)
  try {
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models?key=${encodeURIComponent(cleanKey)}`,
      {
        method: 'GET',
        headers: {
          'Accept': 'application/json',
        },
      }
    );

    const data = await res.json();
    if (res.ok && (Array.isArray(data.models) || data.models)) {
      return { valid: true };
    }

    let errorMsg = data?.error?.message || 'Invalid Gemini API key or unauthorized.';
    if (errorMsg.includes('quota') || errorMsg.includes('RESOURCE_EXHAUSTED')) {
      return { valid: false, error: 'Gemini API quota exceeded. Please verify your billing/plan in Google AI Studio.' };
    }
    if (errorMsg.includes('API_KEY_INVALID') || errorMsg.includes('API key not valid')) {
      return { valid: false, error: 'Invalid API key. Please generate a new key at https://aistudio.google.com/apikey' };
    }
    return { valid: false, error: errorMsg };
  } catch (netErr: any) {
    return {
      valid: false,
      error: 'Network connection error while verifying Gemini API key. Please check your internet connection.',
    };
  }
}

/**
 * Returns a secure masked representation of the API key for UI display (e.g. AIzaSy...9xK1)
 */
export function maskApiKey(apiKey: string | null): string {
  if (!apiKey) return 'None configured';
  const clean = apiKey.trim();
  if (clean.length <= 8) return '••••••••';
  const prefix = clean.slice(0, 6);
  const suffix = clean.slice(-4);
  return `${prefix}••••••••${suffix}`;
}
