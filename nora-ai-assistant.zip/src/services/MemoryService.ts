/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  NoraMemory,
  NoraMemoryCategory,
  NoraProject,
  NoraBrainSettings,
  MemorySearchResult,
} from '../types/memory';
import {
  initializeMemoryStorage,
  dbGetAllMemories,
  dbGetMemoryById,
  dbSaveMemory,
  dbDeleteMemory,
  dbClearAllMemories,
  dbGetAllProjects,
  dbGetProjectById,
  dbSaveProject,
  dbDeleteProject,
  dbGetBrainSettings,
  dbSaveBrainSettings,
  isSensitiveContent,
} from './memoryStorage';

/**
 * Calculates simple token overlap similarity (Jaccard similarity index)
 */
function calculateTextSimilarity(textA: string, textB: string): number {
  const cleanTokens = (str: string) =>
    str
      .toLowerCase()
      .replace(/[^\w\s\u0980-\u09FF\u0900-\u097F]/g, ' ')
      .split(/\s+/)
      .filter((t) => t.length > 1);

  const tokensA = new Set(cleanTokens(textA));
  const tokensB = new Set(cleanTokens(textB));

  if (tokensA.size === 0 || tokensB.size === 0) return 0;

  let intersectionCount = 0;
  for (const token of tokensA) {
    if (tokensB.has(token)) {
      intersectionCount++;
    }
  }

  const unionSize = new Set([...tokensA, ...tokensB]).size;
  return intersectionCount / unionSize;
}

/**
 * Extracts keywords for ranking and search
 */
function extractKeywords(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^\w\s\u0980-\u09FF\u0900-\u097F]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length > 2);
}

export class MemoryService {
  private static instance: MemoryService;

  private constructor() {}

  public static getInstance(): MemoryService {
    if (!MemoryService.instance) {
      MemoryService.instance = new MemoryService();
    }
    return MemoryService.instance;
  }

  /**
   * Initializes the persistent memory DB
   */
  public async initializeMemoryDB(): Promise<void> {
    try {
      await initializeMemoryStorage();
    } catch (err) {
      console.warn('[MemoryService] Memory DB initialization encountered non-fatal error, running in memory-safe mode:', err);
    }
  }

  /**
   * Gets current Brain settings (Level 1, Level 2, Level 3, Master)
   */
  public getBrainSettings(): NoraBrainSettings {
    return dbGetBrainSettings();
  }

  /**
   * Updates Brain settings
   */
  public async updateBrainSettings(settings: Partial<NoraBrainSettings>): Promise<NoraBrainSettings> {
    return dbSaveBrainSettings(settings);
  }

  /**
   * Analyzes if a message contains information worth storing.
   * Filters out sensitive info, temporary status, or noise.
   */
  public shouldRemember(message: string): {
    remember: boolean;
    reason?: string;
    isSensitive?: boolean;
    category?: NoraMemoryCategory;
    importance?: number;
    extractedContent?: string;
  } {
    if (!message || typeof message !== 'string') {
      return { remember: false, reason: 'Empty message' };
    }

    const trimmed = message.trim();
    if (trimmed.length < 3) {
      return { remember: false, reason: 'Message too short' };
    }

    // 1. Check for sensitive private credentials
    const sensitiveCheck = isSensitiveContent(trimmed);
    if (sensitiveCheck.sensitive) {
      return {
        remember: false,
        isSensitive: true,
        reason: `Privacy Guard: Refusing to store sensitive data. ${sensitiveCheck.reason}`,
      };
    }

    const lower = trimmed.toLowerCase();

    // 2. Reject temporary conversation status (e.g. "I am busy today", "আজ আমি ব্যস্ত")
    const isTemporary =
      /(আজ আমি ব্যস্ত|এখন ব্যস্ত|একটু পর আসছি|আজকের আবহাওয়া|কটা বাজে|আজকে বৃষ্টি|today i am busy|i am busy right now|feeling sleepy today|what time is it|will be right back)/i.test(
        trimmed
      );
    if (isTemporary && !/(মনে রাখ|remember|याद रख)/i.test(trimmed)) {
      return {
        remember: false,
        reason: 'Temporary status or conversational pleasantry without persistent value.',
      };
    }

    // 3. Explicit memory instructions (Bengali, Hindi, English)
    const isExplicit =
      /(মনে রাখো|মনে রাখবে|মনে রেখো|এটা মনে রাখ|এটা মনে রাখবে|মনে রাখো যে|remember this|remember that|keep in mind|never forget|याद रखो|याद रखना कि|इसे याद रखो)/i.test(
        trimmed
      );

    // 4. Language preference declarations
    const isLanguagePref =
      /(বাংলায় উত্তর দাও|বাংলায় কথা বলো|বাংলা পছন্দ করি|speak in bengali|reply in bengali|हिंदी में बात करो|हिंदी में बोलो|speak in hindi|always speak in)/i.test(
        trimmed
      );

    // 5. User preference declarations
    const isUserPref =
      /(আমার নাম|আমি পছন্দ করি|আমার প্রিয়|আমার ফেভারিট|my name is|i like|i prefer|my favorite|मेरा नाम|मुझे पसंद है)/i.test(
        trimmed
      );

    // 6. Project definitions
    const isProjectFact =
      /(আমার project|nora project|প্রজেক্ট|my project|the project needs|our app|আমার ওয়েবসাইট|website|project uses)/i.test(
        trimmed
      );

    if (isExplicit) {
      const extracted = this.extractCleanContent(trimmed);
      let cat: NoraMemoryCategory = 'instruction';
      if (isLanguagePref) cat = 'language';
      else if (isProjectFact) cat = 'project';
      else if (isUserPref) cat = 'preference';

      return {
        remember: true,
        reason: 'Explicit user memory instruction.',
        category: cat,
        importance: 5,
        extractedContent: extracted,
      };
    }

    if (isLanguagePref) {
      return {
        remember: true,
        reason: 'Persistent language preference detected.',
        category: 'language',
        importance: 5,
        extractedContent: this.extractCleanContent(trimmed),
      };
    }

    if (isUserPref) {
      return {
        remember: true,
        reason: 'Persistent user preference or identity fact.',
        category: 'preference',
        importance: 4,
        extractedContent: this.extractCleanContent(trimmed),
      };
    }

    if (isProjectFact) {
      return {
        remember: true,
        reason: 'Relevant project architecture or feature specification.',
        category: 'project',
        importance: 4,
        extractedContent: this.extractCleanContent(trimmed),
      };
    }

    return { remember: false, reason: 'Standard conversational turn.' };
  }

  /**
   * Cleans conversational prefix boilerplate from memory text
   */
  private extractCleanContent(message: string): string {
    let clean = message.trim();

    // Strip explicit prefixes
    const prefixes = [
      /^(নোরা|nora|hey nora|নূরা)[,\s]+/i,
      /^(এটা\s+)?(মনে\s+রাখো|মনে\s+রাখবে|মনে\s+রেখো)(\s+যে)?[,:\s]*/i,
      /^(please\s+)?(remember\s+(this|that)?(\s+that)?|keep\s+in\s+mind(\s+that)?)[,:\s]*/i,
      /^(इसे\s+)?(याद\s+रखो|याद\s+रखना)(\s+कि)?[,:\s]*/i,
      /^(আমার\s+মনে\s+রেখো|note\s+that)[,:\s]*/i,
    ];

    for (const regex of prefixes) {
      clean = clean.replace(regex, '').trim();
    }

    return clean || message.trim();
  }

  /**
   * Extracts structured memory candidate from raw message
   */
  public extractMemory(message: string): {
    content: string;
    category: NoraMemoryCategory;
    importance: number;
    projectId?: string;
  } | null {
    const analysis = this.shouldRemember(message);
    if (!analysis.remember || analysis.isSensitive) {
      return null;
    }

    return {
      content: analysis.extractedContent || message.trim(),
      category: analysis.category || 'other',
      importance: analysis.importance || 3,
    };
  }

  /**
   * Finds an existing memory that closely matches or conflicts with the new content
   */
  public async findDuplicateMemory(
    content: string,
    category?: NoraMemoryCategory
  ): Promise<NoraMemory | null> {
    const allMemories = await dbGetAllMemories();
    const cleanContent = content.trim().toLowerCase();

    for (const mem of allMemories) {
      const existingClean = mem.content.trim().toLowerCase();

      // Exact match
      if (existingClean === cleanContent) {
        return mem;
      }

      // High text similarity
      const sim = calculateTextSimilarity(mem.content, content);
      if (sim > 0.65) {
        return mem;
      }

      // Preference / language collision: e.g. "User prefers Bengali" vs "Now speak in English"
      if (category && (category === 'language' || category === 'preference') && mem.category === category) {
        if (
          (cleanContent.includes('বাংলা') && existingClean.includes('english')) ||
          (cleanContent.includes('english') && existingClean.includes('বাংলা')) ||
          (cleanContent.includes('hindi') && existingClean.includes('বাংলা')) ||
          (cleanContent.includes('हिंदी') && existingClean.includes('english'))
        ) {
          return mem; // Conflict: update old language preference
        }
      }
    }

    return null;
  }

  /**
   * Saves or updates a memory with deduplication and conflict resolution
   */
  public async saveMemory(memoryData: Partial<NoraMemory> & { content: string }): Promise<NoraMemory> {
    const settings = this.getBrainSettings();
    if (!settings.memoryEnabled || !settings.longTermMemory) {
      throw new Error('Long-Term Memory is currently disabled in NORA Brain Settings.');
    }

    const cleanContent = memoryData.content.trim();
    if (!cleanContent) {
      throw new Error('Memory content cannot be empty.');
    }

    // Safety guard
    const sensitive = isSensitiveContent(cleanContent);
    if (sensitive.sensitive) {
      throw new Error(`Privacy Guard: ${sensitive.reason} Credentials and secrets cannot be stored.`);
    }

    const category: NoraMemoryCategory = memoryData.category || 'other';
    const now = new Date().toISOString();

    // Check for duplicates / updates
    const existingDuplicate = await this.findDuplicateMemory(cleanContent, category);

    if (existingDuplicate) {
      // Update existing memory (Latest explicit instruction > older memory)
      const updated: NoraMemory = {
        ...existingDuplicate,
        content: cleanContent,
        category: category || existingDuplicate.category,
        importance: memoryData.importance ?? Math.max(existingDuplicate.importance, 3),
        updatedAt: now,
        lastUsedAt: now,
        source: memoryData.source || 'user',
        projectId: memoryData.projectId ?? existingDuplicate.projectId,
        projectName: memoryData.projectName ?? existingDuplicate.projectName,
      };

      await dbSaveMemory(updated);
      console.log(`[MemoryService] Updated existing memory ${updated.id}: "${updated.content}"`);
      return updated;
    }

    // Create new memory
    const newMemory: NoraMemory = {
      id: memoryData.id || `mem_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      content: cleanContent,
      category,
      importance: memoryData.importance ?? 3,
      createdAt: memoryData.createdAt || now,
      updatedAt: now,
      lastUsedAt: now,
      source: memoryData.source || 'user',
      projectId: memoryData.projectId,
      projectName: memoryData.projectName,
      tags: memoryData.tags || [],
    };

    await dbSaveMemory(newMemory);
    console.log(`[MemoryService] Created new memory ${newMemory.id}: "${newMemory.content}" (${newMemory.category})`);
    return newMemory;
  }

  /**
   * Retrieves single memory by ID
   */
  public async getMemory(id: string): Promise<NoraMemory | null> {
    return dbGetMemoryById(id);
  }

  /**
   * Retrieves all saved memories
   */
  public async getAllMemories(): Promise<NoraMemory[]> {
    return dbGetAllMemories();
  }

  /**
   * Full-text search for settings UI and queries
   */
  public async searchMemories(query: string): Promise<NoraMemory[]> {
    const all = await dbGetAllMemories();
    if (!query || query.trim() === '') {
      return all;
    }

    const cleanQuery = query.toLowerCase().trim();
    const queryTokens = extractKeywords(cleanQuery);

    return all.filter((mem) => {
      const contentLower = mem.content.toLowerCase();
      const catLower = mem.category.toLowerCase();
      const projLower = (mem.projectName || '').toLowerCase();

      // Direct substring match
      if (contentLower.includes(cleanQuery) || catLower.includes(cleanQuery) || projLower.includes(cleanQuery)) {
        return true;
      }

      // Keyword token match
      return queryTokens.some((tok) => contentLower.includes(tok) || catLower.includes(tok) || projLower.includes(tok));
    });
  }

  /**
   * Retrieves only relevant memories for the AI prompt context.
   * Ranks by relevance score + importance weight + recency.
   */
  public async getRelevantMemories(query: string, limit: number = 4): Promise<NoraMemory[]> {
    const settings = this.getBrainSettings();
    if (!settings.memoryEnabled || !settings.longTermMemory) {
      return [];
    }

    const all = await dbGetAllMemories();
    if (all.length === 0) return [];

    if (!query || query.trim().length === 0) {
      // Return top priority preferences
      return all.sort((a, b) => b.importance - a.importance).slice(0, limit);
    }

    const cleanQuery = query.toLowerCase().trim();
    const queryTokens = extractKeywords(cleanQuery);
    const now = Date.now();

    const scored: MemorySearchResult[] = [];

    for (const mem of all) {
      const contentLower = mem.content.toLowerCase();
      let matchScore = 0;
      const matchedKeywords: string[] = [];

      // Exact phrase match
      if (contentLower.includes(cleanQuery)) {
        matchScore += 10;
      }

      // Token matches
      for (const tok of queryTokens) {
        if (contentLower.includes(tok)) {
          matchScore += 3;
          matchedKeywords.push(tok);
        }
      }

      // Category relevance boost
      if (
        (cleanQuery.includes('language') || cleanQuery.includes('ভাষা') || cleanQuery.includes('বাংলা') || cleanQuery.includes('hindi')) &&
        mem.category === 'language'
      ) {
        matchScore += 6;
      }

      if (
        (cleanQuery.includes('project') || cleanQuery.includes('প্রজেক্ট') || cleanQuery.includes('nora')) &&
        (mem.category === 'project' || mem.projectId)
      ) {
        matchScore += 6;
      }

      // Always include top-tier language/system preferences with modest base score
      if (mem.category === 'language' && mem.importance >= 4) {
        matchScore += 2;
      }

      if (matchScore > 0) {
        // Importance factor (1 to 5)
        const importanceBonus = mem.importance * 1.5;

        // Recency decay factor (memories used recently get slight boost)
        const lastUsedMs = new Date(mem.lastUsedAt || mem.updatedAt).getTime();
        const daysSinceUsed = Math.max(0, (now - lastUsedMs) / (1000 * 60 * 60 * 24));
        const recencyBonus = Math.max(0, 3 - daysSinceUsed * 0.1);

        const totalScore = matchScore + importanceBonus + recencyBonus;
        scored.push({ memory: mem, score: totalScore, matchedKeywords });
      }
    }

    // Sort by score descending
    scored.sort((a, b) => b.score - a.score);

    const topResults = scored.slice(0, limit).map((s) => s.memory);

    // Update lastUsedAt timestamp asynchronously
    const updateTime = new Date().toISOString();
    for (const mem of topResults) {
      mem.lastUsedAt = updateTime;
      dbSaveMemory(mem).catch(() => {});
    }

    return topResults;
  }

  /**
   * Updates an existing memory
   */
  public async updateMemory(id: string, updates: Partial<NoraMemory>): Promise<NoraMemory | null> {
    const existing = await dbGetMemoryById(id);
    if (!existing) return null;

    if (updates.content) {
      const sensitive = isSensitiveContent(updates.content);
      if (sensitive.sensitive) {
        throw new Error(`Privacy Guard: ${sensitive.reason}`);
      }
    }

    const updated: NoraMemory = {
      ...existing,
      ...updates,
      updatedAt: new Date().toISOString(),
    };

    await dbSaveMemory(updated);
    return updated;
  }

  /**
   * Deletes a memory by ID
   */
  public async deleteMemory(id: string): Promise<boolean> {
    return dbDeleteMemory(id);
  }

  /**
   * Deletes matching memory by query text (e.g. "বাংলা পছন্দ করি ভুলে যাও")
   */
  public async forgetMatchingMemory(query: string): Promise<{ deleted: boolean; memory?: NoraMemory; count: number }> {
    const all = await dbGetAllMemories();
    const clean = query.toLowerCase().trim();

    let bestMatch: NoraMemory | null = null;
    let highestSim = 0;

    for (const mem of all) {
      const memLower = mem.content.toLowerCase();
      if (memLower.includes(clean) || clean.includes(memLower)) {
        bestMatch = mem;
        break;
      }
      const sim = calculateTextSimilarity(mem.content, query);
      if (sim > highestSim && sim > 0.4) {
        highestSim = sim;
        bestMatch = mem;
      }
    }

    if (bestMatch) {
      await dbDeleteMemory(bestMatch.id);
      return { deleted: true, memory: bestMatch, count: 1 };
    }

    return { deleted: false, count: 0 };
  }

  /**
   * Clears all saved memories
   */
  public async clearAllMemories(): Promise<boolean> {
    return dbClearAllMemories();
  }

  // -------------------------------------------------------------
  // LEVEL 3 — PROJECT BRAIN METHODS
  // -------------------------------------------------------------

  public async getAllProjects(): Promise<NoraProject[]> {
    return dbGetAllProjects();
  }

  public async getProject(projectId: string): Promise<NoraProject | null> {
    return dbGetProjectById(projectId);
  }

  public async findProjectByName(name: string): Promise<NoraProject | null> {
    const projects = await dbGetAllProjects();
    const cleanName = name.toLowerCase().trim();

    for (const p of projects) {
      if (p.name.toLowerCase() === cleanName || p.name.toLowerCase().includes(cleanName) || cleanName.includes(p.name.toLowerCase())) {
        return p;
      }
    }
    return null;
  }

  public async saveProject(project: Partial<NoraProject> & { name: string }): Promise<NoraProject> {
    const now = new Date().toISOString();
    const existing = project.id ? await dbGetProjectById(project.id) : await this.findProjectByName(project.name);

    if (existing) {
      const updated: NoraProject = {
        ...existing,
        ...project,
        updatedAt: now,
        lastAccessedAt: now,
      };
      await dbSaveProject(updated);
      return updated;
    }

    const newProject: NoraProject = {
      id: project.id || `proj_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      name: project.name,
      description: project.description || '',
      goals: project.goals || [],
      features: project.features || [],
      technicalDecisions: project.technicalDecisions || [],
      importantInstructions: project.importantInstructions || [],
      currentStatus: project.currentStatus || 'In Planning',
      knownIssues: project.knownIssues || [],
      futurePlans: project.futurePlans || [],
      createdAt: now,
      updatedAt: now,
      lastAccessedAt: now,
    };

    await dbSaveProject(newProject);
    return newProject;
  }

  public async deleteProject(projectId: string): Promise<boolean> {
    return dbDeleteProject(projectId);
  }

  public async saveProjectMemory(projectId: string, memory: Partial<NoraMemory> & { content: string }): Promise<NoraMemory> {
    const proj = await dbGetProjectById(projectId);
    return this.saveMemory({
      ...memory,
      category: 'project',
      projectId,
      projectName: proj?.name || 'Project',
    });
  }

  public async getProjectMemories(projectId: string): Promise<NoraMemory[]> {
    const all = await dbGetAllMemories();
    return all.filter((m) => m.projectId === projectId);
  }

  public async deleteProjectMemory(projectId: string, memoryId: string): Promise<boolean> {
    const mem = await dbGetMemoryById(memoryId);
    if (mem && mem.projectId === projectId) {
      return dbDeleteMemory(memoryId);
    }
    return false;
  }

  /**
   * Formats compact memory & project context for the AI prompt
   */
  public async buildMemoryContext(query: string, activeProjectId?: string): Promise<string> {
    const settings = this.getBrainSettings();
    if (!settings.memoryEnabled) {
      return '';
    }

    const parts: string[] = [];

    // 1. Long-Term Memories
    if (settings.longTermMemory) {
      const relevant = await this.getRelevantMemories(query, 4);
      if (relevant.length > 0) {
        parts.push(
          'RELEVANT USER MEMORIES & PREFERENCES:\n' +
            relevant.map((m) => `- ${m.content} [${m.category}]`).join('\n')
        );
      }
    }

    // 2. Project Brain Context
    if (settings.projectBrain) {
      let targetProject: NoraProject | null = null;

      if (activeProjectId) {
        targetProject = await dbGetProjectById(activeProjectId);
      }

      if (!targetProject) {
        // Detect if query mentions a project (e.g. "NORA", "my website", "project")
        const lowerQuery = query.toLowerCase();
        if (lowerQuery.includes('nora') || lowerQuery.includes('নোরা') || lowerQuery.includes('project') || lowerQuery.includes('প্রজেক্ট')) {
          targetProject = await this.findProjectByName('NORA AI Assistant');
        }
      }

      if (targetProject) {
        const projContext = [
          `ACTIVE PROJECT BRAIN: ${targetProject.name}`,
          `Status: ${targetProject.currentStatus}`,
          `Key Features: ${targetProject.features.slice(0, 5).join(', ')}`,
          `Tech Decisions: ${targetProject.technicalDecisions.slice(0, 3).join(', ')}`,
        ];
        if (targetProject.importantInstructions.length > 0) {
          projContext.push(`Project Directives: ${targetProject.importantInstructions.slice(0, 2).join('; ')}`);
        }
        parts.push(projContext.join('\n'));
      }
    }

    return parts.join('\n\n');
  }
}

export const defaultMemoryService = MemoryService.getInstance();
