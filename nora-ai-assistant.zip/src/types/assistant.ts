/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type VoiceState = 'DISCONNECTED' | 'CONNECTING' | 'LISTENING' | 'SPEAKING';

export type AssistantVisualMode =
  | 'idle'
  | 'listening'
  | 'processing'
  | 'speaking'
  | 'tool_executing'
  | 'error';

export interface AudioMetrics {
  volume: number; // 0.0 to 1.0 normalized
  rawDecibels: number; // dB value from analyser
  bassLevel: number; // 0.0 to 1.0
  midLevel: number; // 0.0 to 1.0
  trebleLevel: number; // 0.0 to 1.0
  frequencyData: Uint8Array;
  timeDomainData: Uint8Array;
}

export interface AssistantConfig {
  sampleRate: number; // typically 16000 or 24000 Hz for Gemini Live
  noiseSuppression: boolean;
  echoCancellation: boolean;
  autoGainControl: boolean;
}

export interface LiveConnectionTelemetry {
  state: VoiceState;
  visualMode: AssistantVisualMode;
  durationSeconds: number;
  inputSampleRate: number;
  outputSampleRate: number;
  latencyMs: number;
  isMuted: boolean;
}

