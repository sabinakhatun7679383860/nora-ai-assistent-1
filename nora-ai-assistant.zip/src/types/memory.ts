/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type NoraMemoryCategory =
  | 'preference'
  | 'language'
  | 'project'
  | 'instruction'
  | 'useful_fact'
  | 'workflow'
  | 'other';

export type NoraMemorySource = 'user' | 'conversation';

export interface NoraMemory {
  id: string;
  content: string;
  category: NoraMemoryCategory;
  importance: number; // 1 to 5
  createdAt: string; // ISO 8601 string
  updatedAt: string; // ISO 8601 string
  lastUsedAt: string; // ISO 8601 string
  source: NoraMemorySource;
  projectId?: string;
  projectName?: string;
  tags?: string[];
}

export interface NoraProject {
  id: string;
  name: string; // e.g. "NORA AI Assistant", "My website", "My API", "School project"
  description: string;
  goals: string[];
  features: string[];
  technicalDecisions: string[];
  importantInstructions: string[];
  currentStatus: string;
  knownIssues: string[];
  futurePlans: string[];
  createdAt: string;
  updatedAt: string;
  lastAccessedAt: string;
}

export interface NoraBrainSettings {
  memoryEnabled: boolean; // Master Memory ON/OFF
  shortTermMemory: boolean; // Level 1 ON/OFF
  longTermMemory: boolean; // Level 2 ON/OFF
  projectBrain: boolean; // Level 3 ON/OFF
  autoRemember: boolean; // Smart automatic memory detection
}

export interface ConversationTurn {
  id: string;
  speaker: 'user' | 'nora';
  text: string;
  timestamp: number;
  detectedLanguage?: 'bn' | 'hi' | 'en';
}

export interface MemorySearchResult {
  memory: NoraMemory;
  score: number;
  matchedKeywords: string[];
}
