/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, useCallback } from 'react';
import { AudioMetrics, VoiceState } from '../types/assistant';

const FFT_SIZE = 128; // 64 frequency bins for fast responsive rendering

export function useAudioAnalyzer(state: VoiceState, isMuted: boolean) {
  const [metrics, setMetrics] = useState<AudioMetrics>({
    volume: 0,
    rawDecibels: -100,
    bassLevel: 0,
    midLevel: 0,
    trebleLevel: 0,
    frequencyData: new Uint8Array(FFT_SIZE / 2),
    timeDomainData: new Uint8Array(FFT_SIZE / 2),
  });

  const [micPermission, setMicPermission] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const animFrameIdRef = useRef<number | null>(null);

  // Clean up existing audio resources
  const cleanupAudio = useCallback(() => {
    if (animFrameIdRef.current) {
      cancelAnimationFrame(animFrameIdRef.current);
      animFrameIdRef.current = null;
    }

    if (mediaStreamRef.current) {
      mediaStreamRef.current.getTracks().forEach((track) => track.stop());
      mediaStreamRef.current = null;
    }

    if (audioContextRef.current && audioContextRef.current.state !== 'closed') {
      audioContextRef.current.close().catch(() => {});
      audioContextRef.current = null;
    }

    analyserRef.current = null;
  }, []);

  // Initialize microphone and Web Audio analyser node
  const startMicrophone = useCallback(async () => {
    try {
      cleanupAudio();
      setErrorMessage(null);

      // Check if mediaDevices is supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        throw new Error('Microphone access is not supported on this browser.');
      }

      const stream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      mediaStreamRef.current = stream;
      setMicPermission('granted');

      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      const ctx = new AudioCtx();
      audioContextRef.current = ctx;

      if (ctx.state === 'suspended') {
        await ctx.resume();
      }

      const source = ctx.createMediaStreamSource(stream);
      const analyser = ctx.createAnalyser();
      analyser.fftSize = FFT_SIZE;
      analyser.smoothingTimeConstant = 0.8;
      source.connect(analyser);
      analyserRef.current = analyser;

      return true;
    } catch (err: unknown) {
      console.warn('Microphone initialization warning:', err);
      const msg = err instanceof Error ? err.message : 'Microphone permission denied or unavailable';
      setMicPermission('denied');
      setErrorMessage(msg);
      return false;
    }
  }, [cleanupAudio]);

  // Main animation loop for audio extraction & synthetic fallback
  useEffect(() => {
    const freqData = new Uint8Array(FFT_SIZE / 2);
    const timeData = new Uint8Array(FFT_SIZE / 2);

    let phase = 0;

    const render = () => {
      phase += 0.05;

      if (state === 'DISCONNECTED') {
        // Subtle dormant idle breathing
        const idleVolume = 0.02 + Math.sin(phase * 0.5) * 0.015;
        for (let i = 0; i < freqData.length; i++) {
          freqData[i] = Math.max(0, Math.floor((Math.sin(phase + i * 0.2) * 0.5 + 0.5) * 12));
          timeData[i] = 128 + Math.floor(Math.sin(phase * 0.8 + i * 0.1) * 3);
        }

        setMetrics({
          volume: idleVolume,
          rawDecibels: -90,
          bassLevel: idleVolume * 0.5,
          midLevel: idleVolume * 0.3,
          trebleLevel: idleVolume * 0.2,
          frequencyData: freqData,
          timeDomainData: timeData,
        });
      } else if (state === 'CONNECTING') {
        // Pulsing quantum oscillation
        const connVolume = 0.35 + Math.sin(phase * 3.5) * 0.2;
        for (let i = 0; i < freqData.length; i++) {
          const wave = Math.sin(phase * 2 + i * 0.35);
          freqData[i] = Math.max(0, Math.floor((wave * 0.5 + 0.5) * 140));
          timeData[i] = 128 + Math.floor(Math.sin(phase * 3 + i * 0.4) * 25);
        }

        setMetrics({
          volume: connVolume,
          rawDecibels: -45,
          bassLevel: 0.4,
          midLevel: 0.3,
          trebleLevel: 0.2,
          frequencyData: freqData,
          timeDomainData: timeData,
        });
      } else if (state === 'SPEAKING') {
        // Simulated AI voice synthesis audio dynamics (harmonic multi-frequency ripples)
        const speakingVol = 0.45 + Math.sin(phase * 2.2) * 0.25 + Math.sin(phase * 5.1) * 0.15;
        for (let i = 0; i < freqData.length; i++) {
          const harmonic1 = Math.sin(phase * 4 + i * 0.28) * 0.5 + 0.5;
          const harmonic2 = Math.cos(phase * 2.5 + i * 0.45) * 0.5 + 0.5;
          const envelope = Math.sin((i / freqData.length) * Math.PI);
          freqData[i] = Math.floor((harmonic1 * 0.6 + harmonic2 * 0.4) * envelope * 220 * (speakingVol + 0.2));
          timeData[i] = 128 + Math.floor(Math.sin(phase * 4.5 + i * 0.3) * speakingVol * 50);
        }

        setMetrics({
          volume: Math.max(0.1, speakingVol),
          rawDecibels: -24 + speakingVol * 15,
          bassLevel: 0.6 * speakingVol,
          midLevel: 0.8 * speakingVol,
          trebleLevel: 0.5 * speakingVol,
          frequencyData: freqData,
          timeDomainData: timeData,
        });
      } else if (state === 'LISTENING') {
        if (isMuted) {
          // Muted state: flatline with subtle glow
          for (let i = 0; i < freqData.length; i++) {
            freqData[i] = 0;
            timeData[i] = 128;
          }
          setMetrics({
            volume: 0,
            rawDecibels: -100,
            bassLevel: 0,
            midLevel: 0,
            trebleLevel: 0,
            frequencyData: freqData,
            timeDomainData: timeData,
          });
        } else if (analyserRef.current) {
          // Real live microphone input analysis
          analyserRef.current.getByteFrequencyData(freqData);
          analyserRef.current.getByteTimeDomainData(timeData);

          // Calculate average energy
          let sum = 0;
          let bassSum = 0;
          let midSum = 0;
          let trebleSum = 0;

          const binCount = freqData.length;
          const bassEnd = Math.floor(binCount * 0.2);
          const midEnd = Math.floor(binCount * 0.6);

          for (let i = 0; i < binCount; i++) {
            const val = freqData[i];
            sum += val;
            if (i < bassEnd) bassSum += val;
            else if (i < midEnd) midSum += val;
            else trebleSum += val;
          }

          const avg = sum / binCount;
          const normalizedVol = Math.min(1, avg / 128);
          const bass = bassSum / (bassEnd * 255 || 1);
          const mid = midSum / ((midEnd - bassEnd) * 255 || 1);
          const treble = trebleSum / ((binCount - midEnd) * 255 || 1);

          setMetrics({
            volume: normalizedVol,
            rawDecibels: -70 + normalizedVol * 60,
            bassLevel: bass,
            midLevel: mid,
            trebleLevel: treble,
            frequencyData: freqData,
            timeDomainData: timeData,
          });
        } else {
          // Ambient simulated room tone if mic not active
          const ambient = 0.08 + Math.sin(phase * 1.5) * 0.04;
          for (let i = 0; i < freqData.length; i++) {
            freqData[i] = Math.max(0, Math.floor((Math.sin(phase + i * 0.25) * 0.5 + 0.5) * 35));
            timeData[i] = 128 + Math.floor(Math.sin(phase * 2 + i * 0.2) * 8);
          }
          setMetrics({
            volume: ambient,
            rawDecibels: -65,
            bassLevel: 0.1,
            midLevel: 0.08,
            trebleLevel: 0.05,
            frequencyData: freqData,
            timeDomainData: timeData,
          });
        }
      }

      animFrameIdRef.current = requestAnimationFrame(render);
    };

    animFrameIdRef.current = requestAnimationFrame(render);

    return () => {
      if (animFrameIdRef.current) {
        cancelAnimationFrame(animFrameIdRef.current);
      }
    };
  }, [state, isMuted]);

  // Clean up on component unmount
  useEffect(() => {
    return () => {
      cleanupAudio();
    };
  }, [cleanupAudio]);

  return {
    metrics,
    micPermission,
    errorMessage,
    startMicrophone,
    cleanupAudio,
  };
}
