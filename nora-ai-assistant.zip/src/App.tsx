/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Sparkles, Mic, MicOff, Power, Info, Cpu, Wifi, RefreshCw, Download, CheckCircle2, Key, Brain } from 'lucide-react';
import { VoiceState, AudioMetrics, AssistantVisualMode } from './types/assistant';
import { LiveSession } from './services/LiveSession';
import { getStoredApiKey, setStoredApiKey, removeStoredApiKey, hasStoredApiKey, validateGeminiApiKey } from './services/apiKeyStorage';
import { BackgroundEffects } from './components/BackgroundEffects';
import { NoraOrb } from './components/NoraOrb';
import { MicButton } from './components/MicButton';
import { VoiceWaveform } from './components/VoiceWaveform';
import { StatusIndicator } from './components/StatusIndicator';
import { ToolNotification, ToolNotificationData } from './components/ToolNotification';
import { WelcomeScreen } from './components/WelcomeScreen';
import { ApiKeySetupScreen } from './components/ApiKeySetupScreen';
import { SettingsModal } from './components/SettingsModal';

type AppScreen = 'welcome' | 'setup' | 'main';

const INITIAL_METRICS: AudioMetrics = {
  volume: 0,
  rawDecibels: -90,
  bassLevel: 0,
  midLevel: 0,
  trebleLevel: 0,
  frequencyData: new Uint8Array(32),
  timeDomainData: new Uint8Array(32),
};

export default function App() {
  // Navigation Screen State
  const [currentScreen, setCurrentScreen] = useState<AppScreen>('welcome');
  const [hasSavedApiKey, setHasSavedApiKey] = useState<boolean>(false);
  const [savedKeyPreview, setSavedKeyPreview] = useState<string | null>(null);

  // Live Assistant Audio / Voice State
  const [voiceState, setVoiceState] = useState<VoiceState>('DISCONNECTED');
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [metrics, setMetrics] = useState<AudioMetrics>(INITIAL_METRICS);
  const [sessionSeconds, setSessionSeconds] = useState<number>(0);
  const [latencyMs, setLatencyMs] = useState<number>(24);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [setupErrorMessage, setSetupErrorMessage] = useState<string | null>(null);
  const [showSettingsModal, setShowSettingsModal] = useState<boolean>(false);
  const [toolNotification, setToolNotification] = useState<ToolNotificationData | null>(null);

  // Command Center Intelligence States
  const [isToolExecuting, setIsToolExecuting] = useState<boolean>(false);
  const [activeToolName, setActiveToolName] = useState<string | null>(null);
  const [isProcessingResponse, setIsProcessingResponse] = useState<boolean>(false);

  // PWA Installation state
  const [installPrompt, setInstallPrompt] = useState<any>(null);
  const [isStandalone, setIsStandalone] = useState<boolean>(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const liveSessionRef = useRef<LiveSession | null>(null);
  const notificationTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const toolExecTimeoutRef = useRef<NodeJS.Timeout | null>(null);

  // Check saved API key status on mount
  useEffect(() => {
    const key = getStoredApiKey();
    setHasSavedApiKey(Boolean(key));
    setSavedKeyPreview(key);
  }, []);

  // Detect standalone display mode and capture PWA beforeinstallprompt event
  useEffect(() => {
    const checkStandalone = () => {
      const isStandaloneMode =
        window.matchMedia('(display-mode: standalone)').matches ||
        (window.navigator as any).standalone === true ||
        document.referrer.includes('android-app://');
      setIsStandalone(Boolean(isStandaloneMode));
    };

    checkStandalone();

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setInstallPrompt(e);
      console.log('[NORA PWA] Captured beforeinstallprompt event.');
    };

    const handleAppInstalled = () => {
      setInstallPrompt(null);
      setToastMessage('NORA command center installed!');
      setTimeout(() => setToastMessage(null), 4000);
      console.log('[NORA PWA] App was successfully installed!');
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, []);

  // Handle user clicking install button
  const handleInstallClick = async () => {
    if (!installPrompt) return;
    try {
      installPrompt.prompt();
      const { outcome } = await installPrompt.userChoice;
      console.log(`[NORA PWA] User response to the install prompt: ${outcome}`);
      if (outcome === 'accepted') {
        setInstallPrompt(null);
      }
    } catch (err) {
      console.warn('[NORA PWA] Error triggering install prompt:', err);
    }
  };

  // Initialize live session instance
  useEffect(() => {
    const session = new LiveSession({
      onStateChange: (state) => {
        setVoiceState(state);
        if (state === 'LISTENING' || state === 'SPEAKING') {
          setErrorMessage(null);
          setIsProcessingResponse(false);
        }
      },
      onMetricsUpdate: (newMetrics) => {
        setMetrics(newMetrics);
      },
      onError: (err, isFatal) => {
        console.error('[App] Voice Session Error encountered:', err);
        setErrorMessage(err);
        setIsProcessingResponse(false);
        if (isFatal) {
          setVoiceState('DISCONNECTED');
        }
      },
      onTelemetryUpdate: ({ latencyMs: lat }) => {
        setLatencyMs(lat);
      },
      onToolCallExecuted: (toolName, args, result) => {
        console.log('[App] Tool executed:', toolName, args, result);

        // Trigger visual intelligent activity state
        setIsToolExecuting(true);
        setActiveToolName(toolName);

        if (toolExecTimeoutRef.current) {
          clearTimeout(toolExecTimeoutRef.current);
        }
        toolExecTimeoutRef.current = setTimeout(() => {
          setIsToolExecuting(false);
          setActiveToolName(null);
        }, 2600);

        if (notificationTimeoutRef.current) {
          clearTimeout(notificationTimeoutRef.current);
        }

        const isSuccess = result?.success !== false && !result?.error;
        setToolNotification({
          id: String(Date.now()),
          toolName,
          url: result?.url || args?.url,
          domain: result?.domain,
          success: isSuccess,
          message: result?.message || result?.error,
        });

        // Auto dismiss notification after 3.5 seconds
        notificationTimeoutRef.current = setTimeout(() => {
          setToolNotification(null);
        }, 3500);
      },
    });

    liveSessionRef.current = session;

    return () => {
      if (notificationTimeoutRef.current) {
        clearTimeout(notificationTimeoutRef.current);
      }
      if (toolExecTimeoutRef.current) {
        clearTimeout(toolExecTimeoutRef.current);
      }
      session.cleanup();
    };
  }, []);

  // Session duration timer
  useEffect(() => {
    let timer: NodeJS.Timeout;
    if (voiceState !== 'DISCONNECTED') {
      timer = setInterval(() => {
        setSessionSeconds((prev) => prev + 1);
      }, 1000);
    } else {
      setSessionSeconds(0);
    }
    return () => clearInterval(timer);
  }, [voiceState]);

  // Handle "START NORA" from Welcome Screen
  const handleWelcomeStart = useCallback(async () => {
    const key = getStoredApiKey();
    if (!key) {
      // No key saved -> route to API Key Setup Screen
      setCurrentScreen('setup');
      return;
    }

    // Key exists -> transition to main interface and auto-connect
    setCurrentScreen('main');
    const session = liveSessionRef.current;
    if (session) {
      setErrorMessage(null);
      await session.preWarmAudio();
      try {
        await session.connect(key);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Connection failed. Please check your Gemini API key.';
        setErrorMessage(msg);
      }
    }
  }, []);

  // Handle Connect from API Key Setup Screen
  const handleSetupConnect = useCallback(async (newApiKey: string) => {
    const cleanKey = newApiKey.trim();

    // Check offline status
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      throw new Error('No internet connection. Please verify network access.');
    }

    // 1. Validate key (works via local server proxy if active, or direct CORS Google Gemini API on GitHub Pages)
    const valResult = await validateGeminiApiKey(cleanKey);
    if (!valResult.valid) {
      throw new Error(valResult.error || 'Invalid Gemini API key. Please check the key in Google AI Studio.');
    }

    // 2. Key is valid! Save locally to this device
    setStoredApiKey(cleanKey);
    setHasSavedApiKey(true);
    setSavedKeyPreview(cleanKey);

    // 3. Move to Main interface and start Live session
    setCurrentScreen('main');
    setSetupErrorMessage(null);

    const session = liveSessionRef.current;
    if (session) {
      setErrorMessage(null);
      await session.preWarmAudio();
      try {
        await session.connect(cleanKey);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Failed to connect to Live session.';
        setErrorMessage(msg);
      }
    }
  }, []);

  // Connect or Disconnect action on Main screen
  const handleTogglePower = useCallback(async () => {
    const session = liveSessionRef.current;
    if (!session) return;

    if (voiceState === 'DISCONNECTED') {
      const key = getStoredApiKey();
      if (!key) {
        setCurrentScreen('setup');
        return;
      }

      setErrorMessage(null);
      await session.preWarmAudio();
      try {
        await session.connect(key);
        setIsMuted(false);
      } catch (err: unknown) {
        const msg = err instanceof Error ? err.message : 'Connection failed';
        setErrorMessage(msg);
      }
    } else {
      session.disconnect();
      setIsMuted(false);
      setIsProcessingResponse(false);
      setIsToolExecuting(false);
    }
  }, [voiceState]);

  // Reconnect action
  const handleRetry = useCallback(async () => {
    const session = liveSessionRef.current;
    if (!session) return;

    const key = getStoredApiKey();
    if (!key) {
      setCurrentScreen('setup');
      return;
    }

    setErrorMessage(null);
    await session.preWarmAudio();
    await session.reconnect(key);
  }, []);

  // Toggle Mute
  const handleToggleMute = useCallback(() => {
    const session = liveSessionRef.current;
    if (!session) return;

    const nextMuted = !isMuted;
    setIsMuted(nextMuted);
    session.setMuted(nextMuted);
  }, [isMuted]);

  // Remove API key handler
  const handleRemoveApiKey = useCallback(() => {
    removeStoredApiKey();
    setHasSavedApiKey(false);
    setSavedKeyPreview(null);
    setShowSettingsModal(false);

    // Stop active live session
    const session = liveSessionRef.current;
    if (session) {
      session.disconnect();
    }

    setToastMessage('Gemini API key removed from this device.');
    setTimeout(() => setToastMessage(null), 3000);

    // Return to welcome screen
    setCurrentScreen('welcome');
  }, []);

  // Change API key handler
  const handleChangeApiKey = useCallback(() => {
    setShowSettingsModal(false);
    const session = liveSessionRef.current;
    if (session) {
      session.disconnect();
    }
    setCurrentScreen('setup');
  }, []);

  // Calculate current visual mode for high-fidelity animations
  const visualMode: AssistantVisualMode = (() => {
    if (errorMessage) return 'error';
    if (isToolExecuting) return 'tool_executing';
    if (voiceState === 'CONNECTING' || isProcessingResponse) return 'processing';
    if (voiceState === 'SPEAKING') return 'speaking';
    if (voiceState === 'LISTENING') {
      return metrics.volume > 0.04 && !isMuted ? 'listening' : 'idle';
    }
    return 'idle';
  })();

  // -------------------------------------------------------------
  // Render Screen 1: Welcome Screen (First Launch Flow)
  // -------------------------------------------------------------
  if (currentScreen === 'welcome') {
    return (
      <>
        <WelcomeScreen
          onStart={handleWelcomeStart}
          hasSavedKey={hasSavedApiKey}
          onOpenSetup={() => setCurrentScreen('setup')}
          onOpenInfo={() => setShowSettingsModal(true)}
          installPrompt={installPrompt}
          onInstallClick={handleInstallClick}
          isStandalone={isStandalone}
        />
        {/* Settings modal accessible from welcome screen info icon */}
        <SettingsModal
          isOpen={showSettingsModal}
          onClose={() => setShowSettingsModal(false)}
          savedApiKey={savedKeyPreview}
          onChangeApiKey={handleChangeApiKey}
          onRemoveApiKey={handleRemoveApiKey}
          latencyMs={latencyMs}
          voiceState={voiceState}
        />
      </>
    );
  }

  // -------------------------------------------------------------
  // Render Screen 2: API Key Setup Screen
  // -------------------------------------------------------------
  if (currentScreen === 'setup') {
    return (
      <ApiKeySetupScreen
        initialKey={savedKeyPreview || ''}
        onConnect={handleSetupConnect}
        onCancel={() => setCurrentScreen('welcome')}
        errorMessage={setupErrorMessage}
        onClearError={() => setSetupErrorMessage(null)}
      />
    );
  }

  // -------------------------------------------------------------
  // Render Screen 3: Main NORA Command Center Interface
  // -------------------------------------------------------------
  return (
    <div
      id="nora-main-command-center"
      className="relative h-full min-h-[100dvh] w-full flex flex-col justify-between overflow-hidden bg-[#06080e] text-slate-100 select-none touch-manipulation"
    >
      {/* 1. Dynamic Futuristic Particle & Neural Grid Background */}
      <BackgroundEffects state={voiceState} audioVolume={metrics.volume} />

      {/* 2. Cybernetic HUD Corner Brackets */}
      <div className="hud-corner-tl m-2 sm:m-3" />
      <div className="hud-corner-tr m-2 sm:m-3" />
      <div className="hud-corner-bl m-2 sm:m-3" />
      <div className="hud-corner-br m-2 sm:m-3" />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-16 z-50 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-900/95 border border-cyan-500/50 text-cyan-200 text-xs font-mono shadow-2xl backdrop-blur-xl animate-in fade-in slide-in-from-top-2">
          <CheckCircle2 className="h-4 w-4 text-cyan-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* 3. COMMAND CENTER TOP BAR */}
      <header className="relative z-20 w-full px-4 sm:px-6 pt-safe pb-2.5 sm:py-3.5 flex items-center justify-between border-b border-white/5 bg-[#06080e]/80 backdrop-blur-xl">
        {/* NORA Visual Brand Identity */}
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-950/60 border border-cyan-500/40 shadow-[0_0_20px_rgba(6,182,212,0.35)]">
            <Sparkles className="h-5 w-5 text-cyan-400 animate-pulse" />
            <div className="absolute inset-0 rounded-xl bg-cyan-400/10" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-cyan-400">
                NORA
              </h1>
              <span className="text-[9px] sm:text-[10px] font-mono font-semibold uppercase px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/40 shadow-sm">
                COMMAND CORE
              </span>
            </div>
            <p className="text-[9px] sm:text-[10px] font-mono tracking-widest text-slate-400 uppercase">
              NEURAL OMNI ASSISTANT
            </p>
          </div>
        </div>

        {/* Top Right Live Telemetry & Control Suite */}
        <div className="flex items-center gap-2 sm:gap-3">
          {/* PWA Install Button */}
          {installPrompt && (
            <button
              id="nora-pwa-install-button"
              type="button"
              onClick={handleInstallClick}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono font-medium shadow-[0_0_15px_rgba(6,182,212,0.3)] transition-all cursor-pointer min-h-[44px]"
              aria-label="Install NORA Web App"
            >
              <Download className="h-4 w-4" />
              <span className="hidden sm:inline">INSTALL</span>
              <span className="sm:hidden">APP</span>
            </button>
          )}

          {/* Real-Time Neural Link Status */}
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-full bg-slate-900/80 border border-slate-800 text-xs font-mono">
            <Wifi
              className={`h-3.5 w-3.5 ${
                voiceState === 'LISTENING' || voiceState === 'SPEAKING'
                  ? 'text-cyan-400'
                  : voiceState === 'CONNECTING'
                  ? 'text-amber-400 animate-pulse'
                  : 'text-slate-500'
              }`}
            />
            <span className="text-slate-300">
              {voiceState === 'DISCONNECTED'
                ? 'STANDBY'
                : voiceState === 'CONNECTING'
                ? 'SYNCING'
                : 'QUANTUM LINK'}
            </span>
          </div>

          {/* Brain & Memory Quick Access */}
          <button
            id="nora-brain-memory-button"
            onClick={() => setShowSettingsModal(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 min-h-[44px] rounded-xl bg-purple-950/40 hover:bg-purple-900/50 border border-purple-500/40 text-purple-300 text-xs font-mono transition-all cursor-pointer shadow-sm"
            aria-label="3-Level Brain Memory Bank"
            title="3-Level Brain Memory Bank"
          >
            <Brain className="h-4 w-4 text-purple-400" />
            <span className="hidden sm:inline text-[11px] font-semibold">BRAIN</span>
          </button>

          {/* Settings & Architecture Modal */}
          <button
            id="nora-settings-button"
            onClick={() => setShowSettingsModal(true)}
            className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            aria-label="System Architecture, Diagnostics & Settings"
          >
            <Info className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* 4. MAIN COMMAND-CENTER STAGE (9:16 optimized, mobile responsive, smooth 60fps) */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-3 sm:py-6 overflow-hidden">
        {/* Floating Tool Execution Micro Notification */}
        <ToolNotification
          notification={toolNotification}
          onDismiss={() => setToolNotification(null)}
        />

        <div className="flex flex-col items-center justify-center gap-3 sm:gap-5 max-w-lg w-full">
          {/* Central Animated NORA Orb with Quantum Gyro Rings */}
          <div className="my-1 sm:my-2">
            <NoraOrb
              state={voiceState}
              visualMode={visualMode}
              volume={metrics.volume}
              bassLevel={metrics.bassLevel}
              midLevel={metrics.midLevel}
              trebleLevel={metrics.trebleLevel}
              isMuted={isMuted}
              isProcessing={isProcessingResponse || voiceState === 'CONNECTING'}
              isToolExecuting={isToolExecuting}
              activeToolName={activeToolName}
              hasError={Boolean(errorMessage)}
            >
              <MicButton
                state={voiceState}
                visualMode={visualMode}
                isMuted={isMuted}
                onTogglePower={handleTogglePower}
                onToggleMute={handleToggleMute}
              />
            </NoraOrb>
          </div>

          {/* Mirrored Assistant Voice Equalizer Waveform */}
          <VoiceWaveform
            state={voiceState}
            frequencyData={metrics.frequencyData}
            timeDomainData={metrics.timeDomainData}
            volume={metrics.volume}
            isMuted={isMuted}
          />

          {/* Minimalist Command-Center Status Capsule */}
          <StatusIndicator
            state={voiceState}
            visualMode={visualMode}
            isMuted={isMuted}
            decibels={metrics.rawDecibels}
            durationSeconds={sessionSeconds}
            errorMessage={errorMessage}
            activeToolName={activeToolName}
            onRetry={handleRetry}
            onClearError={() => setErrorMessage(null)}
            onUpdateKey={() => setCurrentScreen('setup')}
            onGetNewKey={() => window.open('https://aistudio.google.com/apikey', '_blank', 'noopener,noreferrer')}
          />
        </div>
      </main>

      {/* 5. BOTTOM COMMAND BAR (Safe area support & 44px+ touch targets) */}
      <footer className="relative z-20 w-full px-4 sm:px-6 pt-3 pb-safe border-t border-white/5 bg-[#06080e]/90 backdrop-blur-2xl flex flex-col sm:flex-row items-center justify-between gap-3 sm:gap-4">
        {/* Technical telemetry metrics */}
        <div className="flex items-center gap-3 text-[11px] sm:text-xs font-mono text-slate-500">
          <div className="flex items-center gap-1.5">
            <Cpu className="h-3.5 w-3.5 text-cyan-400/80" />
            <span className="truncate max-w-[170px] sm:max-w-none text-slate-400">gemini-3.1-flash-live</span>
          </div>
          <span>•</span>
          <div>
            <span>LATENCY: </span>
            <span className="text-cyan-300 font-semibold">
              {voiceState !== 'DISCONNECTED' ? `${latencyMs}ms` : '--'}
            </span>
          </div>
          {isStandalone && (
            <>
              <span>•</span>
              <span className="text-cyan-400 hidden sm:inline">PWA STANDALONE</span>
            </>
          )}
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2 sm:gap-3 w-full sm:w-auto justify-center sm:justify-end">
          {/* Reconnect retry button if disconnected with error */}
          {voiceState === 'DISCONNECTED' && errorMessage && (
            <button
              id="nora-footer-retry-button"
              type="button"
              onClick={handleRetry}
              className="min-h-[44px] px-4 py-2 rounded-xl border border-amber-500/40 bg-amber-950/50 hover:bg-amber-900/50 text-amber-300 text-xs font-mono font-semibold transition-all cursor-pointer flex items-center gap-1.5 active:scale-95"
            >
              <RefreshCw className="h-4 w-4" />
              <span>RETRY</span>
            </button>
          )}

          {/* Quick Mute toggle */}
          {voiceState !== 'DISCONNECTED' && (
            <button
              id="nora-footer-mute-button"
              type="button"
              onClick={handleToggleMute}
              className={`min-h-[44px] px-4 py-2 rounded-xl border text-xs font-mono font-semibold transition-all cursor-pointer flex items-center gap-2 active:scale-95 ${
                isMuted
                  ? 'bg-rose-950/70 border-rose-500/60 text-rose-300 shadow-[0_0_20px_rgba(244,63,94,0.3)]'
                  : 'bg-slate-900/70 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              {isMuted ? <MicOff className="h-4 w-4" /> : <Mic className="h-4 w-4" />}
              <span>{isMuted ? 'UNMUTE' : 'MUTE'}</span>
            </button>
          )}

          {/* Master Power / Session Toggle Button */}
          <button
            id="nora-footer-power-button"
            type="button"
            onClick={handleTogglePower}
            className={`min-h-[44px] flex-1 sm:flex-initial px-6 py-2.5 rounded-xl border text-xs font-mono font-bold tracking-wider transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95 ${
              voiceState === 'DISCONNECTED'
                ? 'bg-cyan-500/20 hover:bg-cyan-500/30 border-cyan-400/60 text-cyan-200 shadow-[0_0_25px_rgba(6,182,212,0.35)]'
                : 'bg-rose-500/20 hover:bg-rose-500/30 border-rose-400/50 text-rose-300 shadow-[0_0_20px_rgba(244,63,94,0.25)]'
            }`}
          >
            <Power className="h-4 w-4" />
            <span>{voiceState === 'DISCONNECTED' ? 'START NORA' : 'SHUTDOWN'}</span>
          </button>
        </div>
      </footer>

      {/* 6. SETTINGS & ARCHITECTURE MODAL */}
      <SettingsModal
        isOpen={showSettingsModal}
        onClose={() => setShowSettingsModal(false)}
        savedApiKey={savedKeyPreview}
        onChangeApiKey={handleChangeApiKey}
        onRemoveApiKey={handleRemoveApiKey}
        latencyMs={latencyMs}
        voiceState={voiceState}
      />
    </div>
  );
}

