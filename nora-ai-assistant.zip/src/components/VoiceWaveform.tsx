/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useEffect } from 'react';
import { VoiceState } from '../types/assistant';

interface VoiceWaveformProps {
  state: VoiceState;
  frequencyData: Uint8Array;
  timeDomainData: Uint8Array;
  volume: number;
  isMuted: boolean;
}

export const VoiceWaveform: React.FC<VoiceWaveformProps> = ({
  state,
  frequencyData,
  timeDomainData,
  volume,
  isMuted,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    const width = (canvas.width = canvas.offsetWidth * window.devicePixelRatio || 400);
    const height = (canvas.height = canvas.offsetHeight * window.devicePixelRatio || 120);

    const render = () => {
      ctx.clearRect(0, 0, width, height);

      const centerY = height / 2;
      const barCount = 36;
      const barSpacing = width / barCount;
      const barWidth = Math.max(3, barSpacing * 0.45);

      // Select waveform theme based on state
      let primaryColor = '#06b6d4'; // cyan
      let glowColor = 'rgba(6, 182, 212, 0.6)';

      if (state === 'DISCONNECTED') {
        primaryColor = '#334155'; // slate
        glowColor = 'rgba(51, 65, 85, 0.3)';
      } else if (state === 'CONNECTING') {
        primaryColor = '#f59e0b'; // amber
        glowColor = 'rgba(245, 158, 11, 0.6)';
      } else if (state === 'SPEAKING') {
        primaryColor = '#d946ef'; // fuchsia/magenta
        glowColor = 'rgba(217, 70, 239, 0.7)';
      } else if (isMuted) {
        primaryColor = '#f43f5e'; // rose
        glowColor = 'rgba(244, 63, 94, 0.4)';
      }

      ctx.shadowBlur = state !== 'DISCONNECTED' ? 14 : 4;
      ctx.shadowColor = glowColor;

      // Draw mirrored futuristic frequency equalizer bars
      const dataLen = frequencyData.length || 32;

      for (let i = 0; i < barCount; i++) {
        // Symmetric fold so high energy is centered
        const normIdx = Math.abs(i - barCount / 2) / (barCount / 2);
        const dataIndex = Math.min(
          dataLen - 1,
          Math.floor((1 - normIdx) * (dataLen * 0.75))
        );

        let energy = (frequencyData[dataIndex] || 0) / 255;

        // In muted or disconnected state, damp height
        if (state === 'DISCONNECTED') {
          energy = 0.04;
        } else if (isMuted) {
          energy = 0.02;
        } else {
          energy = Math.max(0.06, energy * (1 + volume * 0.8));
        }

        const barHeight = Math.min(height * 0.85, Math.max(6, energy * (height * 0.75)));
        const x = i * barSpacing + (barSpacing - barWidth) / 2;
        const yTop = centerY - barHeight / 2;

        // Vertical gradient for each frequency bar
        const grad = ctx.createLinearGradient(0, yTop, 0, yTop + barHeight);
        if (state === 'DISCONNECTED') {
          grad.addColorStop(0, 'rgba(100, 116, 139, 0.5)');
          grad.addColorStop(1, 'rgba(51, 65, 85, 0.2)');
        } else if (state === 'CONNECTING') {
          grad.addColorStop(0, 'rgba(251, 191, 36, 0.9)');
          grad.addColorStop(0.5, 'rgba(245, 158, 11, 0.7)');
          grad.addColorStop(1, 'rgba(217, 119, 6, 0.3)');
        } else if (state === 'SPEAKING') {
          grad.addColorStop(0, 'rgba(244, 114, 182, 0.95)');
          grad.addColorStop(0.5, 'rgba(217, 70, 239, 0.75)');
          grad.addColorStop(1, 'rgba(147, 51, 234, 0.3)');
        } else {
          grad.addColorStop(0, 'rgba(103, 232, 249, 0.95)');
          grad.addColorStop(0.5, 'rgba(6, 182, 212, 0.75)');
          grad.addColorStop(1, 'rgba(14, 116, 144, 0.3)');
        }

        ctx.fillStyle = grad;
        ctx.beginPath();
        // Pill shaped bars
        const radius = barWidth / 2;
        ctx.roundRect(x, yTop, barWidth, barHeight, radius);
        ctx.fill();
      }

      // Draw subtle continuous oscilloscope line through the waveform
      ctx.beginPath();
      const timeLen = timeDomainData.length || 32;
      for (let i = 0; i < width; i += 4) {
        const tIdx = Math.floor((i / width) * timeLen);
        const rawT = (timeDomainData[tIdx] || 128) - 128;
        const normT = state === 'DISCONNECTED' ? 0 : rawT / 128;
        const waveY = centerY + normT * (height * 0.28) * (isMuted ? 0.05 : 1);

        if (i === 0) ctx.moveTo(i, waveY);
        else ctx.lineTo(i, waveY);
      }

      ctx.strokeStyle = primaryColor;
      ctx.lineWidth = 1.5;
      ctx.globalAlpha = state === 'DISCONNECTED' ? 0.2 : 0.6;
      ctx.stroke();
      ctx.globalAlpha = 1.0;

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animId);
    };
  }, [state, frequencyData, timeDomainData, volume, isMuted]);

  return (
    <div id="nora-voice-waveform-wrapper" className="w-full max-w-md px-4 py-2 flex flex-col items-center">
      <div className="relative w-full h-20 md:h-24 flex items-center justify-center">
        {/* Subtle baseline glow line */}
        <div className="absolute inset-x-8 top-1/2 -translate-y-1/2 h-[1px] bg-gradient-to-r from-transparent via-cyan-500/20 to-transparent pointer-events-none" />
        
        {/* Dynamic Waveform Canvas */}
        <canvas
          ref={canvasRef}
          className="w-full h-full block"
        />
      </div>

      {/* Futuristic Frequency Range Indicators */}
      <div className="w-full flex items-center justify-between px-6 text-[10px] font-mono tracking-widest text-slate-500 uppercase">
        <span>160 Hz</span>
        <span className="text-slate-600">● LIVE VOICE SPECTRUM ●</span>
        <span>8.0 kHz</span>
      </div>
    </div>
  );
};
