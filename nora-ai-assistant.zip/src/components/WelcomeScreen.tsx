/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Sparkles, Power, ArrowRight, Key, Download, Info, Wifi } from 'lucide-react';
import { BackgroundEffects } from './BackgroundEffects';

interface WelcomeScreenProps {
  onStart: () => void;
  hasSavedKey: boolean;
  onOpenSetup: () => void;
  onOpenInfo: () => void;
  installPrompt?: any;
  onInstallClick?: () => void;
  isStandalone?: boolean;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({
  onStart,
  hasSavedKey,
  onOpenSetup,
  onOpenInfo,
  installPrompt,
  onInstallClick,
  isStandalone,
}) => {
  return (
    <div
      id="nora-welcome-screen"
      className="relative min-h-[100dvh] w-full flex flex-col justify-between overflow-hidden bg-[#06080e] text-slate-100 select-none touch-manipulation animate-in fade-in duration-500"
    >
      {/* Background Ambience */}
      <BackgroundEffects state="DISCONNECTED" audioVolume={0.02} />

      {/* Cybernetic HUD Corner Accents */}
      <div className="hud-corner-tl m-2 sm:m-3" />
      <div className="hud-corner-tr m-2 sm:m-3" />
      <div className="hud-corner-bl m-2 sm:m-3" />
      <div className="hud-corner-br m-2 sm:m-3" />

      {/* Top Bar */}
      <header className="relative z-20 w-full px-4 sm:px-6 pt-safe pb-2 sm:py-3.5 flex items-center justify-between border-b border-white/5 bg-[#06080e]/60 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <div className="relative flex h-9 w-9 items-center justify-center rounded-xl bg-cyan-950/70 border border-cyan-500/40 shadow-[0_0_15px_rgba(6,182,212,0.3)]">
            <Sparkles className="h-4 w-4 text-cyan-400 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-display text-xl sm:text-2xl font-bold tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-100 to-cyan-400">
                NORA
              </span>
              <span className="text-[9px] font-mono font-semibold uppercase px-1.5 py-0.5 rounded bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                v3.1 LIVE
              </span>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {installPrompt && (
            <button
              type="button"
              onClick={onInstallClick}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono font-medium shadow-[0_0_15px_rgba(6,182,212,0.25)] transition-all cursor-pointer min-h-[44px]"
            >
              <Download className="h-4 w-4" />
              <span>INSTALL</span>
            </button>
          )}

          <button
            type="button"
            onClick={onOpenInfo}
            className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/70 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
            aria-label="About NORA"
          >
            <Info className="h-4 w-4" />
          </button>
        </div>
      </header>

      {/* Main Hero Center Content */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-6 text-center max-w-lg mx-auto w-full">
        {/* Animated Futuristic NORA Orb in Standby/Breathing Mode */}
        <div className="relative mb-6 flex items-center justify-center">
          {/* Orbital Outer Halo */}
          <div className="absolute h-56 w-56 sm:h-64 sm:w-64 rounded-full border border-cyan-500/20 animate-spin-slow pointer-events-none" />
          <div className="absolute h-48 w-48 sm:h-52 sm:w-52 rounded-full border border-cyan-400/30 border-dashed animate-reverse-spin pointer-events-none" />

          {/* Orb Core Glow */}
          <div className="relative flex h-36 w-36 sm:h-44 sm:w-44 items-center justify-center rounded-full bg-gradient-to-b from-cyan-950/80 via-[#071322]/90 to-[#030712] border border-cyan-400/40 shadow-[0_0_60px_rgba(6,182,212,0.35)] backdrop-blur-xl">
            <div className="absolute inset-2 rounded-full bg-cyan-500/10 animate-pulse-glow" />
            
            {/* Center Neural Icon */}
            <div className="relative flex flex-col items-center justify-center gap-1">
              <Sparkles className="h-10 w-10 sm:h-12 sm:w-12 text-cyan-400 animate-pulse drop-shadow-[0_0_15px_rgba(6,182,212,0.8)]" />
              <span className="text-[10px] font-mono font-semibold tracking-widest text-cyan-300/80 uppercase">
                READY
              </span>
            </div>
          </div>
        </div>

        {/* Brand & Subtitle */}
        <div className="space-y-2 mb-8">
          <h1 className="font-display text-3xl sm:text-4xl font-extrabold tracking-wider text-white">
            NORA AI ASSISTANT
          </h1>
          <p className="text-xs sm:text-sm font-mono tracking-widest text-cyan-400 uppercase font-medium">
            NEURAL OMNI REAL-TIME VOICE ASSISTANT
          </p>
          <div className="flex flex-wrap items-center justify-center gap-2 pt-1">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-cyan-950/50 border border-cyan-500/30 text-cyan-300 text-xs font-mono">
              <span className="h-1.5 w-1.5 rounded-full bg-cyan-400 animate-pulse" />
              <span>বাংলা • हिन्दी • English Auto-Detect</span>
            </span>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-950/50 border border-purple-500/30 text-purple-300 text-xs font-mono">
              <span className="h-1.5 w-1.5 rounded-full bg-purple-400 animate-pulse" />
              <span>🧠 3-Level Brain Memory</span>
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto leading-relaxed pt-1 font-sans">
            Full-duplex bidirectional voice conversation powered by Gemini Live. Speak naturally in Bengali or Hindi, interrupt anytime, and execute live commands.
          </p>
        </div>

        {/* Primary Action Button: Large "START NORA" */}
        <div className="w-full max-w-xs space-y-3">
          <button
            id="nora-welcome-start-button"
            type="button"
            onClick={onStart}
            className="w-full min-h-[56px] px-8 py-3.5 rounded-2xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-teal-400 hover:from-cyan-400 hover:to-teal-300 text-slate-950 font-display font-bold text-base sm:text-lg tracking-wider shadow-[0_0_35px_rgba(6,182,212,0.5)] active:scale-[0.98] transition-all flex items-center justify-center gap-3 cursor-pointer"
          >
            <Power className="h-5 w-5" />
            <span>START NORA</span>
            <ArrowRight className="h-5 w-5" />
          </button>

          {/* Key Status Pill */}
          <div className="pt-2 flex items-center justify-center gap-2">
            {hasSavedKey ? (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-950/60 border border-emerald-500/30 text-emerald-300 text-[11px] font-mono">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
                <span>Gemini API Key Saved</span>
                <button
                  type="button"
                  onClick={onOpenSetup}
                  className="ml-1 text-cyan-400 hover:underline cursor-pointer"
                >
                  (Change)
                </button>
              </div>
            ) : (
              <button
                type="button"
                onClick={onOpenSetup}
                className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-cyan-300 text-[11px] font-mono transition-colors cursor-pointer min-h-[36px]"
              >
                <Key className="h-3.5 w-3.5 text-cyan-400" />
                <span>Configure Gemini API Key</span>
              </button>
            )}
          </div>
        </div>
      </main>

      {/* Footer Info */}
      <footer className="relative z-20 w-full px-4 sm:px-6 py-3 border-t border-white/5 bg-[#06080e]/80 backdrop-blur-md flex items-center justify-between text-[11px] font-mono text-slate-500">
        <div className="flex items-center gap-2">
          <Wifi className="h-3.5 w-3.5 text-cyan-500/80" />
          <span>REAL-TIME LIVE PIPELINE</span>
        </div>
        <div>
          <span>{isStandalone ? 'PWA STANDALONE' : 'READY TO CONNECT'}</span>
        </div>
      </footer>
    </div>
  );
};
