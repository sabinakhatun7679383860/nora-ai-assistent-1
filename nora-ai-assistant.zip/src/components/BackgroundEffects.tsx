/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from 'react';
import { VoiceState } from '../types/assistant';

interface BackgroundEffectsProps {
  state: VoiceState;
  audioVolume: number;
}

export const BackgroundEffects: React.FC<BackgroundEffectsProps> = ({ state, audioVolume }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Dynamic particle effect reacting to state and volume
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle nodes for futuristic neural/energy field
    interface Particle {
      x: number;
      y: number;
      size: number;
      baseSpeedX: number;
      baseSpeedY: number;
      opacity: number;
      hue: number;
    }

    const particleCount = 45;
    const particles: Particle[] = [];

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2 + 0.8,
        baseSpeedX: (Math.random() - 0.5) * 0.35,
        baseSpeedY: (Math.random() - 0.5) * 0.35 - 0.1,
        opacity: Math.random() * 0.5 + 0.2,
        hue: state === 'SPEAKING' ? 290 : state === 'CONNECTING' ? 38 : 190,
      });
    }

    let t = 0;

    const render = () => {
      t += 0.01;
      ctx.clearRect(0, 0, width, height);

      // Determine colors based on active assistant state
      let targetHue = 200; // Cyan default
      let glowColor = 'rgba(6, 182, 212, 0.08)';
      let speedMultiplier = 1;

      if (state === 'DISCONNECTED') {
        targetHue = 215;
        glowColor = 'rgba(30, 41, 59, 0.05)';
        speedMultiplier = 0.5;
      } else if (state === 'CONNECTING') {
        targetHue = 38;
        glowColor = 'rgba(245, 158, 11, 0.12)';
        speedMultiplier = 2.2;
      } else if (state === 'LISTENING') {
        targetHue = 190;
        glowColor = `rgba(6, 182, 212, ${0.08 + audioVolume * 0.18})`;
        speedMultiplier = 1 + audioVolume * 3;
      } else if (state === 'SPEAKING') {
        targetHue = 285;
        glowColor = `rgba(217, 70, 239, ${0.1 + audioVolume * 0.22})`;
        speedMultiplier = 1.6 + audioVolume * 2.5;
      }

      // Draw subtle atmospheric center glow
      const cx = width / 2;
      const cy = height / 2;
      const glowRadius = Math.min(width, height) * 0.65 * (1 + audioVolume * 0.2);
      const radGlow = ctx.createRadialGradient(cx, cy, 10, cx, cy, glowRadius);
      radGlow.addColorStop(0, glowColor);
      radGlow.addColorStop(1, 'rgba(7, 9, 14, 0)');

      ctx.fillStyle = radGlow;
      ctx.fillRect(0, 0, width, height);

      // Update and draw floating neural motes
      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.x += p.baseSpeedX * speedMultiplier;
        p.y += p.baseSpeedY * speedMultiplier;

        // Wrap around viewport edges
        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        // Blend particle hue smoothly toward target
        p.hue += (targetHue - p.hue) * 0.04;

        const dynamicSize = p.size * (1 + audioVolume * 0.8);
        const dynamicOpacity = Math.min(0.9, p.opacity * (1 + audioVolume * 0.5));

        ctx.beginPath();
        ctx.arc(p.x, p.y, dynamicSize, 0, Math.PI * 2);
        ctx.fillStyle = `hsla(${p.hue}, 85%, 65%, ${dynamicOpacity})`;
        ctx.shadowBlur = 10;
        ctx.shadowColor = `hsla(${p.hue}, 90%, 60%, 0.8)`;
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      animId = requestAnimationFrame(render);
    };

    animId = requestAnimationFrame(render);

    return () => {
      window.removeEventListener('resize', handleResize);
      cancelAnimationFrame(animId);
    };
  }, [state, audioVolume]);

  return (
    <div id="nora-background-effects" className="pointer-events-none fixed inset-0 z-0 overflow-hidden bg-[#07090e]">
      {/* Deep Cybernetic Background Grid */}
      <div 
        className="absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage: `
            linear-gradient(to right, rgba(255, 255, 255, 0.15) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(255, 255, 255, 0.15) 1px, transparent 1px)
          `,
          backgroundSize: '48px 48px',
        }}
      />

      {/* Atmospheric Radial Color Blooms */}
      <div 
        className={`absolute -top-40 left-1/2 -translate-x-1/2 w-[700px] h-[500px] rounded-full blur-[140px] transition-all duration-1000 ${
          state === 'DISCONNECTED'
            ? 'bg-slate-800/10'
            : state === 'CONNECTING'
            ? 'bg-amber-500/15'
            : state === 'LISTENING'
            ? 'bg-cyan-500/20'
            : 'bg-fuchsia-600/20'
        }`}
      />

      <div 
        className={`absolute -bottom-32 left-1/2 -translate-x-1/2 w-[600px] h-[450px] rounded-full blur-[130px] transition-all duration-1000 ${
          state === 'DISCONNECTED'
            ? 'bg-blue-950/10'
            : state === 'CONNECTING'
            ? 'bg-orange-600/10'
            : state === 'LISTENING'
            ? 'bg-blue-600/15'
            : 'bg-purple-600/20'
        }`}
      />

      {/* Dynamic Particle Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 block h-full w-full" />

      {/* Futuristic Vignette Frame */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_40%,#07090e_100%)]" />
    </div>
  );
};
