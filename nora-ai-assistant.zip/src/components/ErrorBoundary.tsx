/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Sparkles, ShieldAlert, Terminal } from 'lucide-react';

interface ErrorBoundaryProps {
  children: ReactNode;
}

interface ErrorBoundaryState {
  hasError: boolean;
  errorMessage: string;
  errorStack?: string;
}

/**
 * Sanitizes error messages to ensure no API keys or sensitive user data are displayed
 */
function sanitizeErrorMessage(msg: string): string {
  if (!msg) return 'An unexpected system anomaly occurred.';
  return msg
    .replace(/AIza[0-9A-Za-z-_]{35}/g, '[REDACTED_API_KEY]')
    .replace(/sk-[a-zA-Z0-9]{20,}/g, '[REDACTED_SECRET]')
    .replace(/ghp_[a-zA-Z0-9]{20,}/g, '[REDACTED_TOKEN]');
}

export class ErrorBoundary extends Component<ErrorBoundaryProps, ErrorBoundaryState> {
  public override state: ErrorBoundaryState = {
    hasError: false,
    errorMessage: '',
  };

  public static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return {
      hasError: true,
      errorMessage: sanitizeErrorMessage(error?.message || 'Unknown runtime error'),
      errorStack: error?.stack,
    };
  }

  public override componentDidCatch(error: Error, errorInfo: ErrorInfo): void {
    console.error('[NORA ErrorBoundary] Captured unhandled error:', error, errorInfo);
  }

  private handleReset = (): void => {
    this.setState({ hasError: false, errorMessage: '', errorStack: undefined });
  };

  private handleReload = (): void => {
    if (typeof window !== 'undefined') {
      window.location.reload();
    }
  };

  public override render(): ReactNode {
    if (this.state.hasError) {
      return (
        <div
          id="nora-error-boundary-screen"
          className="h-full min-h-[100dvh] w-full flex flex-col items-center justify-center bg-[#07090e] text-slate-100 p-6 select-none font-sans overflow-y-auto"
        >
          {/* Cybernetic HUD Corner Accents */}
          <div className="fixed top-3 left-3 w-4 h-4 border-t-2 border-l-2 border-rose-500/50" />
          <div className="fixed top-3 right-3 w-4 h-4 border-t-2 border-r-2 border-rose-500/50" />
          <div className="fixed bottom-3 left-3 w-4 h-4 border-b-2 border-l-2 border-rose-500/50" />
          <div className="fixed bottom-3 right-3 w-4 h-4 border-b-2 border-r-2 border-rose-500/50" />

          <div className="max-w-md w-full flex flex-col items-center text-center space-y-6 animate-in fade-in zoom-in-95 duration-300">
            {/* Pulsing Warning Hologram Icon */}
            <div className="relative flex h-20 w-20 items-center justify-center rounded-2xl bg-rose-950/40 border border-rose-500/50 shadow-[0_0_35px_rgba(244,63,94,0.35)]">
              <ShieldAlert className="h-10 w-10 text-rose-400 animate-pulse" />
              <div className="absolute inset-0 rounded-2xl bg-rose-500/10 blur-sm" />
            </div>

            {/* Error Header */}
            <div className="space-y-2">
              <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-rose-950/60 border border-rose-500/30 text-rose-300 text-xs font-mono">
                <AlertTriangle className="h-3.5 w-3.5" />
                <span>RUNTIME DEFENSE TRIGGERED</span>
              </div>
              <h1 className="font-display text-2xl sm:text-3xl font-bold tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-rose-200 via-rose-100 to-rose-400">
                NORA encountered an error
              </h1>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans max-w-sm">
                A non-critical system exception was intercepted. Your private brain memories and session keys remain secure.
              </p>
            </div>

            {/* Error Diagnostic Box */}
            <div className="w-full text-left bg-slate-950/80 border border-slate-800 rounded-xl p-4 font-mono text-xs text-rose-300/90 shadow-inner backdrop-blur-md">
              <div className="flex items-center gap-2 pb-2 mb-2 border-b border-slate-800 text-[10px] uppercase text-slate-500 tracking-wider font-semibold">
                <Terminal className="h-3 w-3 text-cyan-400" />
                <span>Diagnostic Exception Trace</span>
              </div>
              <p className="break-words leading-relaxed">
                {this.state.errorMessage || 'An unhandled exception interrupted the visual renderer.'}
              </p>
            </div>

            {/* Interactive Recovery Buttons */}
            <div className="flex flex-col sm:flex-row items-center gap-3 w-full">
              <button
                id="nora-error-retry-btn"
                type="button"
                onClick={this.handleReset}
                className="w-full sm:flex-1 min-h-[44px] px-5 py-2.5 rounded-xl border border-cyan-500/50 bg-cyan-950/60 hover:bg-cyan-900/60 text-cyan-200 font-mono text-xs font-semibold shadow-[0_0_20px_rgba(6,182,212,0.3)] transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95"
              >
                <RefreshCw className="h-4 w-4" />
                <span>Retry</span>
              </button>

              <button
                id="nora-error-reload-btn"
                type="button"
                onClick={this.handleReload}
                className="w-full sm:flex-1 min-h-[44px] px-5 py-2.5 rounded-xl border border-slate-800 bg-slate-900/70 hover:bg-slate-800 text-slate-300 font-mono text-xs font-medium transition-all cursor-pointer flex items-center justify-center gap-2 active:scale-95"
              >
                <Sparkles className="h-4 w-4 text-cyan-400" />
                <span>Reload Page</span>
              </button>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
