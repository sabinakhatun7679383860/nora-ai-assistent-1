/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { VoiceState, AssistantVisualMode } from '../types/assistant';

interface NoraOrbProps {
  state: VoiceState;
  visualMode?: AssistantVisualMode;
  volume: number; // 0.0 to 1.0
  bassLevel?: number;
  midLevel?: number;
  trebleLevel?: number;
  isMuted: boolean;
  isProcessing?: boolean;
  isToolExecuting?: boolean;
  activeToolName?: string | null;
  hasError?: boolean;
  children?: React.ReactNode;
}

export const NoraOrb: React.FC<NoraOrbProps> = ({
  state,
  visualMode,
  volume,
  bassLevel = 0,
  isMuted,
  isProcessing = false,
  isToolExecuting = false,
  hasError = false,
  children,
}) => {
  // Determine effective visual mode
  const effectiveMode: AssistantVisualMode = visualMode || (() => {
    if (hasError) return 'error';
    if (isToolExecuting) return 'tool_executing';
    if (isProcessing || state === 'CONNECTING') return 'processing';
    if (state === 'SPEAKING') return 'speaking';
    if (state === 'LISTENING') {
      return volume > 0.04 && !isMuted ? 'listening' : 'idle';
    }
    return 'idle';
  })();

  // Audio-reactive dynamic scalers
  const dynamicFactor = isMuted ? 0 : volume;
  const reactiveScale = 1 + (state === 'DISCONNECTED' ? 0 : dynamicFactor * 0.22 + bassLevel * 0.12);
  const ring1Scale = 1 + (state === 'DISCONNECTED' ? 0 : dynamicFactor * 0.35);
  const ring2Scale = 1 + (state === 'DISCONNECTED' ? 0 : dynamicFactor * 0.55);

  // Theme palettes and animations per visual mode
  const getThemeConfig = () => {
    switch (effectiveMode) {
      case 'tool_executing':
        return {
          coreGlow: 'bg-gradient-to-tr from-amber-500/50 via-cyan-400/40 to-yellow-300/30',
          outerBorder: 'border-amber-400/80 shadow-[0_0_60px_rgba(245,158,11,0.6)]',
          ring1Border: 'border-amber-400/70 border-dashed',
          ring2Border: 'border-cyan-400/60',
          accentColor: '#f59e0b',
          glowClass: 'glow-amber',
          spinSpeed1: 'animate-spin-fast',
          spinSpeed2: 'animate-spin-slow-reverse',
        };
      case 'processing':
        return {
          coreGlow: 'bg-gradient-to-tr from-amber-600/40 via-yellow-500/30 to-cyan-500/20',
          outerBorder: 'border-amber-400/70 shadow-[0_0_50px_rgba(245,158,11,0.5)]',
          ring1Border: 'border-amber-400/60 border-dashed',
          ring2Border: 'border-yellow-500/40',
          accentColor: '#fbbf24',
          glowClass: 'glow-amber',
          spinSpeed1: 'animate-spin-fast',
          spinSpeed2: 'animate-spin-slow-reverse',
        };
      case 'listening':
        return {
          coreGlow: 'bg-gradient-to-tr from-cyan-500/45 via-teal-400/35 to-sky-300/25',
          outerBorder: 'border-cyan-400/80 shadow-[0_0_65px_rgba(6,182,212,0.6)]',
          ring1Border: 'border-cyan-400/60 border-dashed',
          ring2Border: 'border-sky-400/40',
          accentColor: '#06b6d4',
          glowClass: 'glow-cyan',
          spinSpeed1: 'animate-spin-slow',
          spinSpeed2: 'animate-spin-slow-reverse',
        };
      case 'speaking':
        return {
          coreGlow: 'bg-gradient-to-tr from-fuchsia-600/50 via-purple-600/40 to-pink-500/30',
          outerBorder: 'border-fuchsia-400/80 shadow-[0_0_70px_rgba(217,70,239,0.6)]',
          ring1Border: 'border-fuchsia-400/70 border-dashed',
          ring2Border: 'border-purple-500/50',
          accentColor: '#d946ef',
          glowClass: 'glow-magenta',
          spinSpeed1: 'animate-spin-slow',
          spinSpeed2: 'animate-spin-slow-reverse',
        };
      case 'error':
        return {
          coreGlow: 'bg-gradient-to-tr from-red-600/45 via-rose-500/35 to-amber-600/25',
          outerBorder: 'border-red-400/80 shadow-[0_0_55px_rgba(239,68,68,0.55)]',
          ring1Border: 'border-red-400/60 border-dotted',
          ring2Border: 'border-rose-500/40',
          accentColor: '#ef4444',
          glowClass: 'glow-crimson',
          spinSpeed1: '',
          spinSpeed2: '',
        };
      case 'idle':
      default:
        return {
          coreGlow: state === 'DISCONNECTED'
            ? 'bg-gradient-to-tr from-slate-800/30 via-slate-900/50 to-cyan-950/15'
            : 'bg-gradient-to-tr from-cyan-950/40 via-slate-900/60 to-teal-950/25',
          outerBorder: state === 'DISCONNECTED'
            ? 'border-slate-700/40 shadow-[0_0_20px_rgba(71,85,105,0.2)]'
            : 'border-cyan-500/40 shadow-[0_0_35px_rgba(6,182,212,0.25)]',
          ring1Border: state === 'DISCONNECTED' ? 'border-slate-800/40 border-dotted' : 'border-cyan-500/30 border-dashed',
          ring2Border: state === 'DISCONNECTED' ? 'border-slate-850/20' : 'border-slate-700/30',
          accentColor: state === 'DISCONNECTED' ? '#64748b' : '#0891b2',
          glowClass: state === 'DISCONNECTED' ? 'glow-dormant' : 'glow-cyan',
          spinSpeed1: state === 'DISCONNECTED' ? '' : 'animate-spin-slow',
          spinSpeed2: state === 'DISCONNECTED' ? '' : 'animate-spin-slow-reverse',
        };
    }
  };

  const theme = getThemeConfig();

  return (
    <div
      id="nora-orb-command-center"
      className="relative flex items-center justify-center select-none"
      style={{ width: '320px', height: '320px' }}
    >
      {/* 1. Atmospheric Reactive Plasma Cloud */}
      <div
        className={`absolute rounded-full transition-all duration-300 ease-out ${theme.coreGlow} blur-3xl pointer-events-none ${
          effectiveMode === 'idle' ? 'animate-orb-breathe' : ''
        }`}
        style={{
          width: '300px',
          height: '300px',
          transform: `scale(${reactiveScale * 1.1})`,
          opacity: state === 'DISCONNECTED' ? 0.2 : 0.85,
        }}
      />

      {/* 2. Tool Execution Quantum Convergence Ripple */}
      {isToolExecuting && (
        <div
          className="absolute rounded-full border-2 border-amber-400 animate-ping pointer-events-none opacity-60"
          style={{ width: '280px', height: '280px' }}
        />
      )}

      {/* 3. Outer Gyroscopic Telemetry Ring with Cardinal Crosshair Markers */}
      <div
        className={`absolute rounded-full border ${theme.ring1Border} ${theme.spinSpeed1} transition-all duration-700 pointer-events-none`}
        style={{
          width: '290px',
          height: '290px',
          transform: `scale(${ring2Scale})`,
        }}
      >
        {/* Cardinal North/South/East/West Telemetry Nodes */}
        {state !== 'DISCONNECTED' && (
          <>
            <span
              className="absolute -top-1.5 left-1/2 -translate-x-1/2 h-3 w-3 rounded-full"
              style={{ backgroundColor: theme.accentColor, boxShadow: `0 0 14px ${theme.accentColor}` }}
            />
            <span
              className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 h-2.5 w-2.5 rounded-full opacity-80"
              style={{ backgroundColor: theme.accentColor, boxShadow: `0 0 10px ${theme.accentColor}` }}
            />
            <span
              className="absolute top-1/2 -left-1.5 -translate-y-1/2 h-2 w-2 rounded-full opacity-70"
              style={{ backgroundColor: theme.accentColor, boxShadow: `0 0 8px ${theme.accentColor}` }}
            />
            <span
              className="absolute top-1/2 -right-1.5 -translate-y-1/2 h-2 w-2 rounded-full opacity-70"
              style={{ backgroundColor: theme.accentColor, boxShadow: `0 0 8px ${theme.accentColor}` }}
            />
          </>
        )}
      </div>

      {/* 4. Counter-Rotating Inner Gyro Ring */}
      <div
        className={`absolute rounded-full border ${theme.ring2Border} ${theme.spinSpeed2} transition-all duration-700 pointer-events-none`}
        style={{
          width: '240px',
          height: '240px',
          transform: `scale(${ring1Scale})`,
        }}
      >
        {effectiveMode === 'processing' && (
          <span
            className="absolute top-0 right-4 h-2 w-2 rounded-full bg-amber-400 shadow-[0_0_10px_#fbbf24] animate-ping"
          />
        )}
      </div>

      {/* 5. Processing Radar Sweep Effect */}
      {effectiveMode === 'processing' && (
        <div
          className="absolute rounded-full overflow-hidden pointer-events-none animate-radar-sweep opacity-75"
          style={{
            width: '210px',
            height: '210px',
            background: 'conic-gradient(from 0deg, rgba(245, 158, 11, 0.4) 0deg, transparent 60deg, transparent 360deg)',
          }}
        />
      )}

      {/* 6. Subtle Vertical Scanning Laser in Processing Mode */}
      {effectiveMode === 'processing' && (
        <div
          className="absolute w-44 h-0.5 bg-gradient-to-r from-transparent via-amber-300 to-transparent animate-scan-laser pointer-events-none shadow-[0_0_12px_#fbbf24]"
        />
      )}

      {/* 7. Non-Textual Intelligent Tool Action Micro-Indicator */}
      {isToolExecuting && (
        <div
          className="absolute -top-4 z-30 flex items-center justify-center p-1.5 rounded-full bg-amber-950/90 border border-amber-400 shadow-[0_0_20px_rgba(245,158,11,0.8)] animate-bounce pointer-events-none"
        >
          {/* Futuristic geometric action diamond */}
          <div className="w-3 h-3 bg-amber-400 rotate-45 animate-spin-fast shadow-md" />
        </div>
      )}

      {/* 8. Central Dark Glass Obsidian Orb Core */}
      <div
        id="nora-orb-core"
        className={`relative flex items-center justify-center rounded-full border transition-all duration-300 ${theme.outerBorder} ${theme.glowClass} bg-[#060913]/90 backdrop-blur-2xl ${
          effectiveMode === 'idle' ? 'animate-orb-breathe' : ''
        }`}
        style={{
          width: '184px',
          height: '184px',
          transform: `scale(${reactiveScale})`,
        }}
      >
        {/* Inner Radial Ambient Mesh */}
        <div
          className={`absolute inset-1 rounded-full ${theme.coreGlow} blur-sm opacity-90 transition-all duration-500 pointer-events-none`}
        />

        {/* Concentric Precision HUD Ridge */}
        <div className="absolute inset-2.5 rounded-full border border-white/10 bg-gradient-to-b from-white/10 to-transparent pointer-events-none" />

        {/* Central Component Slot (Houses MicButton) */}
        <div className="relative z-10 flex items-center justify-center">
          {children}
        </div>
      </div>
    </div>
  );
};
