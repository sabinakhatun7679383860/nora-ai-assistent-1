/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useCallback } from 'react';
import { Mic, MicOff, Power, Loader2, Volume2, Sparkles } from 'lucide-react';
import { VoiceState, AssistantVisualMode } from '../types/assistant';

interface MicButtonProps {
  state: VoiceState;
  visualMode?: AssistantVisualMode;
  isMuted: boolean;
  onTogglePower: () => void;
  onToggleMute: () => void;
  onLongPress?: () => void;
  disabled?: boolean;
}

export const MicButton: React.FC<MicButtonProps> = ({
  state,
  visualMode,
  isMuted,
  onTogglePower,
  onToggleMute,
  onLongPress,
  disabled = false,
}) => {
  const isConnected = state !== 'DISCONNECTED';
  const [isPressing, setIsPressing] = useState(false);
  const [pressProgress, setPressProgress] = useState(0); // 0 to 100 for long press ring

  const pressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const progressAnimRef = useRef<number | null>(null);
  const pressStartTimeRef = useRef<number>(0);
  const longPressFiredRef = useRef<boolean>(false);

  const LONG_PRESS_DURATION = 550; // ms

  // Handle start of pointer/touch press
  const handlePointerDown = useCallback(
    (e: React.PointerEvent) => {
      if (disabled) return;
      // Capture pointer for consistent tracking
      try {
        (e.target as HTMLElement).setPointerCapture(e.pointerId);
      } catch {
        // Safe fallback
      }

      setIsPressing(true);
      setPressProgress(0);
      longPressFiredRef.current = false;
      pressStartTimeRef.current = performance.now();

      // Start progress animation frame loop
      const updateProgress = () => {
        const elapsed = performance.now() - pressStartTimeRef.current;
        const pct = Math.min(100, (elapsed / LONG_PRESS_DURATION) * 100);
        setPressProgress(pct);

        if (pct < 100) {
          progressAnimRef.current = requestAnimationFrame(updateProgress);
        }
      };
      progressAnimRef.current = requestAnimationFrame(updateProgress);

      // Long press timeout
      pressTimerRef.current = setTimeout(() => {
        longPressFiredRef.current = true;
        setPressProgress(100);

        // Haptic feedback if supported on mobile
        if (typeof navigator !== 'undefined' && 'vibrate' in navigator) {
          try {
            navigator.vibrate([25, 20]);
          } catch {
            // Ignore
          }
        }

        if (onLongPress) {
          onLongPress();
        } else if (state !== 'DISCONNECTED') {
          // If no custom long press, long press disconnects/powers down session
          onTogglePower();
        }
      }, LONG_PRESS_DURATION);
    },
    [disabled, onLongPress, onTogglePower, state]
  );

  // Clear press timers and animation
  const clearPressState = useCallback(() => {
    setIsPressing(false);
    setPressProgress(0);
    if (pressTimerRef.current) {
      clearTimeout(pressTimerRef.current);
      pressTimerRef.current = null;
    }
    if (progressAnimRef.current) {
      cancelAnimationFrame(progressAnimRef.current);
      progressAnimRef.current = null;
    }
  }, []);

  // Handle pointer release
  const handlePointerUp = useCallback(
    (e: React.PointerEvent) => {
      if (disabled) return;

      const wasLongPress = longPressFiredRef.current;
      clearPressState();

      // If it wasn't a long press, execute standard tap action!
      if (!wasLongPress) {
        if (state === 'DISCONNECTED') {
          onTogglePower();
        } else if (state === 'CONNECTING') {
          onTogglePower();
        } else {
          // Connected: Toggle Start/Stop or Mute/Unmute
          onToggleMute();
        }
      }
    },
    [disabled, clearPressState, state, onTogglePower, onToggleMute]
  );

  const handlePointerCancel = useCallback(() => {
    clearPressState();
  }, [clearPressState]);

  // Render icon based on state
  const renderIcon = () => {
    if (state === 'CONNECTING' || visualMode === 'processing') {
      return <Loader2 className="h-10 w-10 text-amber-300 animate-spin" />;
    }
    if (state === 'SPEAKING' || visualMode === 'speaking') {
      return <Volume2 className="h-10 w-10 text-fuchsia-200 animate-pulse drop-shadow-[0_0_10px_rgba(217,70,239,0.9)]" />;
    }
    if (state === 'LISTENING' || visualMode === 'listening') {
      if (isMuted) {
        return <MicOff className="h-10 w-10 text-rose-400 drop-shadow-[0_0_8px_rgba(244,63,94,0.8)]" />;
      }
      return <Mic className="h-10 w-10 text-cyan-200 drop-shadow-[0_0_12px_rgba(6,182,212,0.9)]" />;
    }
    return <Power className="h-10 w-10 text-slate-400 group-hover:text-cyan-300 transition-colors" />;
  };

  // Button styling
  const getButtonStyles = () => {
    if (state === 'DISCONNECTED') {
      return 'bg-gradient-to-b from-slate-900/90 via-[#0a0f1d]/95 to-slate-950/95 border-slate-700/60 text-slate-400 hover:border-cyan-500/50 hover:shadow-[0_0_30px_rgba(6,182,212,0.3)] active:scale-95';
    }
    if (state === 'CONNECTING' || visualMode === 'processing') {
      return 'bg-gradient-to-b from-amber-950/80 to-slate-950/90 border-amber-400/80 shadow-[0_0_35px_rgba(245,158,11,0.4)]';
    }
    if (state === 'SPEAKING' || visualMode === 'speaking') {
      return 'bg-gradient-to-b from-fuchsia-950/80 to-purple-950/90 border-fuchsia-400/80 shadow-[0_0_40px_rgba(217,70,239,0.5)]';
    }
    if (isMuted) {
      return 'bg-gradient-to-b from-rose-950/80 to-slate-950/90 border-rose-500/70 shadow-[0_0_25px_rgba(244,63,94,0.35)]';
    }
    return 'bg-gradient-to-b from-cyan-950/90 via-[#071929]/95 to-slate-950/90 border-cyan-400/80 shadow-[0_0_40px_rgba(6,182,212,0.55)]';
  };

  const circumference = 2 * Math.PI * 46; // Radius 46 for 96px button
  const strokeDashoffset = circumference - (pressProgress / 100) * circumference;

  return (
    <div className="relative group flex items-center justify-center">
      {/* SVG Circular Long-Press Progress Track */}
      {isPressing && pressProgress > 0 && (
        <svg
          className="absolute -inset-1.5 w-[108px] h-[108px] -rotate-90 pointer-events-none z-30"
          viewBox="0 0 108 108"
        >
          <circle
            cx="54"
            cy="54"
            r="49"
            className="stroke-cyan-500/20 fill-none"
            strokeWidth="3"
          />
          <circle
            cx="54"
            cy="54"
            r="49"
            className="stroke-cyan-400 fill-none transition-all duration-75"
            strokeWidth="3.5"
            strokeDasharray={2 * Math.PI * 49}
            strokeDashoffset={2 * Math.PI * 49 - (pressProgress / 100) * (2 * Math.PI * 49)}
            strokeLinecap="round"
          />
        </svg>
      )}

      {/* Main Central Tactile Command Button */}
      <button
        id="nora-mic-central-button"
        type="button"
        onPointerDown={handlePointerDown}
        onPointerUp={handlePointerUp}
        onPointerCancel={handlePointerCancel}
        onPointerLeave={handlePointerCancel}
        disabled={disabled}
        aria-label={
          state === 'DISCONNECTED'
            ? 'Connect NORA Assistant'
            : isConnected && isMuted
            ? 'Unmute Microphone'
            : 'Mute Microphone'
        }
        className={`relative z-20 flex h-24 w-24 min-h-[44px] min-w-[44px] items-center justify-center rounded-full border-2 transition-all duration-200 cursor-pointer focus:outline-none focus:ring-2 focus:ring-cyan-400/40 select-none ${getButtonStyles()} ${
          isPressing ? 'scale-95 brightness-110' : ''
        }`}
      >
        {/* Subtle metallic bezel highlight */}
        <div className="absolute inset-1 rounded-full bg-gradient-to-b from-white/20 via-transparent to-black/30 pointer-events-none" />

        {/* Dynamic Center Icon */}
        <div className="relative z-10 flex items-center justify-center">
          {renderIcon()}
        </div>
      </button>

      {/* Button Action Tag on Hover/Desktop */}
      <div className="absolute -bottom-8 left-1/2 -translate-x-1/2 whitespace-nowrap text-[10px] font-mono tracking-widest text-slate-400 uppercase opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
        {state === 'DISCONNECTED'
          ? 'TAP TO ACTIVATE'
          : isMuted
          ? 'TAP TO UNMUTE'
          : 'TAP TO MUTE'}
      </div>
    </div>
  );
};
