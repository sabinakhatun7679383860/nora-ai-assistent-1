/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Key,
  Trash2,
  Edit3,
  ExternalLink,
  ShieldCheck,
  Terminal,
  X,
  CheckCircle2,
  Cpu,
  Radio,
  Wifi,
  Brain,
  Sliders,
} from 'lucide-react';
import { maskApiKey } from '../services/apiKeyStorage';
import { BrainMemoryPanel } from './BrainMemoryPanel';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedApiKey: string | null;
  onChangeApiKey: () => void;
  onRemoveApiKey: () => void;
  latencyMs: number;
  voiceState: string;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  savedApiKey,
  onChangeApiKey,
  onRemoveApiKey,
  latencyMs,
  voiceState,
}) => {
  const [modalTab, setModalTab] = useState<'brain' | 'system'>('brain');
  const [confirmRemove, setConfirmRemove] = useState<boolean>(false);

  if (!isOpen) return null;

  const handleOpenGoogleAIStudio = () => {
    window.open('https://aistudio.google.com/apikey', '_blank', 'noopener,noreferrer');
  };

  const handleConfirmRemove = () => {
    onRemoveApiKey();
    setConfirmRemove(false);
  };

  return (
    <div
      id="nora-settings-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/85 backdrop-blur-lg animate-in fade-in"
      onClick={onClose}
    >
      <div
        id="nora-settings-modal"
        className="relative w-full max-w-xl bg-[#090d16] border border-cyan-500/30 rounded-2xl p-4 sm:p-6 shadow-2xl space-y-4 max-h-[92vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-white/10 pb-3">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/30">
              <Sparkles className="h-4 w-4 text-cyan-400" />
            </div>
            <div>
              <h3 className="font-display text-base sm:text-lg font-bold tracking-wide text-white">
                NORA Control Center
              </h3>
              <p className="text-[10px] font-mono text-slate-400 uppercase">
                3-Level Brain Memory &amp; System Configuration
              </p>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="text-slate-400 hover:text-white text-sm font-mono p-2 cursor-pointer min-h-[44px] min-w-[44px] flex items-center justify-center rounded-lg hover:bg-slate-800"
            aria-label="Close modal"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Top Tab Bar: Brain & Memory vs System */}
        <div className="flex items-center gap-2 p-1 bg-slate-950 border border-slate-800/90 rounded-xl">
          <button
            type="button"
            onClick={() => setModalTab('brain')}
            className={`flex-1 min-h-[44px] px-3 py-2 rounded-lg text-xs font-mono font-semibold cursor-pointer transition-all flex items-center justify-center gap-2 ${
              modalTab === 'brain'
                ? 'bg-cyan-500/25 border border-cyan-400/60 text-cyan-200 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Brain className="h-4 w-4 text-cyan-400" />
            <span>🧠 3-Level Brain &amp; Memory</span>
          </button>

          <button
            type="button"
            onClick={() => setModalTab('system')}
            className={`flex-1 min-h-[44px] px-3 py-2 rounded-lg text-xs font-mono font-semibold cursor-pointer transition-all flex items-center justify-center gap-2 ${
              modalTab === 'system'
                ? 'bg-cyan-500/25 border border-cyan-400/60 text-cyan-200 shadow-sm'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sliders className="h-4 w-4 text-cyan-400" />
            <span>⚙️ API &amp; System</span>
          </button>
        </div>

        {/* TAB 1: BRAIN & MEMORY PANEL */}
        {modalTab === 'brain' && (
          <div className="animate-in fade-in">
            <BrainMemoryPanel />
          </div>
        )}

        {/* TAB 2: SYSTEM & API KEY PANEL */}
        {modalTab === 'system' && (
          <div className="space-y-3.5 animate-in fade-in">
            {/* Section 1: API Key Management */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs font-mono font-semibold text-cyan-300 uppercase">
                  <Key className="h-4 w-4 text-cyan-400" />
                  <span>Gemini API Key</span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                  {savedApiKey ? 'Active' : 'Not Set'}
                </span>
              </div>

              <div className="flex items-center justify-between bg-slate-900/90 border border-slate-800/80 rounded-lg p-2.5">
                <div className="text-xs font-mono text-slate-300 truncate">
                  {maskApiKey(savedApiKey)}
                </div>
                <span className="text-[10px] font-mono text-slate-500 shrink-0 pl-2">
                  Encrypted LocalStorage
                </span>
              </div>

              {/* Action Buttons for API Key */}
              <div className="flex flex-wrap items-center gap-2 pt-1">
                <button
                  type="button"
                  onClick={onChangeApiKey}
                  className="flex-1 min-h-[44px] px-3 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                >
                  <Edit3 className="h-3.5 w-3.5" />
                  <span>Change Key</span>
                </button>

                {savedApiKey && (
                  <>
                    {!confirmRemove ? (
                      <button
                        type="button"
                        onClick={() => setConfirmRemove(true)}
                        className="min-h-[44px] px-3 py-2 rounded-xl bg-rose-500/15 hover:bg-rose-500/25 border border-rose-500/40 text-rose-300 text-xs font-mono font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>Remove</span>
                      </button>
                    ) : (
                      <div className="flex items-center gap-1.5 w-full sm:w-auto">
                        <button
                          type="button"
                          onClick={handleConfirmRemove}
                          className="flex-1 min-h-[44px] px-3 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-semibold transition-all cursor-pointer"
                        >
                          Confirm Delete
                        </button>
                        <button
                          type="button"
                          onClick={() => setConfirmRemove(false)}
                          className="min-h-[44px] px-2.5 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-mono"
                        >
                          Cancel
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>

              <div className="pt-1 flex items-center justify-between text-[11px] text-slate-400">
                <button
                  type="button"
                  onClick={handleOpenGoogleAIStudio}
                  className="inline-flex items-center gap-1 text-cyan-400 hover:underline cursor-pointer min-h-[36px]"
                >
                  <span>Get API Key from Google AI Studio</span>
                  <ExternalLink className="h-3 w-3" />
                </button>
              </div>
            </div>

            {/* Section 2: Real-Time Telemetry & Status */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2.5">
              <div className="flex items-center gap-2 text-xs font-mono font-semibold text-cyan-300 uppercase">
                <Radio className="h-4 w-4 text-cyan-400" />
                <span>Live Session Diagnostics</span>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs font-mono">
                <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">VOICE STATE</span>
                  <span className="text-cyan-300 font-semibold">{voiceState}</span>
                </div>
                <div className="bg-slate-900/80 p-2 rounded-lg border border-slate-800">
                  <span className="text-[10px] text-slate-400 block">ROUNDTRIP LATENCY</span>
                  <span className="text-cyan-300 font-semibold">{latencyMs}ms</span>
                </div>
              </div>
            </div>

            {/* Section 3: System Pipeline Specifications */}
            <div className="p-4 rounded-xl bg-slate-950/80 border border-slate-800 space-y-2">
              <div className="text-[11px] font-mono text-cyan-300 uppercase flex items-center gap-1.5">
                <Terminal className="h-3.5 w-3.5" />
                <span>NORA 3-Level Architecture Specs:</span>
              </div>
              <ul className="list-disc list-inside space-y-1 text-slate-400 text-[11px]">
                <li>
                  <strong className="text-slate-300">Level 1 (Short-Term):</strong> In-Memory turn history &amp; pronoun resolution
                </li>
                <li>
                  <strong className="text-slate-300">Level 2 (Long-Term):</strong> IndexedDB persistent personal &amp; language preferences
                </li>
                <li>
                  <strong className="text-slate-300">Level 3 (Project Brain):</strong> Dedicated project goals, architecture &amp; technical specs
                </li>
                <li>
                  <strong className="text-slate-300">Audio Pipeline:</strong> 16kHz PCM continuous capture &amp; 24kHz Web Audio scheduler
                </li>
                <li>
                  <strong className="text-slate-300">Zero-Leak Privacy:</strong> Device-local memory with credential stripping
                </li>
              </ul>
            </div>
          </div>
        )}

        {/* Footer */}
        <div className="pt-2 flex justify-end border-t border-white/10">
          <button
            type="button"
            onClick={onClose}
            className="min-h-[44px] px-6 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-mono text-xs font-semibold cursor-pointer active:scale-95 shadow-md"
          >
            CLOSE
          </button>
        </div>
      </div>
    </div>
  );
};
