/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Key,
  Eye,
  EyeOff,
  ClipboardPaste,
  ExternalLink,
  ShieldCheck,
  AlertCircle,
  ArrowLeft,
  Loader2,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import { BackgroundEffects } from './BackgroundEffects';

interface ApiKeySetupScreenProps {
  initialKey?: string;
  onConnect: (apiKey: string) => Promise<void>;
  onCancel?: () => void;
  errorMessage?: string | null;
  onClearError?: () => void;
}

export const ApiKeySetupScreen: React.FC<ApiKeySetupScreenProps> = ({
  initialKey = '',
  onConnect,
  onCancel,
  errorMessage: externalError,
  onClearError,
}) => {
  const [apiKeyInput, setApiKeyInput] = useState<string>(initialKey);
  const [showKey, setShowKey] = useState<boolean>(false);
  const [isValidating, setIsValidating] = useState<boolean>(false);
  const [localError, setLocalError] = useState<string | null>(null);
  const [pasteSuccess, setPasteSuccess] = useState<boolean>(false);

  // Clear errors when typing
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setApiKeyInput(e.target.value);
    if (localError) setLocalError(null);
    if (externalError && onClearError) onClearError();
  };

  // Paste API key from clipboard
  const handlePaste = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.readText) {
        const text = await navigator.clipboard.readText();
        const trimmed = text.trim();
        if (trimmed) {
          setApiKeyInput(trimmed);
          setPasteSuccess(true);
          setTimeout(() => setPasteSuccess(false), 2000);
          if (localError) setLocalError(null);
          if (externalError && onClearError) onClearError();
        } else {
          setLocalError('Clipboard is empty.');
        }
      } else {
        setLocalError('Clipboard access is not permitted in this browser.');
      }
    } catch (err) {
      setLocalError('Could not read from clipboard. Please paste manually.');
    }
  };

  // Form submission / Connect NORA
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanKey = apiKeyInput.trim();

    if (!cleanKey) {
      setLocalError('Please enter your Gemini API key to continue.');
      return;
    }

    if (cleanKey.length < 10) {
      setLocalError('The provided key appears too short. Please verify your Gemini API key.');
      return;
    }

    // Check offline status
    if (typeof navigator !== 'undefined' && !navigator.onLine) {
      setLocalError('No Internet Connection. NORA requires an active network connection to connect to Gemini Live.');
      return;
    }

    setLocalError(null);
    if (onClearError) onClearError();
    setIsValidating(true);

    try {
      await onConnect(cleanKey);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to connect. Please check your Gemini API key.';
      setLocalError(msg);
    } finally {
      setIsValidating(false);
    }
  };

  // Open Google AI Studio API key creation page directly
  const handleOpenGoogleAIStudio = () => {
    window.open('https://aistudio.google.com/apikey', '_blank', 'noopener,noreferrer');
  };

  const activeError = localError || externalError;

  return (
    <div
      id="nora-api-setup-screen"
      className="relative min-h-[100dvh] w-full flex flex-col justify-between overflow-hidden bg-[#06080e] text-slate-100 select-none touch-manipulation animate-in fade-in duration-300"
    >
      {/* Background Cyber Grid */}
      <BackgroundEffects state="DISCONNECTED" audioVolume={0.02} />

      {/* Cybernetic HUD Corner Accents */}
      <div className="hud-corner-tl m-2 sm:m-3" />
      <div className="hud-corner-tr m-2 sm:m-3" />
      <div className="hud-corner-bl m-2 sm:m-3" />
      <div className="hud-corner-br m-2 sm:m-3" />

      {/* Top Header */}
      <header className="relative z-20 w-full px-4 sm:px-6 pt-safe pb-2 sm:py-3.5 flex items-center justify-between border-b border-white/5 bg-[#06080e]/60 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          {onCancel && (
            <button
              type="button"
              onClick={onCancel}
              className="p-2 min-h-[44px] min-w-[44px] flex items-center justify-center rounded-xl bg-slate-900/80 hover:bg-slate-800 border border-slate-800 text-slate-400 hover:text-slate-200 transition-colors cursor-pointer"
              aria-label="Back to welcome screen"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
          )}
          <div className="flex items-center gap-2">
            <div className="relative flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-950/80 border border-cyan-500/40 shadow-sm">
              <Sparkles className="h-4 w-4 text-cyan-400" />
            </div>
            <span className="font-display text-lg sm:text-xl font-bold tracking-wider text-white">
              NORA
            </span>
          </div>
        </div>

        <div className="flex items-center gap-1.5 text-xs font-mono text-cyan-400 bg-cyan-950/40 border border-cyan-500/30 px-3 py-1.5 rounded-full">
          <Lock className="h-3.5 w-3.5 text-cyan-400" />
          <span>DEVICE SECURE</span>
        </div>
      </header>

      {/* Main Setup Card Container */}
      <main className="relative z-10 flex-1 flex flex-col items-center justify-center px-4 py-6 max-w-md mx-auto w-full">
        <div className="w-full bg-[#090d16]/95 border border-cyan-500/30 rounded-3xl p-6 sm:p-7 shadow-[0_0_50px_rgba(6,182,212,0.15)] backdrop-blur-2xl space-y-5">
          {/* Header Visual & Title */}
          <div className="text-center space-y-2">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-950/80 border border-cyan-400/50 shadow-[0_0_20px_rgba(6,182,212,0.35)]">
              <Key className="h-7 w-7 text-cyan-400 animate-pulse" />
            </div>
            <h2 className="font-display text-2xl font-bold tracking-wide text-white">
              Connect Gemini
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 leading-relaxed font-sans">
              NORA needs your Gemini API key to start the Live voice assistant.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Input Field Container */}
            <div className="space-y-1.5">
              <label htmlFor="gemini-api-key-input" className="block text-[11px] font-mono font-medium text-cyan-300 uppercase tracking-wider">
                Gemini API Key
              </label>

              <div className="relative flex items-center">
                <input
                  id="gemini-api-key-input"
                  type={showKey ? 'text' : 'password'}
                  value={apiKeyInput}
                  onChange={handleInputChange}
                  placeholder="AIzaSy..."
                  autoComplete="off"
                  spellCheck="false"
                  disabled={isValidating}
                  className="w-full min-h-[48px] pl-3.5 pr-20 py-2.5 rounded-xl bg-slate-950/90 border border-cyan-500/40 text-slate-100 text-sm font-mono placeholder:text-slate-600 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-500/30 transition-all disabled:opacity-50"
                />

                {/* Right Action Icons (Toggle Show/Hide & Quick Paste) */}
                <div className="absolute right-1.5 flex items-center gap-1">
                  <button
                    type="button"
                    onClick={() => setShowKey(!showKey)}
                    className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer rounded-lg hover:bg-slate-900"
                    title={showKey ? 'Hide key' : 'Show key'}
                    aria-label={showKey ? 'Hide API key' : 'Show API key'}
                  >
                    {showKey ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>

                  <button
                    type="button"
                    onClick={handlePaste}
                    className="p-2 min-h-[40px] min-w-[40px] flex items-center justify-center text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer rounded-lg hover:bg-slate-900"
                    title="Paste API Key"
                    aria-label="Paste API key from clipboard"
                  >
                    {pasteSuccess ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    ) : (
                      <ClipboardPaste className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>
            </div>

            {/* Error Banner */}
            {activeError && (
              <div
                id="nora-api-setup-error"
                className="flex items-start gap-2.5 p-3 rounded-xl bg-rose-950/80 border border-rose-500/50 text-rose-200 text-xs shadow-lg animate-in fade-in"
              >
                <AlertCircle className="h-4 w-4 shrink-0 text-rose-400 mt-0.5" />
                <div className="flex-1 text-[11px] leading-relaxed">
                  <p className="font-semibold text-rose-300">Connection Failed</p>
                  <p>{activeError}</p>
                </div>
              </div>
            )}

            {/* Quick Paste Button (Explicit text button) */}
            <div className="flex items-center justify-between pt-1">
              <button
                type="button"
                onClick={handlePaste}
                className="inline-flex items-center gap-1.5 text-[11px] font-mono text-cyan-400 hover:text-cyan-300 transition-colors cursor-pointer min-h-[36px]"
              >
                <ClipboardPaste className="h-3.5 w-3.5" />
                <span>Paste from Clipboard</span>
              </button>

              {/* Get API Key Link */}
              <button
                type="button"
                onClick={handleOpenGoogleAIStudio}
                className="inline-flex items-center gap-1 text-[11px] font-mono text-slate-400 hover:text-cyan-300 transition-colors cursor-pointer min-h-[36px]"
              >
                <span>Get API Key</span>
                <ExternalLink className="h-3 w-3" />
              </button>
            </div>

            {/* Primary Action Button: "Connect NORA" */}
            <div className="pt-2">
              <button
                id="nora-api-connect-button"
                type="submit"
                disabled={isValidating}
                className="w-full min-h-[50px] px-6 py-3 rounded-xl bg-gradient-to-r from-cyan-500 via-cyan-400 to-teal-400 hover:from-cyan-400 hover:to-teal-300 disabled:from-slate-800 disabled:to-slate-800 disabled:text-slate-500 text-slate-950 font-display font-bold text-sm tracking-wider shadow-[0_0_25px_rgba(6,182,212,0.4)] active:scale-[0.98] transition-all flex items-center justify-center gap-2 cursor-pointer"
              >
                {isValidating ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin text-slate-950" />
                    <span>TESTING &amp; CONNECTING...</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="h-4 w-4" />
                    <span>CONNECT NORA</span>
                  </>
                )}
              </button>
            </div>
          </form>

          {/* Security & Official Instructions Section */}
          <div className="pt-2 border-t border-white/5 space-y-2 text-[11px] text-slate-400 font-sans">
            <div className="flex items-center gap-1.5 text-cyan-400 font-mono text-[11px]">
              <ShieldCheck className="h-3.5 w-3.5" />
              <span>Security Guarantee</span>
            </div>
            <p className="text-[11px] text-slate-400 leading-normal">
              Your API key is stored locally in your browser only. It is never logged, tracked, or shared with third parties.
            </p>

            <div className="pt-2">
              <a
                href="https://aistudio.google.com/apikey"
                target="_blank"
                rel="noopener noreferrer"
                className="w-full min-h-[44px] px-4 py-2 rounded-xl bg-slate-900/90 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white text-xs font-mono flex items-center justify-center gap-2 transition-colors cursor-pointer"
              >
                <span>Open Google AI Studio</span>
                <ExternalLink className="h-3.5 w-3.5 text-cyan-400" />
              </a>
            </div>
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="relative z-20 w-full px-4 sm:px-6 py-3 border-t border-white/5 bg-[#06080e]/80 backdrop-blur-md flex items-center justify-center text-[11px] font-mono text-slate-500">
        <span>Official Google AI Studio API: https://aistudio.google.com/apikey</span>
      </footer>
    </div>
  );
};
