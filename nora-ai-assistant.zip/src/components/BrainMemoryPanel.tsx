/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useMemo } from 'react';
import {
  Brain,
  Search,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  ShieldCheck,
  FolderGit2,
  Sparkles,
  ToggleLeft,
  ToggleRight,
  AlertTriangle,
  Clock,
  Star,
  Layers,
  Database,
  RefreshCw,
} from 'lucide-react';
import { NoraMemory, NoraMemoryCategory, NoraProject, NoraBrainSettings } from '../types/memory';
import { defaultMemoryService } from '../services/MemoryService';

interface BrainMemoryPanelProps {
  onMemoryUpdated?: () => void;
}

const CATEGORY_COLORS: Record<NoraMemoryCategory, { bg: string; text: string; border: string }> = {
  preference: { bg: 'bg-purple-500/15', text: 'text-purple-300', border: 'border-purple-500/30' },
  language: { bg: 'bg-emerald-500/15', text: 'text-emerald-300', border: 'border-emerald-500/30' },
  project: { bg: 'bg-cyan-500/15', text: 'text-cyan-300', border: 'border-cyan-500/30' },
  instruction: { bg: 'bg-amber-500/15', text: 'text-amber-300', border: 'border-amber-500/30' },
  useful_fact: { bg: 'bg-blue-500/15', text: 'text-blue-300', border: 'border-blue-500/30' },
  workflow: { bg: 'bg-indigo-500/15', text: 'text-indigo-300', border: 'border-indigo-500/30' },
  other: { bg: 'bg-slate-500/15', text: 'text-slate-300', border: 'border-slate-500/30' },
};

export const BrainMemoryPanel: React.FC<BrainMemoryPanelProps> = ({ onMemoryUpdated }) => {
  const [activeTab, setActiveTab] = useState<'memories' | 'projects' | 'settings'>('memories');
  const [settings, setSettings] = useState<NoraBrainSettings>(defaultMemoryService.getBrainSettings());
  const [memories, setMemories] = useState<NoraMemory[]>([]);
  const [projects, setProjects] = useState<NoraProject[]>([]);
  const [selectedProjectId, setSelectedProjectId] = useState<string>('proj_nora_core');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [isLoading, setIsLoading] = useState<boolean>(true);

  // Modal / Inline Add & Edit state
  const [isAddMemoryOpen, setIsAddMemoryOpen] = useState<boolean>(false);
  const [editingMemoryId, setEditingMemoryId] = useState<string | null>(null);
  const [editContent, setEditContent] = useState<string>('');
  const [editCategory, setEditCategory] = useState<NoraMemoryCategory>('preference');
  const [editImportance, setEditImportance] = useState<number>(3);
  const [editProjectName, setEditProjectName] = useState<string>('');

  // Clear confirmation
  const [confirmClearAll, setConfirmClearAll] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Project detail addition states
  const [newFeatureText, setNewFeatureText] = useState<string>('');
  const [newGoalText, setNewGoalText] = useState<string>('');
  const [newTechText, setNewTechText] = useState<string>('');

  const loadData = async () => {
    setIsLoading(true);
    try {
      await defaultMemoryService.initializeMemoryDB();
      const currentSettings = defaultMemoryService.getBrainSettings();
      const allMemories = await defaultMemoryService.getAllMemories();
      const allProjects = await defaultMemoryService.getAllProjects();

      setSettings(currentSettings);
      setMemories(allMemories);
      setProjects(allProjects);
      if (allProjects.length > 0 && !selectedProjectId) {
        setSelectedProjectId(allProjects[0].id);
      }
    } catch (err) {
      console.warn('[BrainMemoryPanel] Load error:', err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleSetting = async (key: keyof NoraBrainSettings) => {
    const updated = { ...settings, [key]: !settings[key] };
    setSettings(updated);
    await defaultMemoryService.updateBrainSettings(updated);
    onMemoryUpdated?.();
  };

  const handleSaveNewMemory = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editContent.trim()) return;

    setErrorMessage(null);
    try {
      let projId: string | undefined;
      if (editProjectName.trim()) {
        const proj = await defaultMemoryService.findProjectByName(editProjectName.trim());
        if (proj) projId = proj.id;
      }

      await defaultMemoryService.saveMemory({
        content: editContent.trim(),
        category: editCategory,
        importance: editImportance,
        projectName: editProjectName.trim() || undefined,
        projectId: projId,
        source: 'user',
      });

      setEditContent('');
      setIsAddMemoryOpen(false);
      await loadData();
      onMemoryUpdated?.();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to save memory.');
    }
  };

  const handleStartEdit = (mem: NoraMemory) => {
    setEditingMemoryId(mem.id);
    setEditContent(mem.content);
    setEditCategory(mem.category);
    setEditImportance(mem.importance);
    setEditProjectName(mem.projectName || '');
  };

  const handleSaveEdit = async () => {
    if (!editingMemoryId || !editContent.trim()) return;

    setErrorMessage(null);
    try {
      await defaultMemoryService.updateMemory(editingMemoryId, {
        content: editContent.trim(),
        category: editCategory,
        importance: editImportance,
        projectName: editProjectName.trim() || undefined,
      });

      setEditingMemoryId(null);
      setEditContent('');
      await loadData();
      onMemoryUpdated?.();
    } catch (err: any) {
      setErrorMessage(err?.message || 'Failed to update memory.');
    }
  };

  const handleDeleteMemory = async (id: string) => {
    await defaultMemoryService.deleteMemory(id);
    await loadData();
    onMemoryUpdated?.();
  };

  const handleClearAll = async () => {
    await defaultMemoryService.clearAllMemories();
    setConfirmClearAll(false);
    await loadData();
    onMemoryUpdated?.();
  };

  // Filtered memories based on search and category
  const filteredMemories = useMemo(() => {
    return memories.filter((mem) => {
      const matchCat = selectedCategory === 'all' || mem.category === selectedCategory;
      const matchSearch =
        !searchQuery.trim() ||
        mem.content.toLowerCase().includes(searchQuery.toLowerCase()) ||
        mem.category.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (mem.projectName && mem.projectName.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchCat && matchSearch;
    });
  }, [memories, selectedCategory, searchQuery]);

  const activeProject = useMemo(() => {
    return projects.find((p) => p.id === selectedProjectId) || projects[0];
  }, [projects, selectedProjectId]);

  const handleAddProjectFeature = async () => {
    if (!newFeatureText.trim() || !activeProject) return;
    const updated = {
      ...activeProject,
      features: [...activeProject.features, newFeatureText.trim()],
    };
    await defaultMemoryService.saveProject(updated);
    setNewFeatureText('');
    await loadData();
    onMemoryUpdated?.();
  };

  const handleAddProjectGoal = async () => {
    if (!newGoalText.trim() || !activeProject) return;
    const updated = {
      ...activeProject,
      goals: [...activeProject.goals, newGoalText.trim()],
    };
    await defaultMemoryService.saveProject(updated);
    setNewGoalText('');
    await loadData();
    onMemoryUpdated?.();
  };

  const handleAddProjectTech = async () => {
    if (!newTechText.trim() || !activeProject) return;
    const updated = {
      ...activeProject,
      technicalDecisions: [...activeProject.technicalDecisions, newTechText.trim()],
    };
    await defaultMemoryService.saveProject(updated);
    setNewTechText('');
    await loadData();
    onMemoryUpdated?.();
  };

  const formatDate = (isoStr?: string) => {
    if (!isoStr) return 'Just now';
    try {
      const d = new Date(isoStr);
      return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    } catch {
      return isoStr;
    }
  };

  return (
    <div className="space-y-4 text-slate-200">
      {/* Brain Header Summary & Navigation */}
      <div className="p-3.5 rounded-xl bg-slate-950/90 border border-cyan-500/25 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-lg bg-cyan-500/20 text-cyan-400 border border-cyan-500/30">
              <Brain className="h-4 w-4" />
            </div>
            <div>
              <div className="text-xs font-mono font-bold text-white flex items-center gap-2">
                <span>3-LEVEL AI BRAIN &amp; MEMORY</span>
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded font-mono uppercase ${
                    settings.memoryEnabled ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'
                  }`}
                >
                  {settings.memoryEnabled ? 'Active' : 'Disabled'}
                </span>
              </div>
              <p className="text-[10px] text-slate-400 font-mono">
                IndexedDB Private Neural Storage • Bilingual Recall
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={() => handleToggleSetting('memoryEnabled')}
            className="cursor-pointer text-cyan-400 hover:text-cyan-300 min-h-[44px] min-w-[44px] flex items-center justify-center"
            title={settings.memoryEnabled ? 'Disable Memory Engine' : 'Enable Memory Engine'}
          >
            {settings.memoryEnabled ? (
              <ToggleRight className="h-7 w-7 text-cyan-400" />
            ) : (
              <ToggleLeft className="h-7 w-7 text-slate-600" />
            )}
          </button>
        </div>

        {/* Level Quick Toggles */}
        <div className="grid grid-cols-3 gap-2 pt-1">
          <button
            type="button"
            onClick={() => handleToggleSetting('shortTermMemory')}
            className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
              settings.shortTermMemory
                ? 'bg-cyan-950/40 border-cyan-500/40 text-cyan-300'
                : 'bg-slate-900/50 border-slate-800 text-slate-500'
            }`}
          >
            <span className="text-[10px] font-mono block uppercase">Level 1</span>
            <span className="text-xs font-semibold block">Short-Term</span>
          </button>

          <button
            type="button"
            onClick={() => handleToggleSetting('longTermMemory')}
            className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
              settings.longTermMemory
                ? 'bg-purple-950/40 border-purple-500/40 text-purple-300'
                : 'bg-slate-900/50 border-slate-800 text-slate-500'
            }`}
          >
            <span className="text-[10px] font-mono block uppercase">Level 2</span>
            <span className="text-xs font-semibold block">Long-Term</span>
          </button>

          <button
            type="button"
            onClick={() => handleToggleSetting('projectBrain')}
            className={`p-2 rounded-lg border text-left cursor-pointer transition-all ${
              settings.projectBrain
                ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-300'
                : 'bg-slate-900/50 border-slate-800 text-slate-500'
            }`}
          >
            <span className="text-[10px] font-mono block uppercase">Level 3</span>
            <span className="text-xs font-semibold block">Project Brain</span>
          </button>
        </div>

        {/* Navigation Tabs */}
        <div className="flex border-b border-slate-800 pt-1">
          <button
            type="button"
            onClick={() => setActiveTab('memories')}
            className={`flex-1 py-2 text-xs font-mono font-semibold cursor-pointer border-b-2 text-center transition-all ${
              activeTab === 'memories'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Memories ({memories.length})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('projects')}
            className={`flex-1 py-2 text-xs font-mono font-semibold cursor-pointer border-b-2 text-center transition-all ${
              activeTab === 'projects'
                ? 'border-cyan-400 text-cyan-300'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            Project Brain ({projects.length})
          </button>
        </div>
      </div>

      {/* Error / Warning Alert */}
      {errorMessage && (
        <div className="p-3 rounded-lg bg-rose-500/15 border border-rose-500/40 text-rose-300 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button
            type="button"
            onClick={() => setErrorMessage(null)}
            className="text-rose-300 hover:text-white"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}

      {/* TAB 1: MEMORIES MANAGEMENT */}
      {activeTab === 'memories' && (
        <div className="space-y-3">
          {/* Controls Bar: Search & Add */}
          <div className="flex flex-col sm:flex-row gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search memories (Bengali / English / Hindi)..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700/80 rounded-xl pl-9 pr-3 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
              />
              {searchQuery && (
                <button
                  type="button"
                  onClick={() => setSearchQuery('')}
                  className="absolute right-3 top-2.5 text-slate-400 hover:text-white"
                >
                  <X className="h-3.5 w-3.5" />
                </button>
              )}
            </div>

            <button
              type="button"
              onClick={() => {
                setEditingMemoryId(null);
                setEditContent('');
                setIsAddMemoryOpen(true);
              }}
              className="min-h-[44px] px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-cyan-200 text-xs font-mono font-semibold transition-all cursor-pointer flex items-center justify-center gap-1.5 shrink-0"
            >
              <Plus className="h-4 w-4" />
              <span>Add Memory</span>
            </button>
          </div>

          {/* Category Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-[11px] font-mono no-scrollbar">
            {['all', 'preference', 'language', 'project', 'instruction', 'useful_fact'].map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-full whitespace-nowrap cursor-pointer transition-all ${
                  selectedCategory === cat
                    ? 'bg-cyan-400 text-slate-950 font-bold'
                    : 'bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800'
                }`}
              >
                {cat === 'all' ? 'All Categories' : cat}
              </button>
            ))}
          </div>

          {/* Add Memory Modal / Accordion */}
          {isAddMemoryOpen && (
            <form
              onSubmit={handleSaveNewMemory}
              className="p-3.5 rounded-xl bg-slate-900/90 border border-cyan-500/40 space-y-3 animate-in fade-in"
            >
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <span className="text-xs font-mono font-bold text-cyan-300 flex items-center gap-1.5">
                  <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
                  <span>Add New Memory</span>
                </span>
                <button
                  type="button"
                  onClick={() => setIsAddMemoryOpen(false)}
                  className="text-slate-400 hover:text-white"
                >
                  <X className="h-4 w-4" />
                </button>
              </div>

              <div>
                <label className="text-[10px] font-mono text-slate-400 block mb-1">
                  MEMORY CONTENT (BENGALI, HINDI, OR ENGLISH)
                </label>
                <textarea
                  rows={2}
                  required
                  placeholder="e.g. User prefers Bengali responses, or project architecture detail..."
                  value={editContent}
                  onChange={(e) => setEditContent(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-sans"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">CATEGORY</label>
                  <select
                    value={editCategory}
                    onChange={(e) => setEditCategory(e.target.value as NoraMemoryCategory)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                  >
                    <option value="preference">Preference</option>
                    <option value="language">Language</option>
                    <option value="project">Project</option>
                    <option value="instruction">Instruction</option>
                    <option value="useful_fact">Useful Fact</option>
                    <option value="workflow">Workflow</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="text-[10px] font-mono text-slate-400 block mb-1">
                    IMPORTANCE (1-5)
                  </label>
                  <select
                    value={editImportance}
                    onChange={(e) => setEditImportance(Number(e.target.value))}
                    className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-400 font-mono"
                  >
                    <option value={5}>5 - Critical Directive</option>
                    <option value={4}>4 - High Priority</option>
                    <option value={3}>3 - Standard Fact</option>
                    <option value={2}>2 - Minor Preference</option>
                    <option value={1}>1 - Low Priority</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] font-mono text-slate-400 block mb-1">
                  OPTIONAL PROJECT
                </label>
                <input
                  type="text"
                  placeholder="e.g. NORA AI Assistant"
                  value={editProjectName}
                  onChange={(e) => setEditProjectName(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                />
              </div>

              <div className="flex justify-end gap-2 pt-1">
                <button
                  type="button"
                  onClick={() => setIsAddMemoryOpen(false)}
                  className="min-h-[44px] px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-mono"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="min-h-[44px] px-4 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-semibold cursor-pointer shadow"
                >
                  Save to Brain
                </button>
              </div>
            </form>
          )}

          {/* Memories List */}
          <div className="space-y-2.5 max-h-[380px] overflow-y-auto pr-1">
            {isLoading ? (
              <div className="text-center py-6 text-slate-500 text-xs font-mono flex items-center justify-center gap-2">
                <RefreshCw className="h-4 w-4 animate-spin text-cyan-400" />
                <span>Loading brain memory banks...</span>
              </div>
            ) : filteredMemories.length === 0 ? (
              <div className="text-center py-8 rounded-xl bg-slate-950/40 border border-dashed border-slate-800 p-4">
                <Brain className="h-8 w-8 text-slate-600 mx-auto mb-2 opacity-50" />
                <p className="text-xs text-slate-400 font-mono">No memories found</p>
                <p className="text-[11px] text-slate-500 mt-1">
                  Speak &quot;মনে রাখো...&quot; or &quot;Remember that...&quot; or add a memory above.
                </p>
              </div>
            ) : (
              filteredMemories.map((mem) => {
                const isEditing = editingMemoryId === mem.id;
                const catStyle = CATEGORY_COLORS[mem.category] || CATEGORY_COLORS.other;

                if (isEditing) {
                  return (
                    <div
                      key={mem.id}
                      className="p-3 rounded-xl bg-slate-900 border border-cyan-400/60 space-y-2"
                    >
                      <textarea
                        rows={2}
                        value={editContent}
                        onChange={(e) => setEditContent(e.target.value)}
                        className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-xs text-white focus:outline-none focus:border-cyan-400"
                      />
                      <div className="flex items-center justify-between">
                        <select
                          value={editCategory}
                          onChange={(e) => setEditCategory(e.target.value as NoraMemoryCategory)}
                          className="bg-slate-950 border border-slate-700 rounded p-1 text-xs text-white font-mono"
                        >
                          <option value="preference">Preference</option>
                          <option value="language">Language</option>
                          <option value="project">Project</option>
                          <option value="instruction">Instruction</option>
                          <option value="useful_fact">Useful Fact</option>
                          <option value="other">Other</option>
                        </select>

                        <div className="flex gap-1.5">
                          <button
                            type="button"
                            onClick={() => setEditingMemoryId(null)}
                            className="min-h-[44px] px-2.5 py-1 rounded bg-slate-800 text-xs font-mono text-slate-300"
                          >
                            Cancel
                          </button>
                          <button
                            type="button"
                            onClick={handleSaveEdit}
                            className="min-h-[44px] px-3 py-1 rounded bg-cyan-600 hover:bg-cyan-500 text-xs font-mono font-semibold text-white"
                          >
                            Save
                          </button>
                        </div>
                      </div>
                    </div>
                  );
                }

                return (
                  <div
                    key={mem.id}
                    className="p-3 rounded-xl bg-slate-950/80 hover:bg-slate-900/90 border border-slate-800 hover:border-slate-700 transition-all space-y-2 group"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <p className="text-xs text-slate-200 font-sans leading-relaxed flex-1">
                        {mem.content}
                      </p>

                      <div className="flex items-center gap-1 opacity-80 group-hover:opacity-100 shrink-0">
                        <button
                          type="button"
                          onClick={() => handleStartEdit(mem)}
                          className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-300 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
                          title="Edit Memory"
                        >
                          <Edit2 className="h-3.5 w-3.5" />
                        </button>
                        <button
                          type="button"
                          onClick={() => handleDeleteMemory(mem.id)}
                          className="p-1.5 rounded hover:bg-rose-500/20 text-slate-400 hover:text-rose-400 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
                          title="Delete Memory"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] font-mono text-slate-400 pt-1 border-t border-slate-900">
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <span
                          className={`px-2 py-0.5 rounded-full border ${catStyle.bg} ${catStyle.text} ${catStyle.border} uppercase font-semibold`}
                        >
                          {mem.category}
                        </span>

                        {mem.projectName && (
                          <span className="px-1.5 py-0.5 rounded bg-cyan-950/60 text-cyan-300 border border-cyan-800/40">
                            {mem.projectName}
                          </span>
                        )}

                        <div className="flex items-center text-amber-400/90 pl-1" title={`Importance: ${mem.importance}/5`}>
                          {Array.from({ length: mem.importance }).map((_, i) => (
                            <Star key={i} className="h-2.5 w-2.5 fill-amber-400" />
                          ))}
                        </div>
                      </div>

                      <span className="flex items-center gap-1 text-slate-500">
                        <Clock className="h-3 w-3" />
                        {formatDate(mem.updatedAt)}
                      </span>
                    </div>
                  </div>
                );
              })
            )}
          </div>

          {/* Clear All Footer */}
          {memories.length > 0 && (
            <div className="pt-2 border-t border-slate-800 flex items-center justify-between">
              <span className="text-[11px] font-mono text-slate-500">
                Total: {memories.length} saved memories
              </span>

              {!confirmClearAll ? (
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(true)}
                  className="min-h-[44px] px-3 py-1.5 rounded-lg bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/30 text-xs font-mono cursor-pointer flex items-center gap-1.5"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  <span>Clear All Memories</span>
                </button>
              ) : (
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={handleClearAll}
                    className="min-h-[44px] px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white text-xs font-mono font-semibold"
                  >
                    Confirm Wipe All
                  </button>
                  <button
                    type="button"
                    onClick={() => setConfirmClearAll(false)}
                    className="min-h-[44px] px-2.5 py-1.5 rounded-lg bg-slate-800 text-slate-300 text-xs font-mono"
                  >
                    Cancel
                  </button>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* TAB 2: PROJECT BRAIN (LEVEL 3) */}
      {activeTab === 'projects' && (
        <div className="space-y-3">
          {/* Project Selector Bar */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 no-scrollbar">
            {projects.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setSelectedProjectId(p.id)}
                className={`min-h-[44px] px-3 py-2 rounded-xl text-xs font-mono font-semibold cursor-pointer border flex items-center gap-1.5 whitespace-nowrap transition-all ${
                  selectedProjectId === p.id
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-200'
                    : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                }`}
              >
                <FolderGit2 className="h-3.5 w-3.5" />
                <span>{p.name}</span>
              </button>
            ))}
          </div>

          {activeProject && (
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 space-y-3">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <div>
                  <h4 className="font-mono text-xs font-bold text-white flex items-center gap-2">
                    <span>{activeProject.name}</span>
                    <span className="text-[10px] px-2 py-0.5 rounded-full bg-cyan-500/15 text-cyan-300 border border-cyan-500/30">
                      {activeProject.currentStatus}
                    </span>
                  </h4>
                  <p className="text-[11px] text-slate-400 mt-0.5">{activeProject.description}</p>
                </div>
              </div>

              {/* Key Features */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono text-cyan-300 uppercase block font-semibold">
                  Key Features ({activeProject.features.length})
                </span>
                <ul className="space-y-1 text-xs text-slate-300">
                  {activeProject.features.map((feat, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 bg-slate-900/60 p-1.5 rounded-md border border-slate-800/60">
                      <span className="text-cyan-400 text-[10px] font-mono">0{idx + 1}.</span>
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    placeholder="Add new feature..."
                    value={newFeatureText}
                    onChange={(e) => setNewFeatureText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddProjectFeature()}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddProjectFeature}
                    className="min-h-[44px] px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-semibold"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Goals */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono text-cyan-300 uppercase block font-semibold">
                  Goals &amp; Objectives
                </span>
                <ul className="space-y-1 text-xs text-slate-300">
                  {activeProject.goals.map((goal, idx) => (
                    <li key={idx} className="flex items-start gap-1.5 bg-slate-900/60 p-1.5 rounded-md border border-slate-800/60">
                      <Check className="h-3.5 w-3.5 text-emerald-400 shrink-0 mt-0.5" />
                      <span>{goal}</span>
                    </li>
                  ))}
                </ul>
                <div className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    placeholder="Add new goal..."
                    value={newGoalText}
                    onChange={(e) => setNewGoalText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddProjectGoal()}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddProjectGoal}
                    className="min-h-[44px] px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-semibold"
                  >
                    Add
                  </button>
                </div>
              </div>

              {/* Technical Decisions */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono text-cyan-300 uppercase block font-semibold">
                  Technical Architecture
                </span>
                <ul className="space-y-1 text-xs text-slate-300">
                  {activeProject.technicalDecisions.map((tech, idx) => (
                    <li key={idx} className="bg-slate-900/60 p-1.5 rounded-md border border-slate-800/60 text-[11px] font-mono">
                      {tech}
                    </li>
                  ))}
                </ul>
                <div className="flex gap-1.5 pt-1">
                  <input
                    type="text"
                    placeholder="Add technical specification..."
                    value={newTechText}
                    onChange={(e) => setNewTechText(e.target.value)}
                    onKeyDown={(e) => e.key === 'Enter' && handleAddProjectTech()}
                    className="flex-1 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
                  />
                  <button
                    type="button"
                    onClick={handleAddProjectTech}
                    className="min-h-[44px] px-3 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-mono font-semibold"
                  >
                    Add
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Privacy Guard Assurance */}
      <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800 flex items-center gap-2.5 text-slate-400 text-[11px]">
        <ShieldCheck className="h-4 w-4 text-emerald-400 shrink-0" />
        <span>
          <strong>Device-Private Memory:</strong> All memories, preferences, and project specs are stored locally in your browser&apos;s IndexedDB. Sensitive credentials, passwords, and tokens are strictly prevented from saving.
        </span>
      </div>
    </div>
  );
};
