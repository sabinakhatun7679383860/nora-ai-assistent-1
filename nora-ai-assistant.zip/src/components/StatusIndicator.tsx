/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { Radio, Activity, Zap, Volume2, ShieldAlert, RefreshCw, XCircle, Wrench, Key, ExternalLink } from 'lucide-react';
import { VoiceState, AssistantVisualMode } from '../types/assistant';

interface StatusIndicatorProps {
  state: VoiceState;
  visualMode?: AssistantVisualMode;
  isMuted: boolean;
  decibels: number;
  durationSeconds: number;
  errorMessage?: string | null;
  activeToolName?: string | null;
  onRetry?: () => void;
  onClearError?: () => void;
  onUpdateKey?: () => void;
  onGetNewKey?: () => void;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({
  state,
  visualMode,
  isMuted,
  decibels,
  durationSeconds,
  errorMessage,
  activeToolName,
  onRetry,
  onClearError,
  onUpdateKey,
  onGetNewKey,
}) => {
  // Format live session time (MM:SS)
  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const isKeyError =
    Boolean(errorMessage) &&
    (errorMessage?.toLowerCase().includes('key') ||
      errorMessage?.toLowerCase().includes('unauthorized') ||
      errorMessage?.toLowerCase().includes('quota'));

  const getStatusMeta = () => {
    if (errorMessage) {
      return {
        title: isKeyError ? 'KEY CONFIGURATION NEEDED' : 'DIAGNOSTIC ALERT',
        subtext: isKeyError ? 'Your Gemini API key needs to be updated.' : 'System notification encountered',
        badgeBg: 'bg-rose-500/10 border-rose-400/40 text-rose-300',
        dotColor: 'bg-rose-500 animate-ping',
        icon: <ShieldAlert className="h-4 w-4 text-rose-400" />,
      };
    }

    if (visualMode === 'tool_executing') {
      return {
        title: 'COMMAND EXECUTING',
        subtext: activeToolName ? `Executing ${activeToolName}...` : 'Processing system action...',
        badgeBg: 'bg-amber-500/15 border-amber-400/50 text-amber-300',
        dotColor: 'bg-amber-400 animate-ping',
        icon: <Wrench className="h-4 w-4 text-amber-400 animate-spin-fast" />,
      };
    }

    if (visualMode === 'processing' || state === 'CONNECTING') {
      return {
        title: 'PROCESSING NEURAL SIGNAL',
        subtext: 'Analyzing audio & preparing response...',
        badgeBg: 'bg-amber-500/10 border-amber-400/40 text-amber-300',
        dotColor: 'bg-amber-400 animate-ping',
        icon: <Zap className="h-4 w-4 text-amber-400 animate-pulse" />,
      };
    }

    switch (state) {
      case 'SPEAKING':
        return {
          title: 'TRANSMITTING VOICE',
          subtext: 'Neural Voice Synthesis Active • Interrupt anytime',
          badgeBg: 'bg-fuchsia-500/10 border-fuchsia-400/40 text-fuchsia-300',
          dotColor: 'bg-fuchsia-400 animate-ping',
          icon: <Volume2 className="h-4 w-4 text-fuchsia-400" />,
        };
      case 'LISTENING':
        if (isMuted) {
          return {
            title: 'INPUT MUTED',
            subtext: 'Tap Central Orb to Resume Voice Stream',
            badgeBg: 'bg-rose-500/10 border-rose-400/40 text-rose-300',
            dotColor: 'bg-rose-500',
            icon: <Radio className="h-4 w-4 text-rose-400" />,
          };
        }
        if (visualMode === 'listening') {
          return {
            title: 'VOICE DETECTED',
            subtext: 'Streaming 16kHz PCM audio to Gemini Live',
            badgeBg: 'bg-cyan-500/15 border-cyan-400/50 text-cyan-200',
            dotColor: 'bg-cyan-400 animate-ping',
            icon: <Radio className="h-4 w-4 text-cyan-400 animate-pulse" />,
          };
        }
        return {
          title: 'LISTENING',
          subtext: 'Speak naturally • NORA is listening',
          badgeBg: 'bg-cyan-500/10 border-cyan-400/40 text-cyan-300',
          dotColor: 'bg-cyan-400 animate-ping',
          icon: <Radio className="h-4 w-4 text-cyan-400" />,
        };
      case 'DISCONNECTED':
      default:
        return {
          title: 'STANDBY • READY',
          subtext: 'Tap Central Power Core to Initiate NORA',
          badgeBg: 'bg-slate-800/40 border-slate-700/50 text-slate-400',
          dotColor: 'bg-slate-500',
          icon: <Activity className="h-4 w-4 text-slate-500" />,
        };
    }
  };

  const meta = getStatusMeta();

  return (
    <div id="nora-status-indicator" className="flex flex-col items-center gap-2 text-center w-full max-w-sm px-2">
      {/* State Status Badge */}
      <div
        className={`inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full border backdrop-blur-md transition-all duration-300 ${meta.badgeBg}`}
      >
        <span className="relative flex h-2 w-2">
          <span className={`absolute inline-flex h-full w-full rounded-full opacity-75 ${meta.dotColor}`} />
          <span className={`relative inline-flex rounded-full h-2 w-2 ${meta.dotColor}`} />
        </span>

        <span className="text-[11px] font-mono font-bold tracking-wider">
          {meta.title}
        </span>

        {state !== 'DISCONNECTED' && (
          <span className="text-[10px] font-mono opacity-60 border-l border-white/20 pl-2">
            {formatTime(durationSeconds)}
          </span>
        )}
      </div>

      {/* Subtext description */}
      <p className="text-[11px] sm:text-xs text-slate-400 font-medium tracking-wide max-w-xs transition-opacity duration-300">
        {meta.subtext}
      </p>

      {/* Error notification banner */}
      {errorMessage && (
        <div className="mt-1 w-full flex flex-col gap-2 text-xs text-amber-200 bg-amber-950/80 border border-amber-500/50 p-3 rounded-xl shadow-lg">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2 text-left">
              <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400" />
              <span className="leading-snug text-[11px]">{errorMessage}</span>
            </div>
            {onClearError && (
              <button
                type="button"
                onClick={onClearError}
                className="p-1 text-slate-400 hover:text-white cursor-pointer"
                aria-label="Dismiss error"
              >
                <XCircle className="h-3.5 w-3.5" />
              </button>
            )}
          </div>

          {/* Action row for key errors or connection retries */}
          <div className="flex flex-wrap items-center justify-end gap-2 pt-1 border-t border-amber-500/20">
            {isKeyError && onUpdateKey && (
              <button
                type="button"
                onClick={onUpdateKey}
                className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/50 text-[10px] font-mono font-semibold text-cyan-200 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <Key className="h-3 w-3" />
                <span>Update API Key</span>
              </button>
            )}

            {isKeyError && onGetNewKey && (
              <button
                type="button"
                onClick={onGetNewKey}
                className="px-2.5 py-1 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-700 text-[10px] font-mono font-semibold text-slate-300 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <span>Get New API Key</span>
                <ExternalLink className="h-3 w-3" />
              </button>
            )}

            {onRetry && (
              <button
                type="button"
                onClick={onRetry}
                className="px-2.5 py-1 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-400/40 text-[10px] font-mono font-semibold text-amber-300 flex items-center gap-1 cursor-pointer transition-colors"
              >
                <RefreshCw className="h-3 w-3" />
                <span>RETRY</span>
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
