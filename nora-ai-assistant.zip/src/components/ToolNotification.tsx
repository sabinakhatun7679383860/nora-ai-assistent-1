/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import {
  ExternalLink,
  CheckCircle2,
  AlertTriangle,
  Brain,
  Trash2,
  Search,
  FolderGit2,
  Clock,
  Activity,
} from 'lucide-react';

export interface ToolNotificationData {
  id: string;
  toolName: string;
  url?: string;
  domain?: string;
  success: boolean;
  message?: string;
}

interface ToolNotificationProps {
  notification: ToolNotificationData | null;
  onDismiss: () => void;
}

export const ToolNotification: React.FC<ToolNotificationProps> = ({
  notification,
  onDismiss,
}) => {
  if (!notification) return null;

  const renderToolIcon = () => {
    switch (notification.toolName) {
      case 'rememberMemory':
        return <Brain className="h-4 w-4 text-purple-400" />;
      case 'forgetMemory':
        return <Trash2 className="h-4 w-4 text-rose-400" />;
      case 'searchMemories':
        return <Search className="h-4 w-4 text-cyan-400" />;
      case 'manageProjectMemory':
        return <FolderGit2 className="h-4 w-4 text-emerald-400" />;
      case 'getSystemTime':
        return <Clock className="h-4 w-4 text-amber-400" />;
      case 'getAssistantStatus':
        return <Activity className="h-4 w-4 text-cyan-400" />;
      case 'searchWeb':
        return <Search className="h-4 w-4 text-blue-400" />;
      case 'openWebsite':
      default:
        return notification.success ? (
          <ExternalLink className="h-4 w-4 text-cyan-400" />
        ) : (
          <AlertTriangle className="h-4 w-4 text-rose-400" />
        );
    }
  };

  return (
    <div
      id="nora-tool-notification"
      className={`fixed top-20 z-40 max-w-sm w-[90%] sm:w-auto flex items-center gap-3 px-4 py-2.5 rounded-xl border backdrop-blur-xl shadow-2xl transition-all duration-300 animate-in fade-in slide-in-from-top-4 ${
        notification.success
          ? 'bg-slate-900/90 border-cyan-500/40 text-slate-100 shadow-[0_0_25px_rgba(6,182,212,0.2)]'
          : 'bg-slate-900/90 border-rose-500/40 text-slate-100 shadow-[0_0_25px_rgba(244,63,94,0.2)]'
      }`}
    >
      <div
        className={`p-1.5 rounded-lg ${
          notification.success
            ? 'bg-slate-800/80 border border-slate-700/60'
            : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
        }`}
      >
        {renderToolIcon()}
      </div>

      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-1.5">
          <span className="text-[10px] font-mono uppercase tracking-wider text-cyan-400 font-semibold">
            {notification.toolName}
          </span>
          {notification.success && (
            <CheckCircle2 className="h-3 w-3 text-emerald-400" />
          )}
        </div>
        <p className="text-xs text-slate-300 font-mono truncate">
          {notification.domain
            ? `Opened ${notification.domain}`
            : notification.url
            ? notification.url
            : notification.message || 'Brain action executed'}
        </p>
      </div>

      <button
        type="button"
        onClick={onDismiss}
        className="text-slate-500 hover:text-slate-300 text-xs px-1 cursor-pointer min-h-[36px] min-w-[36px] flex items-center justify-center"
        aria-label="Dismiss notification"
      >
        ✕
      </button>
    </div>
  );
};
