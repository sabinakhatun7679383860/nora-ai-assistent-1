/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import http from 'http';
import express from 'express';
import path from 'path';
import { createServer as createViteServer } from 'vite';
import { setupLiveRelay, validateApiKey } from './server/liveRelay.ts';

async function startServer() {
  const app = express();
  const port = 3000;

  app.use(express.json());

  // API health endpoint
  app.get('/api/health', (_req, res) => {
    res.json({
      status: 'ok',
      service: 'NORA AI Assistant',
      liveApi: 'gemini-3.1-flash-live-preview',
      languages: ['Bengali (বাংলা)', 'Hindi (हिन्दी)', 'English'],
    });
  });

  // API key verification endpoint (validates Gemini API key securely without logging)
  app.post('/api/validate-key', async (req, res) => {
    try {
      const { apiKey } = req.body || {};
      const result = await validateApiKey(apiKey);
      if (result.valid) {
        return res.json(result);
      }
      return res.status(400).json(result);
    } catch (err: any) {
      return res.status(400).json({ valid: false, error: err?.message || 'Validation failed' });
    }
  });

  // Vite middleware for development or static serving for production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  const server = http.createServer(app);

  // Attach the WebSocket Live API relay
  setupLiveRelay(server);

  server.listen(port, '0.0.0.0', () => {
    console.log(`[NORA Server] Running on http://0.0.0.0:${port}`);
  });
}

startServer();
