/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

const CACHE_NAME = 'nora-ai-v2';

// Install event: Pre-cache core shell using relative paths
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      console.log('[NORA SW] Pre-caching offline application shell');
      const basePath = self.location.pathname.replace(/sw\.js$/, '');
      const assets = [
        basePath,
        `${basePath}index.html`,
        `${basePath}manifest.json`,
        `${basePath}icon.svg`,
        `${basePath}favicon.svg`,
      ];
      return cache.addAll(assets).catch((err) => {
        console.warn('[NORA SW] Some assets failed to pre-cache:', err);
      });
    })
  );
  self.skipWaiting();
});

// Activate event: Clean up old cache versions and claim immediate control
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => {
      return Promise.all(
        keys.map((key) => {
          if (key !== CACHE_NAME) {
            console.log('[NORA SW] Removing stale cache:', key);
            return caches.delete(key);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event: Network-first with Cache fallback (excluding WebSocket and Gemini API paths)
self.addEventListener('fetch', (event) => {
  const url = new URL(event.request.url);

  // Exclude non-GET requests, API endpoints, and live relay / Gemini WebSocket traffic
  if (
    event.request.method !== 'GET' ||
    url.pathname.startsWith('/api/') ||
    url.hostname.includes('googleapis.com') ||
    url.protocol === 'ws:' ||
    url.protocol === 'wss:'
  ) {
    return;
  }

  // Handle HTML navigation: Network first, falling back to cached index.html
  if (event.request.mode === 'navigate') {
    event.respondWith(
      fetch(event.request)
        .then((networkResponse) => {
          if (networkResponse && networkResponse.status === 200) {
            const copy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return networkResponse;
        })
        .catch(() => {
          const basePath = self.location.pathname.replace(/sw\.js$/, '');
          return caches.match(`${basePath}index.html`).then((cached) => cached || caches.match(basePath));
        })
    );
    return;
  }

  // For static assets: Cache first / Stale-while-revalidate
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      const fetchPromise = fetch(event.request)
        .then((networkResponse) => {
          if (
            networkResponse &&
            networkResponse.status === 200 &&
            networkResponse.type === 'basic'
          ) {
            const copy = networkResponse.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
          }
          return networkResponse;
        })
        .catch(() => {
          // Network failure is fine if we had a cached version
          return cachedResponse;
        });

      return cachedResponse || fetchPromise;
    })
  );
});
