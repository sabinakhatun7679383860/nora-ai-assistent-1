/**
 * Generates valid PNG icons for PWA compliance without external dependencies.
 */
import fs from 'fs';
import path from 'path';
import zlib from 'zlib';

function createPngBuffer(width, height, drawFn) {
  // RGBA buffer
  const rgba = Buffer.alloc(width * height * 4);

  for (let y = 0; y < height; y++) {
    for (let x = 0; x < width; x++) {
      const idx = (y * width + x) * 4;
      const [r, g, b, a] = drawFn(x, y, width, height);
      rgba[idx] = r;
      rgba[idx + 1] = g;
      rgba[idx + 2] = b;
      rgba[idx + 3] = a;
    }
  }

  // Filter scanlines: 0x00 (None) prefix per line
  const rawScanlines = Buffer.alloc(height * (1 + width * 4));
  for (let y = 0; y < height; y++) {
    const rawOffset = y * (1 + width * 4);
    rawScanlines[rawOffset] = 0; // Filter byte: None
    const rgbaOffset = y * width * 4;
    rgba.copy(rawScanlines, rawOffset + 1, rgbaOffset, rgbaOffset + width * 4);
  }

  const compressed = zlib.deflateSync(rawScanlines);

  // Build PNG chunks
  const signature = Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]);

  function makeChunk(type, data) {
    const len = Buffer.alloc(4);
    len.writeUInt32BE(data.length, 0);
    const typeBuf = Buffer.from(type, 'ascii');
    const crcData = Buffer.concat([typeBuf, data]);
    const crc = crc32(crcData);
    const crcBuf = Buffer.alloc(4);
    crcBuf.writeUInt32BE(crc, 0);
    return Buffer.concat([len, typeBuf, data, crcBuf]);
  }

  // IHDR
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(width, 0);
  ihdr.writeUInt32BE(height, 4);
  ihdr[8] = 8; // Bit depth
  ihdr[9] = 6; // Color type: RGBA
  ihdr[10] = 0; // Compression
  ihdr[11] = 0; // Filter
  ihdr[12] = 0; // Interlace

  const ihdrChunk = makeChunk('IHDR', ihdr);
  const idatChunk = makeChunk('IDAT', compressed);
  const iendChunk = makeChunk('IEND', Buffer.alloc(0));

  return Buffer.concat([signature, ihdrChunk, idatChunk, iendChunk]);
}

// Standard CRC32 table & calculation
const crcTable = new Uint32Array(256);
for (let n = 0; n < 256; n++) {
  let c = n;
  for (let k = 0; k < 8; k++) {
    c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  }
  crcTable[n] = c;
}

function crc32(buf) {
  let c = 0xffffffff;
  for (let i = 0; i < buf.length; i++) {
    c = crcTable[(c ^ buf[i]) & 0xff] ^ (c >>> 8);
  }
  return (c ^ 0xffffffff) >>> 0;
}

// Icon Drawer
function noraIconDrawer(x, y, w, h) {
  const cx = w / 2;
  const cy = h / 2;
  const dx = x - cx;
  const dy = y - cy;
  const dist = Math.sqrt(dx * dx + dy * dy);
  const maxR = w / 2;

  // Background: dark futuristic cyber canvas (#07090e -> #0b1329)
  const bgNorm = Math.min(1, dist / maxR);
  const rBg = Math.round(7 + (11 - 7) * (1 - bgNorm));
  const gBg = Math.round(9 + (19 - 9) * (1 - bgNorm));
  const bBg = Math.round(14 + (41 - 14) * (1 - bgNorm));

  // Outer orbital ring (radius ~ 0.65 to 0.72)
  const rRing1 = maxR * 0.68;
  const ring1Dist = Math.abs(dist - rRing1);

  // Inner core (radius ~ 0.35)
  const rCore = maxR * 0.38;

  if (dist < rCore) {
    // Glowing cyan/magenta core
    const coreNorm = dist / rCore;
    const r = Math.round(6 + (217 - 6) * coreNorm);
    const g = Math.round(182 - 110 * coreNorm);
    const b = Math.round(212 + 27 * coreNorm);
    return [r, g, b, 255];
  } else if (ring1Dist < maxR * 0.04) {
    // Cyan orbital ring
    const ringAlpha = 1 - ring1Dist / (maxR * 0.04);
    return [
      Math.round(6 * ringAlpha + rBg * (1 - ringAlpha)),
      Math.round(182 * ringAlpha + gBg * (1 - ringAlpha)),
      Math.round(212 * ringAlpha + bBg * (1 - ringAlpha)),
      255,
    ];
  } else if (dist < maxR * 0.85) {
    // Outer atmospheric cyan/magenta bloom
    const glowIntensity = Math.max(0, 1 - (dist - rCore) / (maxR * 0.45));
    const r = Math.round(rBg + 20 * glowIntensity);
    const g = Math.round(gBg + 80 * glowIntensity);
    const b = Math.round(bBg + 130 * glowIntensity);
    return [r, g, b, 255];
  }

  return [rBg, gBg, bBg, 255];
}

const publicDir = path.resolve(process.cwd(), 'public');
if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

// Write 192x192
const png192 = createPngBuffer(192, 192, noraIconDrawer);
fs.writeFileSync(path.join(publicDir, 'icon-192.png'), png192);
console.log('Created icon-192.png');

// Write 512x512
const png512 = createPngBuffer(512, 512, noraIconDrawer);
fs.writeFileSync(path.join(publicDir, 'icon-512.png'), png512);
fs.writeFileSync(path.join(publicDir, 'icon-maskable-512.png'), png512);
fs.writeFileSync(path.join(publicDir, 'apple-touch-icon.png'), png512);
console.log('Created icon-512.png, icon-maskable-512.png, apple-touch-icon.png');
